/**
 * Kirim pesan ke satu frame, dengan satu kali suntik ulang content script bila frame itu belum punya penerima.
 *
 * Uji live 26 November 2026: Side Panel menampilkan galat mentah Chrome "Could not establish connection. Receiving
 * end does not exist." Tab lowongan sudah terbuka sebelum ekstensi dimuat ulang, atau suntikan `allFrames` gagal dan
 * jatuh ke frame utama saja, sehingga frame yang dipilih tidak punya `content.js`. Galat itu kini memicu suntik ulang
 * ke frame tersebut lalu satu percobaan lagi; bila tetap gagal, pengguna mendapat langkah yang jelas.
 */
const NO_RECEIVER_RE = /Receiving end does not exist|Could not establish connection/i;
const messageOf = (err) => typeof err?.message === "string" ? String(err.message) : String(err);
const PANEL_RELOAD_MESSAGE = "Ekstensi baru dimuat ulang. Tutup Side Panel ini, lalu buka lagi dari ikon Applify.";
/**
 * Pesan Side Panel ke service worker. Uji live 26 November 2026: sesudah ekstensi dimuat ulang, Side Panel yang masih
 * terbuka adalah halaman lama yang tidak lagi tersambung, dan setiap tombol memunculkan galat mentah Chrome "Could not
 * establish connection. Receiving end does not exist." Galat itu diganti langkah yang jelas untuk pengguna.
 */
async function sendFromPanel(send) {
    try {
        return await send();
    }
    catch (err) {
        if (NO_RECEIVER_RE.test(messageOf(err)) || /Extension context invalidated/i.test(messageOf(err)))
            throw new Error(PANEL_RELOAD_MESSAGE);
        throw err;
    }
}

/**
 * Jawaban pertanyaan yang diketik pengguna di side panel, sebelum dikirim ke `POST /api/extension/answers`.
 * Batas sama dengan backend (30 jawaban, nilai paling panjang 2000 karakter); dirapikan di sini supaya
 * permintaan tidak ditolak karena ukuran.
 */
const MAX_ANSWERS = 30;
const MAX_ANSWER_VALUE_LENGTH = 2000;
const MAX_KEY_LENGTH = 200;
const MAX_LABEL_LENGTH = 300;
/** Buang jawaban kosong atau salah bentuk, pangkas spasi, potong ke batas, dan batasi jumlahnya. Kunci kembar: yang pertama menang. */
function sanitizeAnswers(raw) {
    if (!Array.isArray(raw))
        return [];
    const out = [];
    const seen = new Set();
    for (const item of raw) {
        const a = item;
        if (typeof a?.key !== "string" || typeof a.value !== "string")
            continue;
        const key = a.key.trim().slice(0, MAX_KEY_LENGTH);
        const value = a.value.trim().slice(0, MAX_ANSWER_VALUE_LENGTH);
        if (!key || !value || seen.has(key))
            continue;
        seen.add(key);
        const label = (typeof a.label === "string" ? a.label : "").replace(/\s+/g, " ").trim().slice(0, MAX_LABEL_LENGTH) || key;
        out.push({ key, label, value });
        if (out.length >= MAX_ANSWERS)
            break;
    }
    return out;
}

// AUTO-GENERATED from project/shared/domains.json via project/scripts/sync-domains.mjs. DO NOT EDIT BY HAND.
const KNOWN_ATS_DOMAINS = [
    "greenhouse.io",
    "lever.co",
    "ashbyhq.com",
    "workable.com",
    "smartrecruiters.com",
    "recruitee.com",
    "breezy.hr",
    "bamboohr.com",
    "jazzhr.com",
    "applytojob.com",
    "personio.de",
    "personio.com",
    "teamtailor.com",
    "pinpointhq.com",
    "myworkdayjobs.com",
    "icims.com",
    "jobvite.com",
    "taleo.net",
    "successfactors.com",
    "successfactors.eu",
    "rippling-ats.com",
    "keka.com",
    "freshteam.com"
];
const EXTENSION_LOGIN_PORTAL_DOMAINS = [
    "jobstreet.com",
    "jobstreet.co.id",
    "glints.com",
    "kalibrr.com",
    "kalibrr.id",
    "dealls.com"
];
const EXTERNAL_AUTH_PORTAL_MAP = {
    "jobstreet.com": [
        "login.seek.com",
        "auth.seek.com"
    ],
    "jobstreet.co.id": [
        "login.seek.com",
        "auth.seek.com"
    ]
};

/**
 * Penjaga keamanan & domain untuk Ekstensi Browser Chrome/Edge Applify.
 *
 * Aturan utama:
 *   - Lowongan/domain LinkedIn selalu ditolak (manual-only).
 *   - Hanya URL http(s) yang sah; remote API wajib HTTPS kecuali localhost/127.0.0.1.
 *   - Token wajib berawalan `ext_tok_v1.` (menolak JWT Supabase penuh agar pemisahan scope terjaga).
 *   - Tangkapan layar `captureVisibleTab` hanya diizinkan pada tab lowongan/ATS terkait.
 */
function parseHttpUrl(raw) {
    if (typeof raw !== "string")
        return null;
    const trimmed = raw.trim();
    if (!trimmed)
        return null;
    try {
        const u = new URL(trimmed);
        if (u.protocol !== "http:" && u.protocol !== "https:")
            return null;
        return u;
    }
    catch {
        return null;
    }
}

/** Semua domain yang izin situsnya dimiliki ekstensi sejak pasang: ATS yang dikenal ditambah portal login. */
const EXTENSION_HOST_DOMAINS = [...KNOWN_ATS_DOMAINS, ...EXTENSION_LOGIN_PORTAL_DOMAINS];
/**
 * Google Forms (lowongan di luar portal sering memakai tautan `forms.gle`). Bukan ATS dan bukan portal login, jadi
 * tidak masuk daftar domain bersama (`domains.json`): ini kasus tersendiri dengan izin yang dibatasi PATH.
 * `docs.google.com` juga rumah Docs, Sheets, dan Drive, jadi izinnya hanya `https://docs.google.com/forms/*`.
 * `forms.gle` hanya pengalih HTTP ke sana: tidak butuh izin sendiri (tab berakhir di docs.google.com).
 */
const GOOGLE_FORMS_HOST = "docs.google.com";
const GOOGLE_FORMS_SHORT_HOST = "forms.gle";
const GOOGLE_FORMS_PERMISSION_PATTERN = `https://${GOOGLE_FORMS_HOST}/forms/*`;
/** URL minimal yang dicakup `GOOGLE_FORMS_PERMISSION_PATTERN`, untuk meminta atau memeriksa izinnya per host. */
const GOOGLE_FORMS_PERMISSION_URL = `https://${GOOGLE_FORMS_HOST}/forms/`;
/**
 * URL Google Forms yang dicakup izin di atas: `forms.gle/<kode>` (pengalih), atau `docs.google.com/forms/...`. Hanya
 * HTTPS. Path `/u/0/forms/` dan `/a/<domain>/forms/` (akun Workspace) tidak dicakup pola `/forms/*`, jadi bukan cocok.
 */
function isGoogleFormsUrl(rawUrl) {
    const url = parseHttpUrl(rawUrl);
    if (!url || url.protocol !== "https:")
        return false;
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (host === GOOGLE_FORMS_SHORT_HOST)
        return url.pathname.length > 1;
    return host === GOOGLE_FORMS_HOST && (url.pathname === "/forms" || url.pathname.startsWith("/forms/"));
}
const isIpLike = (host) => /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(":") || host.startsWith("[");
/**
 * Host `rawHost` adalah salah satu domain di daftar atau subdomainnya (aturan yang sama dengan `hostMatchesDomain`
 * di backend). Bawaannya HANYA ATS (`KNOWN_ATS_DOMAINS`), jadi `id.jobstreet.com` bukan ATS di sini, sama seperti di
 * backend. Untuk "situs yang boleh diminta izinnya" (ATS atau portal login) pakai `hostIsExtensionSite`.
 */
function hostIsKnownAts(rawHost, domains = KNOWN_ATS_DOMAINS) {
    const host = String(rawHost ?? "")
        .trim()
        .toLowerCase()
        .replace(/\.$/, "");
    if (!host || isIpLike(host))
        return false;
    return domains.some((d) => host === d || host.endsWith(`.${d}`));
}
/**
 * Pola izin untuk SATU host lowongan: `https://<host persis>/*`, atau null bila host itu bukan ATS atau portal login
 * di daftar. Hanya HTTPS. Dipakai untuk `chrome.permissions.request`, sehingga host di luar daftar tidak pernah
 * diminta izinnya (tetap lewat `activeTab`).
 *
 * Pengecualian tersendiri: Google Forms (`forms.gle/<kode>` atau `docs.google.com/forms/...`) memakai pola path
 * `GOOGLE_FORMS_PERMISSION_PATTERN`, bukan host persis, supaya Docs, Sheets, dan Drive tidak ikut terbuka. Hanya
 * berlaku untuk daftar bawaan; daftar domain khusus (tes) tidak pernah menerimanya.
 */
function atsPermissionPattern(rawUrl, domains = EXTENSION_HOST_DOMAINS) {
    const url = parseHttpUrl(rawUrl);
    if (!url || url.protocol !== "https:")
        return null;
    if (domains === EXTENSION_HOST_DOMAINS && isGoogleFormsUrl(url.href))
        return GOOGLE_FORMS_PERMISSION_PATTERN;
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (!hostIsKnownAts(host, domains))
        return null;
    return `https://${host}/*`;
}
/** Daftar seluruh host autentikasi eksternal dikenal milik portal (mis. `login.seek.com` untuk JobStreet). */
[
    ...new Set(Object.values(EXTERNAL_AUTH_PORTAL_MAP).flat()),
];

/**
 * Minta izin untuk origin lowongan, HANYA bila host-nya cocok dengan daftar ATS atau portal login (JobStreet,
 * Glints, Kalibrr, Dealls). Host di luar daftar, URL non-HTTPS,
 * dan URL yang tidak terbaca tidak pernah memanggil `permissions.request`. Penolakan atau galat (di luar gestur,
 * pola di luar manifest) menghasilkan `granted: false`, bukan galat: jalur cadangannya tetap `activeTab`.
 *
 * Panggil langsung di dalam handler klik, sebelum `await` lain, agar gestur pengguna masih berlaku.
 */
async function requestAtsPermission(api, applyUrl) {
    const pattern = atsPermissionPattern(applyUrl);
    if (!pattern || !api)
        return { requested: false, granted: false, pattern };
    try {
        const granted = await api.request({ origins: [pattern] });
        return { requested: true, granted: granted === true, pattern };
    }
    catch {
        return { requested: true, granted: false, pattern };
    }
}

/**
 * Berkas lamaran yang dipasang ke input file halaman: jenis, batas ukuran, dan pembersihan metadata dari respons backend.
 *
 * Berkas hanya hidup di memori service worker dan skrip konten selama satu pengisian. Tidak pernah ditulis ke
 * `chrome.storage` (session maupun local).
 */
const FILE_KINDS = ["resume", "cover_letter", "transcript", "portfolio"];
/** Nama jenis berkas untuk pesan ke pengguna. */
const FILE_KIND_LABELS = {
    resume: "CV",
    cover_letter: "surat lamaran",
    transcript: "transkrip",
    portfolio: "portofolio",
};

/** Pilihan ya/tidak untuk kolom centang tanpa daftar opsi. Nilai yang disimpan memakai bahasa formulir (Yes/No). */
const YES_NO_CHOICES = [
    { label: "Ya", value: "Yes" },
    { label: "Tidak", value: "No" },
];
/**
 * Jenis isian untuk satu pertanyaan. Kolom rahasia (`secret_skip`) dan input file tidak pernah punya isian:
 * pengguna mengisinya sendiri di halaman, dan nilainya tidak lewat panel ini.
 */
function questionWidget(q) {
    if (q.kind === "secret_skip" || q.kind === "file")
        return "self_fill";
    if (Array.isArray(q.options) && q.options.length > 0)
        return "select";
    // `check` = kolom centang (kosakata backend); `checkbox` = nama jenis kontrol di ekstensi.
    if (q.kind === "check" || q.kind === "checkbox")
        return "yesno";
    if (q.kind === "textarea")
        return "textarea";
    return "text";
}
function splitQuestions(list) {
    const answerable = [];
    const selfFill = [];
    for (const q of Array.isArray(list) ? list : []) {
        if (!q || typeof q.key !== "string" || typeof q.label !== "string")
            continue;
        (questionWidget(q) === "self_fill" ? selfFill : answerable).push(q);
    }
    return { answerable, selfFill };
}
/** Jawaban yang akan dikirim: hanya pertanyaan yang bisa dijawab dan sudah diisi (kosong dibuang). */
function collectAnswers(answerable, values) {
    return sanitizeAnswers(answerable.map((q) => ({ key: q.key, label: q.label, value: values.get(q.key) ?? "" })));
}
const onTargetTab = (session, tabAccess) => Boolean(session?.targetOk && tabAccess === "ok");
/**
 * Sesi tab aktif yang belum siap kirim (kolom wajib masih kurang atau tombol kirim tidak ditemukan) tetapi masih
 * menyimpan pertanyaan, mis. hasil antrean latar yang berhenti karena butuh jawaban. Dikembalikan agar panel
 * menampilkan pertanyaannya (audit U2B-08). Tidak menimpa tampilan hasil pengisian manual persetujuan lain, dan
 * tidak diulang untuk persetujuan yang pertanyaannya sudah tampil.
 */
function pendingSessionToRestore(session, tabAccess, knownApprovalIds, view) {
    if (!session || session.canSubmit || !onTargetTab(session, tabAccess))
        return null;
    if (typeof session.approvalId !== "string" || !knownApprovalIds.includes(session.approvalId))
        return null;
    if (!Array.isArray(session.pendingQuestions) || session.pendingQuestions.length === 0)
        return null;
    if (view.shownFor === session.approvalId)
        return null;
    if (view.shownFor !== null && !view.restored)
        return null;
    return session;
}
/** Tampilan hasil pemulihan sesi sudah usang: tab aktif bukan lagi tab yang tadi diisi untuk persetujuan itu. */
function restoredQuestionsStale(session, tabAccess, view) {
    if (!view.restored || view.shownFor === null)
        return false;
    return !(onTargetTab(session, tabAccess) && session?.approvalId === view.shownFor);
}
/** Pesan generik bila AI gagal (`aiError: "ai_failed"`). Tanpa detail galat, tanpa nama penyedia. */
const AI_FAILED_MESSAGE = "Applify belum bisa menyusun jawaban otomatis untuk sebagian kolom. Isi sendiri di halaman, atau coba lagi nanti.";
/** Ringkasan hasil pengisian untuk panel: kolom terisi, berkas terpasang, pertanyaan tersisa, galat generik. */
function summarizeRunForPanel(res) {
    const lines = [];
    const summary = res?.summary;
    if (summary)
        lines.push(`Kolom terisi: ${Number(summary.filledCount) || 0}`);
    const attached = res?.files?.attached;
    const names = FILE_KINDS.filter((k) => attached?.[k] === true).map((k) => FILE_KIND_LABELS[k]);
    lines.push(`Berkas terpasang: ${names.length ? names.join(", ") : "tidak ada"}`);
    const questions = Array.isArray(res?.questions) ? res.questions : Array.isArray(res?.plan?.pendingQuestions) ? res.plan.pendingQuestions : [];
    const { answerable, selfFill } = splitQuestions(questions);
    const required = answerable.filter((q) => q.required === true).length;
    const parts = [`${required} wajib`, `${answerable.length - required} opsional`];
    lines.push(`Pertanyaan tersisa: ${parts.join(", ")}${selfFill.length ? `; ${selfFill.length} diisi sendiri` : ""}`);
    if (res?.plan?.aiError === "ai_failed")
        lines.push(AI_FAILED_MESSAGE);
    const note = typeof res?.plan?.note === "string" ? res.plan.note.trim() : "";
    if (note)
        lines.push(`Catatan Applify: ${note}`);
    return lines;
}
/** Pesan galat berkas (sudah generik dari service worker) untuk ditampilkan di bawah ringkasan. */
function fileProblemsForPanel(res) {
    const errors = res?.files?.errors;
    if (!Array.isArray(errors))
        return [];
    return errors.map((e) => (typeof e?.message === "string" ? e.message : "")).filter(Boolean);
}

/**
 * URL minimal untuk satu host: bentuk yang diterima `requestAtsPermission` dan `hasOriginPermission`. Google Forms
 * (`docs.google.com`) izinnya dibatasi path `/forms/`, jadi URL-nya ikut path itu, bukan akar situs.
 */
const permissionUrlForHost = (host) => (host === GOOGLE_FORMS_HOST ? GOOGLE_FORMS_PERMISSION_URL : `https://${host}/`);
/** Nama yang ditampilkan untuk sebuah host: Google Forms hanya halaman /forms/ di docs.google.com, bukan seluruh situsnya. */
const displayHost = (host) => (host === GOOGLE_FORMS_HOST ? "Google Forms (docs.google.com/forms)" : host);
const permissionCardText = (host) => `Ekstensi butuh izin untuk membuka ${displayHost(host)}`;
const permissionButtonLabel = (host) => (host === GOOGLE_FORMS_HOST ? "Izinkan Google Forms" : `Izinkan ${host}`);

const NO_TAB_ACCESS_MESSAGE = "Ekstensi belum punya akses ke tab ini. Klik ikon Applify di toolbar saat berada di tab lowongan (panel tetap terbuka), lalu coba lagi. Untuk situs ATS dan portal lowongan yang dikenal (JobStreet, Glints, Kalibrr, Dealls), tombol Buka Situs Lowongan atau Isi Formulir Sekarang juga meminta izin situsnya.";

/**
 * Draf token yang sedang diketik di side panel.
 *
 * Disimpan di `chrome.storage.session` (memori peramban, tidak ditulis ke disk, hilang saat peramban
 * ditutup, tidak terbaca skrip konten), BUKAN `chrome.storage.local`. Draf kedaluwarsa dalam
 * `TOKEN_DRAFT_TTL_MS` dan dihapus saat terhubung atau diputus. Nilai token tidak pernah ditulis ke log.
 */
const TOKEN_DRAFT_KEY = "applify_token_draft";
const TOKEN_DRAFT_TTL_MS = 30 * 60 * 1000;
const TOKEN_DRAFT_MAX_LENGTH = 4096;
async function saveTokenDraft(area, value, now) {
    if (typeof value !== "string" || value === "") {
        await area.remove(TOKEN_DRAFT_KEY);
        return;
    }
    await area.set({ [TOKEN_DRAFT_KEY]: { value: value.slice(0, TOKEN_DRAFT_MAX_LENGTH), savedAt: now } });
}
/** Draf yang masih berlaku, atau string kosong. Draf kedaluwarsa atau rusak dihapus. */
async function loadTokenDraft(area, now) {
    const res = await area.get(TOKEN_DRAFT_KEY);
    const raw = res?.[TOKEN_DRAFT_KEY];
    const valid = raw &&
        typeof raw === "object" &&
        typeof raw.value === "string" &&
        typeof raw.savedAt === "number" &&
        now - raw.savedAt >= 0 &&
        now - raw.savedAt <= TOKEN_DRAFT_TTL_MS;
    if (!valid) {
        if (raw !== undefined)
            await area.remove(TOKEN_DRAFT_KEY);
        return "";
    }
    return raw.value;
}
async function clearTokenDraft(area) {
    await area.remove(TOKEN_DRAFT_KEY);
}

/**
 * Status kesehatan runner antrean, disimpan di `chrome.storage.session` supaya panel bisa menampilkannya.
 *
 * - Token kedaluwarsa atau dicabut (401) menghentikan polling antrean sampai pengguna menghubungkan ulang
 *   (`clearRunnerAuthExpired`, dipanggil saat token baru tersimpan). Tanpa ini, poll tiap menit menghasilkan 401
 *   yang sama terus-menerus.
 * - Galat lain hanya dicatat (`lastError`, `consecutiveFailures`) supaya panel bisa menjelaskannya.
 * - Fungsi di bagian "murni" tidak menyentuh storage, jadi mudah diuji.
 *
 * Nilai token tidak pernah masuk ke status ini; hanya sidik jari 32-bit (`tokenId`) untuk menolak 401 milik token lama.
 */
const RUNNER_HEALTH_KEY = "applify_runner_health";
/** Jumlah galat berturut-turut sebelum panel menampilkan peringatan. */
const DEGRADED_FAILURE_THRESHOLD = 2;
/** Galat berulang yang belum selesai (bukan sambungan kedaluwarsa): panel perlu menampilkan `lastError`. */
function isRunnerDegraded(h) {
    return !h.authExpired && h.consecutiveFailures >= DEGRADED_FAILURE_THRESHOLD && h.lastError !== null;
}
/** Tulisan dibuat berurutan supaya dua pembaruan yang datang bersamaan tidak saling menimpa. */
Promise.resolve();

/**
 * URL backend Applify yang tetap (bukan isian pengguna).
 *
 * Nilai bawaan adalah backend production. Build lokal untuk dev dapat menimpanya lewat variabel lingkungan
 * `APPLIFY_API_URL` yang dibaca `build.mjs` (lihat README). Build menyisipkan `__APPLIFY_API_URL__` di atas
 * modul ini; di luar build (misalnya saat tes) simbol itu tidak ada dan nilai bawaan dipakai.
 */
const PRODUCTION_API_URL = "https://backend-production-efa7dfef.up.railway.app";
typeof __APPLIFY_API_URL__ === "string" && __APPLIFY_API_URL__ !== "" ? __APPLIFY_API_URL__ : PRODUCTION_API_URL;
/**
 * Alamat aplikasi web Applify. Dipakai hanya untuk membuka halaman Pengaturan (tempat token ekstensi dibuat) dari
 * side panel saat token habis. Ekstensi tidak pernah mengirim apa pun ke alamat ini.
 */
const PRODUCTION_WEB_URL = "https://applify-smart-job-applications.vercel.app";
const SETTINGS_EXTENSION_URL = `${PRODUCTION_WEB_URL}/settings#ekstensi`;

/**
 * Pemetaan kode galat backend `/api/extension/*` ke pesan Indonesia yang singkat untuk side panel.
 *
 * Kode `already_claimed` dan `approval_already_used` bersifat final: persetujuan itu tidak boleh
 * dikirim lagi dari ekstensi.
 */
/** Masa berlaku token ekstensi (keputusan Hans 26 Nov 2026: 8 jam, sama dengan backend `DEFAULT_EXTENSION_TTL_SEC`). */
const TOKEN_LIFETIME_LABEL = "8 jam";
/** Langkah membuat token baru, sama persis dengan yang tertulis di Bantuan Applify (#ekstensi). */
const TOKEN_RENEW_STEPS = "Buka Applify, lalu Pengaturan, lalu Hubungkan Ekstensi Chrome/Edge, salin token baru, dan tempel di kolom token di panel ini.";

/**
 * UI side panel Applify Form Copilot. Panel tetap terbuka saat pengguna berpindah tab atau mengklik halaman
 * lowongan, jadi semua keadaan yang bisa hilang (token yang sedang diketik, status tab) dipulihkan atau
 * dihitung ulang dari service worker, bukan diandalkan dari umur halaman ini.
 */
const el = (id) => document.getElementById(id);
const connectSection = el("connect-section");
const appSection = el("app-section");
const disconnectBtn = el("disconnect-btn");
const tabBanner = el("tab-banner");
const tabBannerText = el("tab-banner-text");
const recheckTabBtn = el("recheck-tab-btn");
const tabHost = el("tab-host");
const statusBox = el("status-box");
const extTokenInput = el("ext-token");
const connectBtn = el("connect-btn");
const refreshBtn = el("refresh-btn");
const approvalsList = el("approvals-list");
const actionsPanel = el("actions-panel");
const openTabBtn = el("open-tab-btn");
const fillBtn = el("fill-btn");
const resumeBtn = el("resume-btn");
const submitBtn = el("submit-btn");
const resultBox = el("result-box");
const resultList = el("result-list");
const questionsBox = el("questions-box");
const questionsList = el("questions-list");
const selfFillBox = el("selffill-box");
const selfFillList = el("selffill-list");
const saveAnswersBtn = el("save-answers-btn");
const unreportedBanner = el("unreported-banner");
const unreportedText = el("unreported-text");
const retryReportBtn = el("retry-report-btn");
const bgFillToggle = el("bg-fill-toggle");
const visibleRunToggle = el("visible-run-toggle");
const permissionList = el("permission-list");
const runnerHealthBanner = el("runner-health-banner");
const runnerHealthText = el("runner-health-text");
const reconnectBtn = el("reconnect-btn");
const openSettingsBtn = el("open-settings-btn");
const openSettingsConnectBtn = el("open-settings-connect-btn");
const tokenHelp = el("token-help");
// Cara mendapatkan token selalu terlihat di bagian hubungkan, karena token berlaku 8 jam dan akan habis di tengah pemakaian.
tokenHelp.textContent = `Token berlaku ${TOKEN_LIFETIME_LABEL}. ${TOKEN_RENEW_STEPS}`;
/** Buka halaman Pengaturan Applify (bagian Ekstensi) di tab baru. Tidak ada data yang dikirim ke sana. */
function openApplifySettings() {
    try {
        void chrome.tabs.create({ url: SETTINGS_EXTENSION_URL });
    }
    catch {
        window.open(SETTINGS_EXTENSION_URL, "_blank", "noopener,noreferrer");
    }
}
openSettingsBtn.addEventListener("click", openApplifySettings);
openSettingsConnectBtn.addEventListener("click", openApplifySettings);
let items = [];
let selected = null;
let connected = false;
/** Akses ekstensi ke tab aktif. Dihitung service worker; diperbarui tiap tab berpindah atau berubah. */
let tabAccess = "no_access";
/** true selama pengisian atau pengiriman berjalan. Pembaruan status tab tidak boleh mengubah tombol Kirim saat itu. */
let busy = false;
/** Jendela tempat panel ini berada, supaya "tab aktif" berarti tab aktif di jendela ini. */
let windowId;
/** Pertanyaan yang sedang ditampilkan sebagai isian, dan ketikan pengguna. Hanya di memori panel, tidak disimpan di storage. */
let currentQuestions = [];
const answerDrafts = new Map();
/** Persetujuan pemilik pertanyaan yang sedang tampil, dan apakah itu hasil pemulihan sesi tab (bukan pengisian manual di panel ini). */
let questionsShownFor = null;
let questionsRestored = false;
/** Kirim pesan ke service worker. Selalu membawa `windowId` panel. */
function send(message) {
    return sendFromPanel(() => chrome.runtime.sendMessage({ ...message, windowId }));
}
/** Tampilkan atau sembunyikan peringatan "hasil belum terlapor". Tetap tampil sampai laporan berhasil. */
function renderUnreported(warning) {
    if (!warning) {
        unreportedBanner.classList.add("hidden");
        unreportedText.textContent = "";
        return;
    }
    unreportedText.textContent = `${warning} `;
    unreportedBanner.classList.remove("hidden");
}
/**
 * Kartu kesehatan runner. Sambungan kedaluwarsa (401): antrean berhenti sampai token baru, dengan tombol
 * "Hubungkan ulang". Galat berulang: tampilkan `lastError` singkat. Selain itu banner disembunyikan.
 */
function renderRunnerHealth(health) {
    if (health?.authExpired) {
        runnerHealthText.textContent = `Sambungan ke Applify kedaluwarsa, jadi antrean berhenti sementara. Token berlaku ${TOKEN_LIFETIME_LABEL}. ${TOKEN_RENEW_STEPS}`;
        reconnectBtn.classList.remove("hidden");
        openSettingsBtn.classList.remove("hidden");
        runnerHealthBanner.classList.remove("hidden");
        return;
    }
    if (health && isRunnerDegraded(health)) {
        runnerHealthText.textContent = `Antrean mengalami galat berulang: ${health.lastError}`;
        reconnectBtn.classList.add("hidden");
        openSettingsBtn.classList.add("hidden");
        runnerHealthBanner.classList.remove("hidden");
        return;
    }
    reconnectBtn.classList.add("hidden");
    openSettingsBtn.classList.add("hidden");
    runnerHealthBanner.classList.add("hidden");
    runnerHealthText.textContent = "";
}
/**
 * Kartu "Ekstensi butuh izin untuk membuka <host>" dengan tombol "Izinkan <host>", satu per host yang diblokir
 * izinnya. Tombol meminta izin lewat helper `requestAtsPermission` di handler klik (gestur pengguna): hanya
 * host di daftar ATS dan portal login yang bisa diminta, dan hanya satu host per klik.
 */
function renderPermissionNeeded(list) {
    permissionList.textContent = "";
    for (const { host } of list ?? []) {
        const card = document.createElement("div");
        card.className = "permission-card";
        const title = document.createElement("p");
        title.className = "permission-title";
        title.textContent = permissionCardText(host);
        const hint = document.createElement("p");
        hint.textContent = "Tanpa izin ini, lamaran yang sudah kamu setujui tidak bisa dibuka dan diisi di latar. Izin hanya untuk situs ini.";
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "primary-btn";
        btn.textContent = permissionButtonLabel(host);
        btn.addEventListener("click", () => void grantSitePermission(host, btn));
        card.append(title, hint, btn);
        permissionList.appendChild(card);
    }
}
async function refreshPermissionNeeded() {
    if (!connected)
        return;
    const res = await send({ type: "GET_PERMISSION_NEEDED" }).catch(() => null);
    if (res?.ok)
        renderPermissionNeeded(res.permissionNeeded);
}
/** Dipanggil langsung dari klik tombol Izinkan: permintaan izin harus jalan sebelum `await` lain agar gestur pengguna masih berlaku. */
async function grantSitePermission(host, btn) {
    btn.disabled = true;
    const perm = await requestAtsPermission(chrome.permissions, permissionUrlForHost(host));
    if (!perm.requested) {
        btn.disabled = false;
        setStatus(`Izin untuk ${host} tidak bisa diminta dari sini. Buka situs itu dan klik ikon Applify di toolbar.`, "warn");
        return;
    }
    if (!perm.granted) {
        btn.disabled = false;
        setStatus(`Izin untuk ${host} ditolak, jadi lamaran di situs itu belum bisa diisi di latar. Klik Izinkan ${host} lagi bila berubah pikiran.`, "warn");
        return;
    }
    // Service worker mencocokkan catatan dan langsung mengambil tugas yang tertahan, tanpa menunggu alarm.
    const res = await send({ type: "PERMISSION_CHANGED" }).catch(() => null);
    renderPermissionNeeded(res?.ok ? res.permissionNeeded : []);
    setStatus(`Izin untuk ${host} diberikan. Ekstensi segera melanjutkan lamaran yang tertahan.`, "ok");
}
function setStatus(message, tone = "") {
    if (!message) {
        statusBox.className = "banner hidden";
        statusBox.textContent = "";
        return;
    }
    statusBox.className = tone ? `banner ${tone}` : "banner";
    statusBox.textContent = message;
}
/** Satu pertanyaan sebagai isian: teks, area teks, pilihan dari `options`, atau ya/tidak. Wajib ditandai. */
function buildQuestionField(q, index) {
    const wrap = document.createElement("div");
    wrap.className = "q-field";
    const inputId = `q-input-${index}`;
    const label = document.createElement("label");
    label.className = "q-label";
    label.htmlFor = inputId;
    label.textContent = q.label;
    const mark = document.createElement("span");
    mark.className = q.required ? "q-req" : "q-opt";
    mark.textContent = q.required ? "wajib" : "opsional";
    label.appendChild(mark);
    wrap.appendChild(label);
    const widget = questionWidget(q);
    const remember = (value) => {
        if (value.trim())
            answerDrafts.set(q.key, value);
        else
            answerDrafts.delete(q.key);
    };
    if (widget === "select" || widget === "yesno") {
        const select = document.createElement("select");
        select.id = inputId;
        const blank = document.createElement("option");
        blank.value = "";
        blank.textContent = "Pilih jawaban";
        select.appendChild(blank);
        const choices = widget === "yesno" ? YES_NO_CHOICES : (q.options ?? []).map((o) => ({ label: o, value: o }));
        for (const choice of choices) {
            const option = document.createElement("option");
            option.value = choice.value;
            option.textContent = choice.label;
            select.appendChild(option);
        }
        select.value = answerDrafts.get(q.key) ?? "";
        select.addEventListener("change", () => remember(select.value));
        wrap.appendChild(select);
        return wrap;
    }
    const field = widget === "textarea" ? document.createElement("textarea") : document.createElement("input");
    field.id = inputId;
    field.maxLength = MAX_ANSWER_VALUE_LENGTH;
    if (field instanceof HTMLInputElement) {
        field.type = "text";
        field.autocomplete = "off";
    }
    field.value = answerDrafts.get(q.key) ?? "";
    field.addEventListener("input", () => remember(field.value));
    wrap.appendChild(field);
    return wrap;
}
function renderQuestions(list) {
    questionsList.textContent = "";
    selfFillList.textContent = "";
    const { answerable, selfFill } = splitQuestions(list);
    currentQuestions = answerable;
    if (answerable.length === 0 && selfFill.length === 0) {
        questionsBox.classList.add("hidden");
        return;
    }
    questionsBox.classList.remove("hidden");
    answerable.forEach((q, i) => questionsList.appendChild(buildQuestionField(q, i)));
    // Kolom rahasia (kata sandi, PIN, nomor kartu, dll.) tidak punya isian: pengguna mengisinya sendiri di halaman.
    for (const q of selfFill) {
        const li = document.createElement("li");
        li.textContent = q.label;
        selfFillList.appendChild(li);
    }
    selfFillBox.classList.toggle("hidden", selfFill.length === 0);
    saveAnswersBtn.classList.toggle("hidden", answerable.length === 0);
}
/** Ringkasan hasil pengisian: kolom terisi, berkas terpasang, pertanyaan tersisa, dan catatan atau galat berkas yang generik. */
function renderResult(runResult) {
    resultList.textContent = "";
    if (!runResult?.summary) {
        resultBox.classList.add("hidden");
        return;
    }
    for (const line of summarizeRunForPanel(runResult)) {
        const li = document.createElement("li");
        li.textContent = line;
        resultList.appendChild(li);
    }
    for (const problem of fileProblemsForPanel(runResult)) {
        const li = document.createElement("li");
        li.className = "problem";
        li.textContent = problem;
        resultList.appendChild(li);
    }
    resultBox.classList.remove("hidden");
}
/** Host lowongan persetujuan terpilih ada di daftar ATS atau portal login (JobStreet, Glints, Kalibrr, Dealls), jadi izin situsnya bisa diminta lewat klik tombol. */
const canRequestSitePermission = () => Boolean(selected?.applyUrl && atsPermissionPattern(selected.applyUrl));
/** Tombol isi/lanjut hanya aktif bila ada persetujuan terpilih, tab aktif bisa diakses, bukan LinkedIn, dan tidak sedang berjalan. */
function updateFillEnabled() {
    // Tab tanpa akses tetap boleh diisi bila lowongan ada di daftar ATS atau portal login: klik tombol meminta izin situsnya (gestur
    // pengguna), dan service worker tetap menolak (TabAccessError) bila tab aktif memang tidak terbaca.
    const tabOk = tabAccess === "ok" || (tabAccess === "no_access" && canRequestSitePermission());
    fillBtn.disabled = busy || !tabOk || !selected;
    resumeBtn.disabled = busy || !tabOk || !selected;
    saveAnswersBtn.disabled = busy || !selected;
}
function renderApprovals() {
    approvalsList.textContent = "";
    if (items.length === 0) {
        const empty = document.createElement("div");
        empty.className = "banner";
        empty.textContent = "Belum ada persetujuan aktif yang siap diisi. Setujui draf di Applify terlebih dahulu.";
        approvalsList.appendChild(empty);
        actionsPanel.classList.add("hidden");
        return;
    }
    if (!selected || !items.some((i) => i.approvalId === selected.approvalId)) {
        selected = items[0];
    }
    for (const item of items) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = `approval-item ${selected?.approvalId === item.approvalId ? "selected" : ""}`;
        const title = document.createElement("span");
        title.className = "approval-title";
        title.textContent = `${item.title} — ${item.company}`;
        const meta = document.createElement("span");
        meta.className = "approval-meta";
        meta.textContent = `Kanal: ${item.channel} (${item.platform})`;
        btn.appendChild(title);
        btn.appendChild(meta);
        btn.addEventListener("click", () => {
            // Ketikan jawaban milik lowongan sebelumnya tidak ikut ke lowongan lain.
            if (selected?.approvalId !== item.approvalId)
                answerDrafts.clear();
            selected = item;
            renderApprovals();
            updateActionButtons(null);
        });
        approvalsList.appendChild(btn);
    }
    actionsPanel.classList.remove("hidden");
    openTabBtn.disabled = !selected?.applyUrl;
    updateFillEnabled();
}
function updateActionButtons(runResult, prefix = "") {
    resumeBtn.classList.add("hidden");
    submitBtn.classList.add("hidden");
    questionsShownFor = runResult ? (selected?.approvalId ?? null) : null;
    questionsRestored = false;
    if (!runResult) {
        renderQuestions([]);
        renderResult(null);
        return;
    }
    if (runResult.blocked === "auth_required" || runResult.blocked === "captcha_blocked") {
        resumeBtn.classList.remove("hidden");
        setStatus(`${prefix}${runResult.note ?? "Selesaikan login atau CAPTCHA di tab, lalu lanjutkan."}`, "warn");
        renderQuestions([]);
        renderResult(null);
        return;
    }
    if (runResult.blocked) {
        setStatus(`${prefix}${runResult.note ?? "Halaman tidak dapat diisi otomatis."}`, "err");
        renderQuestions([]);
        renderResult(null);
        return;
    }
    // Formulir tidak muncul di tab (audit U2B-08): tanpa cabang ini pesan "Membaca formulir..." tertinggal di layar.
    if (runResult.formNotFound) {
        setStatus(`${prefix}${runResult.note ?? "Formulir lamaran tidak muncul di halaman."}`, "warn");
        renderQuestions([]);
        renderResult(null);
        return;
    }
    const summary = runResult.summary;
    // `questions` = pertanyaan dari server digabung dengan kolom pilihan yang tidak terisi (dihitung service worker).
    renderQuestions(runResult.questions ?? runResult.plan?.pendingQuestions ?? []);
    renderResult(runResult);
    if (summary && runResult.plan) {
        if (summary.missingRequiredCount === 0 && runResult.plan.submitControlId) {
            submitBtn.classList.remove("hidden");
            setStatus(`${prefix}Terisi ${summary.filledCount} kolom. Periksa isian di tab, lalu klik "Kirim Sekarang" jika siap.`, "ok");
        }
        else {
            setStatus(`${prefix}Terisi ${summary.filledCount} kolom. Masih ada ${summary.missingRequiredCount} kolom wajib yang perlu dicek di halaman.`, "warn");
        }
    }
}
/** Banner status tab aktif: LinkedIn, belum ada akses, atau formulir terisi yang menunggu di tab lain. */
function renderTabBanner(st) {
    const hide = () => {
        tabBanner.className = "banner hidden";
        tabBannerText.textContent = "";
        recheckTabBtn.classList.add("hidden");
    };
    if (!connected || !st) {
        hide();
        tabHost.classList.add("hidden");
        return;
    }
    if (st.host) {
        tabHost.textContent = `Tab aktif: ${st.host}`;
        tabHost.classList.remove("hidden");
    }
    else {
        tabHost.classList.add("hidden");
    }
    if (st.access === "linkedin") {
        tabBanner.className = "banner warn";
        tabBannerText.textContent = "Domain LinkedIn terdeteksi. Demi keamanan akun, lamaran LinkedIn hanya dilakukan secara manual.";
        recheckTabBtn.classList.add("hidden");
        return;
    }
    if (st.access !== "ok") {
        tabBanner.className = "banner warn";
        tabBannerText.textContent = `${NO_TAB_ACCESS_MESSAGE} Tab bawaan Chrome (chrome://...) tidak bisa diisi.`;
        recheckTabBtn.classList.remove("hidden");
        return;
    }
    if (st.session?.canSubmit && !st.session.targetOk) {
        tabBanner.className = "banner";
        tabBannerText.textContent = "Ada formulir terisi yang belum dikirim di tab lain. Pengiriman hanya bisa dari tab itu.";
        recheckTabBtn.classList.add("hidden");
        return;
    }
    hide();
}
/**
 * Samakan tombol Kirim dengan sesi pengisian yang tersimpan: tampil hanya bila tab aktif adalah tab yang tadi
 * diisi (dan origin-nya sama), hilang saat pengguna pindah tab. Gerbang yang sebenarnya tetap di service worker.
 */
function syncSubmitWithSession(session) {
    const eligible = Boolean(session?.canSubmit && session.targetOk && tabAccess === "ok");
    const match = eligible ? items.find((i) => i.approvalId === session.approvalId) : undefined;
    const shown = !submitBtn.classList.contains("hidden");
    if (match && !shown) {
        selected = match;
        renderApprovals();
        renderQuestions(session.pendingQuestions ?? []);
        questionsShownFor = match.approvalId;
        questionsRestored = true;
        submitBtn.classList.remove("hidden");
        setStatus(`Sesi pengisian dipulihkan (${session.filledCount} kolom terisi). Periksa isian di tab, lalu klik "Kirim Sekarang" jika siap.`, "ok");
        return;
    }
    let hid = false;
    if (!match && shown) {
        submitBtn.classList.add("hidden");
        setStatus("Tombol Kirim disembunyikan karena tab aktif bukan tab yang tadi diisi. Kembali ke tab itu untuk mengirim.", "warn");
        hid = true;
    }
    // Sesi yang belum siap kirim (mis. antrean latar berhenti karena ada pertanyaan) tetap menampilkan pertanyaannya
    // (audit U2B-08). Tombol Kirim tidak muncul: pengguna menjawab lalu klik "Simpan jawaban dan isi ulang".
    const view = { shownFor: questionsShownFor, restored: questionsRestored };
    const pending = pendingSessionToRestore(session, tabAccess, items.map((i) => i.approvalId), view);
    if (pending) {
        // Ketikan jawaban milik lowongan lain tidak ikut ke lowongan ini.
        if (selected?.approvalId !== pending.approvalId)
            answerDrafts.clear();
        selected = items.find((i) => i.approvalId === pending.approvalId) ?? selected;
        renderApprovals();
        renderQuestions(pending.pendingQuestions ?? []);
        questionsShownFor = pending.approvalId ?? null;
        questionsRestored = true;
        setStatus(`Applify butuh jawabanmu. Sesi pengisian dipulihkan (${pending.filledCount ?? 0} kolom terisi). Masih ada ${pending.pendingQuestions?.length ?? 0} pertanyaan. Jawab di bawah, lalu klik "Simpan jawaban dan isi ulang".`, "warn");
    }
    else if (restoredQuestionsStale(session, tabAccess, view)) {
        // Pertanyaan hasil pemulihan tidak dibiarkan usang di layar saat pengguna pindah ke tab yang tidak cocok.
        renderQuestions([]);
        renderResult(null);
        questionsShownFor = null;
        questionsRestored = false;
        if (!hid)
            setStatus("Pertanyaan disembunyikan karena tab aktif bukan tab yang tadi diisi. Kembali ke tab itu untuk menjawab.", "warn");
    }
}
function applyTabStatus(st) {
    tabAccess = st?.access === "ok" || st?.access === "linkedin" ? st.access : "no_access";
    renderTabBanner(st);
    updateFillEnabled();
    if (connected && !busy)
        syncSubmitWithSession(st?.session);
}
async function refreshTab() {
    if (!connected)
        return;
    const st = await send({ type: "GET_TAB_STATUS" }).catch(() => null);
    if (st?.ok)
        applyTabStatus(st);
}
let refreshTimer;
/** Tab bisa berubah beruntun (loading, redirect). Gabungkan jadi satu pemeriksaan. */
function scheduleRefreshTab() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => void refreshTab(), 120);
}
async function loadApprovals() {
    setStatus("Memuat persetujuan aktif...");
    const res = await send({ type: "LOAD_APPROVALS" });
    if (!res?.ok) {
        if (res?.code === "token_revoked" || res?.status === 401) {
            await send({ type: "CLEAR_CONFIG" }).catch(() => undefined);
            await init();
            setStatus(res?.error ?? "Token dicabut atau kedaluwarsa. Hubungkan ulang dengan token baru.", "err");
            return;
        }
        setStatus(res?.error ?? "Gagal memuat daftar persetujuan.", "err");
        items = [];
        renderApprovals();
        return;
    }
    items = res.items ?? [];
    setStatus("");
    renderApprovals();
}
async function init() {
    const cfg = await send({ type: "GET_CONFIG" });
    connected = Boolean(cfg?.connected);
    renderUnreported(cfg?.unreportedWarning);
    renderRunnerHealth(connected ? cfg?.runnerHealth : null);
    if (!connected) {
        renderPermissionNeeded([]);
        connectSection.classList.remove("hidden");
        appSection.classList.add("hidden");
        disconnectBtn.classList.add("hidden");
        renderTabBanner(null);
        // Pulihkan token yang sedang diketik bila panel tertutup atau dimuat ulang sebelum sempat dihubungkan.
        if (extTokenInput.value === "") {
            extTokenInput.value = await loadTokenDraft(chrome.storage.session, Date.now()).catch(() => "");
        }
        return;
    }
    connectSection.classList.add("hidden");
    appSection.classList.remove("hidden");
    disconnectBtn.classList.remove("hidden");
    // Bawaan aktif; hanya `false` eksplisit dari service worker yang mematikan saklar.
    bgFillToggle.checked = cfg?.backgroundFill !== false;
    visibleRunToggle.checked = cfg?.visibleRun !== false;
    renderPermissionNeeded(cfg?.permissionNeeded);
    await loadApprovals();
    // Sesudah daftar persetujuan termuat, supaya sesi pengisian tersimpan bisa dicocokkan dan tombol Kirim dipulihkan.
    applyTabStatus(cfg);
}
retryReportBtn.addEventListener("click", async () => {
    retryReportBtn.disabled = true;
    try {
        const res = await send({ type: "RETRY_UNREPORTED" });
        renderUnreported(res?.unreportedWarning);
        if (res?.ok && !res.unreportedWarning)
            setStatus("Laporan berhasil dikirim ke Applify.", "ok");
    }
    finally {
        retryReportBtn.disabled = false;
    }
});
// Tombol "Hubungkan ulang": tampilkan area token dan fokuskan kolomnya. Hubungkan lewat tombol yang sama
// (SAVE_CONFIG). Status 401 dibersihkan service worker begitu token baru tersimpan.
reconnectBtn.addEventListener("click", () => {
    connectSection.classList.remove("hidden");
    extTokenInput.focus();
    setStatus(`Belum punya token baru? ${TOKEN_RENEW_STEPS} Lalu tekan Hubungkan Ekstensi.`, "warn");
});
// Kesehatan runner berubah saat panel terbuka (misalnya 401 dari alarm poll): banner ikut diperbarui.
// `storage.onChanged` ada di runtime Chrome, tetapi tipe bawaan proyek tidak memuatnya, jadi dibaca lewat tipe sempit ini.
const storageChanged = chrome.storage.onChanged;
storageChanged?.addListener((changes, area) => {
    const change = changes[RUNNER_HEALTH_KEY];
    if (area !== "session" || !change)
        return;
    renderRunnerHealth(connected ? change.newValue : null);
});
// Simpan draf token selama diketik (storage.session, bukan local). Nilainya tidak pernah dicatat ke log.
extTokenInput.addEventListener("input", () => {
    void saveTokenDraft(chrome.storage.session, extTokenInput.value, Date.now()).catch(() => undefined);
});
connectBtn.addEventListener("click", async () => {
    connectBtn.disabled = true;
    try {
        // URL backend tetap di build: yang dikirim hanya token.
        const res = await send({ type: "SAVE_CONFIG", token: extTokenInput.value });
        if (!res?.ok) {
            setStatus(res?.error ?? "Gagal menghubungkan.", "err");
            return;
        }
        extTokenInput.value = "";
        await clearTokenDraft(chrome.storage.session).catch(() => undefined);
        await init();
        setStatus("Ekstensi terhubung.", "ok");
    }
    finally {
        connectBtn.disabled = false;
    }
});
disconnectBtn.addEventListener("click", async () => {
    // Service worker menghapus token dan sesi, dan mencabut semua izin situs opsional yang pernah disetujui.
    const res = await send({ type: "CLEAR_CONFIG" });
    await clearTokenDraft(chrome.storage.session).catch(() => undefined);
    extTokenInput.value = "";
    items = [];
    selected = null;
    answerDrafts.clear();
    renderQuestions([]);
    renderResult(null);
    await init();
    setStatus(res?.revokedOrigins > 0 ? "Koneksi diputus dan izin situs dicabut." : "Koneksi diputus.");
});
// Saklar "Isi otomatis di latar": nilainya disimpan service worker (panel tidak menyentuh storage sama sekali). Gagal: kembalikan.
bgFillToggle.addEventListener("change", async () => {
    const wanted = bgFillToggle.checked;
    bgFillToggle.disabled = true;
    try {
        const res = await send({ type: "SET_BG_FILL", enabled: wanted });
        if (!res?.ok) {
            bgFillToggle.checked = !wanted;
            setStatus(res?.error ?? "Gagal menyimpan pengaturan isi otomatis.", "err");
            return;
        }
        setStatus(wanted ? "Isi otomatis di latar aktif." : "Isi otomatis di latar dimatikan. Tidak ada tugas baru yang diambil.", wanted ? "ok" : "warn");
    }
    catch {
        bgFillToggle.checked = !wanted;
        setStatus("Gagal menyimpan pengaturan isi otomatis.", "err");
    }
    finally {
        bgFillToggle.disabled = false;
    }
});
// Saklar "Tampilkan tab saat mengisi": hanya CARA tab dibuka (aktif di jendelamu, atau tidak aktif di latar). Gagal: kembalikan.
visibleRunToggle.addEventListener("change", async () => {
    const wanted = visibleRunToggle.checked;
    visibleRunToggle.disabled = true;
    try {
        const res = await send({ type: "SET_VISIBLE_RUN", enabled: wanted });
        if (!res?.ok) {
            visibleRunToggle.checked = !wanted;
            setStatus(res?.error ?? "Gagal menyimpan pengaturan tampilan tab.", "err");
            return;
        }
        setStatus(wanted ? "Tab lowongan akan dibuka di jendelamu supaya kamu bisa melihat prosesnya." : "Tab lowongan akan dibuka di latar tanpa mengganggu tab aktifmu.", "ok");
    }
    catch {
        visibleRunToggle.checked = !wanted;
        setStatus("Gagal menyimpan pengaturan tampilan tab.", "err");
    }
    finally {
        visibleRunToggle.disabled = false;
    }
});
refreshBtn.addEventListener("click", () => loadApprovals());
recheckTabBtn.addEventListener("click", () => scheduleRefreshTab());
/** Pesan tentang izin situs sesudah permintaan (atau tidak adanya permintaan) untuk lowongan terpilih. */
function permissionNote(perm) {
    if (!perm.requested)
        return "Klik ikon Applify di toolbar pada tab itu untuk memberi akses";
    if (perm.granted)
        return "Izin situs ini sudah diberikan, jadi tab bisa diisi tanpa klik ikon";
    return "Izin situs ditolak, jadi klik ikon Applify di toolbar pada tab itu untuk memberi akses";
}
openTabBtn.addEventListener("click", async () => {
    const applyUrl = selected?.applyUrl;
    if (!applyUrl)
        return;
    // Minta izin situs lebih dulu, langsung di handler klik (gestur pengguna). Hanya bila host ada di daftar ATS atau portal login.
    const perm = await requestAtsPermission(chrome.permissions, applyUrl);
    await chrome.tabs.create({ url: applyUrl });
    setStatus(`Tab lowongan dibuka. ${permissionNote(perm)}. Setelah selesai masuk (login), klik Isi Formulir Sekarang.`, perm.granted ? "ok" : "");
});
async function runFillFlow() {
    if (!selected)
        return;
    const approval = selected;
    busy = true;
    updateFillEnabled();
    try {
        // Gestur klik masih berlaku di sini: minta izin situs (ATS atau portal login) sebelum langkah async lain. Host di luar daftar tidak diminta.
        const perm = await requestAtsPermission(chrome.permissions, approval.applyUrl);
        setStatus("Membaca formulir dan menyiapkan isian dari Applify...");
        const res = await send({ type: "RUN_FILL", approval });
        if (!res?.ok) {
            const denied = perm.requested && !perm.granted ? " Izin situs ditolak." : "";
            setStatus(`${res?.error ?? "Gagal mengisi formulir."}${denied}`, "err");
            if (res?.code === "no_tab_access")
                scheduleRefreshTab();
            return;
        }
        updateActionButtons(res);
        if (res.reportWarning)
            setStatus(`${statusBox.textContent ?? ""} ${res.reportWarning}`.trim(), "warn");
    }
    finally {
        busy = false;
        updateFillEnabled();
        scheduleRefreshTab();
    }
}
saveAnswersBtn.addEventListener("click", async () => {
    if (!selected)
        return;
    const approval = selected;
    const answers = collectAnswers(currentQuestions, answerDrafts);
    if (answers.length === 0) {
        setStatus("Isi minimal satu jawaban dulu.", "warn");
        return;
    }
    busy = true;
    updateFillEnabled();
    setStatus("Menyimpan jawaban dan mengisi ulang formulir...");
    try {
        // Service worker menyimpan jawaban, lalu mengisi ulang di tab dan frame yang sama dengan pengisian sebelumnya.
        const res = await send({ type: "SAVE_ANSWERS_REFILL", approval, answers });
        if (!res?.ok) {
            const saved = typeof res?.saved === "number";
            setStatus(res?.error ?? "Gagal menyimpan jawaban.", saved ? "warn" : "err");
            if (res?.code === "no_tab_access")
                scheduleRefreshTab();
            // Frame hilang atau berpindah situs: sesi dihapus di service worker, tombol Kirim tidak boleh tersisa.
            // Persetujuan sudah dipakai di tempat lain (terminal): tombol Kirim juga disembunyikan.
            if (res?.terminal || res?.code === "no_session" || res?.code === "frame_lost" || res?.code === "frame_origin_changed") {
                submitBtn.classList.add("hidden");
            }
            return;
        }
        for (const a of answers)
            answerDrafts.delete(a.key);
        updateActionButtons(res, `Jawaban tersimpan (${res.saved ?? answers.length}). `);
        if (res.reportWarning)
            setStatus(`${statusBox.textContent ?? ""} ${res.reportWarning}`.trim(), "warn");
    }
    finally {
        busy = false;
        updateFillEnabled();
        scheduleRefreshTab();
    }
});
fillBtn.addEventListener("click", runFillFlow);
resumeBtn.addEventListener("click", runFillFlow);
submitBtn.addEventListener("click", async () => {
    busy = true;
    submitBtn.disabled = true;
    updateFillEnabled();
    setStatus("Memverifikasi persetujuan dan kuota sebelum mengirim...");
    try {
        const res = await send({ type: "AUTHORIZED_SUBMIT" });
        if (!res?.ok) {
            // Persetujuan sudah dipakai atau sesi hilang: jangan biarkan tombol Kirim tetap tersedia.
            // Frame hilang atau berpindah situs: sesi sudah dihapus di service worker, pengguna harus mengisi ulang.
            const sessionGone = res?.code === "no_session" || res?.code === "frame_lost" || res?.code === "frame_origin_changed";
            if (res?.terminal || sessionGone)
                submitBtn.classList.add("hidden");
            setStatus(res?.error ?? "Pengiriman dibatalkan atau gagal.", "err");
            if (res?.terminal)
                renderUnreported((await send({ type: "GET_CONFIG" }))?.unreportedWarning);
            return;
        }
        // Formulir tidak jadi terkirim (audit U2B-02): galat validasi baru atau halaman kode keamanan. Persetujuan
        // dilepas, jadi ini bukan "mungkin terkirim" dan tidak boleh memunculkan peringatan jangan kirim ulang.
        if (res.outcome === "validation_error" || res.outcome === "needs_code") {
            const note = res.reported === false && res.warning ? ` ${res.warning}` : "";
            if (res.outcome === "validation_error") {
                // Sesi dipertahankan di service worker: tombol Kirim tetap ada agar pengguna bisa mengirim ulang sesudah memperbaiki.
                setStatus(`Formulir menolak kiriman. Perbaiki kolom yang bertanda galat di halaman, lalu klik Kirim Sekarang lagi.${note}`, "warn");
            }
            else {
                submitBtn.classList.add("hidden");
                setStatus(`Halaman meminta kode keamanan dari email. Masukkan kode itu lalu kirim langsung di halaman. Lamaran belum tercatat terkirim.${note}`, "warn");
            }
            if (res.reported === false)
                renderUnreported(res.warning);
            return;
        }
        submitBtn.classList.add("hidden");
        if (res.reported === false) {
            // Klik kirim sudah terjadi tetapi laporan gagal. Lamaran mungkin sudah terkirim: jangan kirim lagi.
            renderUnreported(res.warning);
            setStatus(res.warning, "err");
            return;
        }
        setStatus(res.outcome === "success"
            ? "Terkirim! Bukti dan status sudah dicatat di Applify."
            : "Tombol kirim sudah ditekan (perlu dicek). Periksa kotak masuk atau riwayat Persetujuan.", res.outcome === "success" ? "ok" : "warn");
        await loadApprovals();
    }
    finally {
        busy = false;
        submitBtn.disabled = false;
        updateFillEnabled();
        scheduleRefreshTab();
    }
});
// Panel mengikuti tab aktif: perbarui status saat tab berpindah, dimuat ulang, atau akses diberikan lewat klik ikon.
chrome.tabs.onActivated.addListener((info) => {
    if (windowId === undefined || info.windowId === windowId)
        scheduleRefreshTab();
});
chrome.tabs.onUpdated.addListener((_tabId, change, tab) => {
    if (!tab?.active)
        return;
    if (windowId !== undefined && tab.windowId !== undefined && tab.windowId !== windowId)
        return;
    if (change.status || change.url)
        scheduleRefreshTab();
});
chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "TAB_ACCESS_CHANGED")
        scheduleRefreshTab();
    // Antrean latar berhenti menunggu jawaban di sebuah tab: muat ulang pertanyaan tab aktif (tab itu baru dibawa ke depan).
    if (msg?.type === "NEEDS_INPUT_CHANGED")
        scheduleRefreshTab();
    // Service worker mencatat atau menghapus situs yang butuh izin (poll, izin diberikan, atau Putus).
    if (msg?.type === "PERMISSION_NEEDED_CHANGED")
        void refreshPermissionNeeded();
    return false;
});
// Izin situs yang diberikan atau dicabut mengubah apakah URL tab terbaca (akses tab), jadi hitung ulang statusnya.
chrome.permissions.onAdded.addListener(() => scheduleRefreshTab());
chrome.permissions.onRemoved.addListener(() => scheduleRefreshTab());
window.addEventListener("focus", scheduleRefreshTab);
void (async () => {
    windowId = await chrome.windows
        .getCurrent()
        .then((w) => w.id)
        .catch(() => undefined);
    await init();
})();
