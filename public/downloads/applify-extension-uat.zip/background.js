// AUTO-GENERATED from project/shared/domains.json via project/scripts/sync-domains.mjs. DO NOT EDIT BY HAND.
const KNOWN_ATS_DOMAINS = [
    "greenhouse.io",
    "lever.co",
    "ashbyhq.com",
    "workable.com",
    "smartrecruiters.com",
    "recruitee.com",
    "breezy.hr",
    "bamboohr.com",
    "jazzhr.com",
    "applytojob.com",
    "personio.de",
    "personio.com",
    "teamtailor.com",
    "pinpointhq.com",
    "myworkdayjobs.com",
    "icims.com",
    "jobvite.com",
    "taleo.net",
    "successfactors.com",
    "successfactors.eu",
    "rippling-ats.com",
    "keka.com",
    "freshteam.com"
];
const EXTENSION_LOGIN_PORTAL_DOMAINS = [
    "jobstreet.com",
    "jobstreet.co.id",
    "glints.com",
    "kalibrr.com",
    "kalibrr.id",
    "dealls.com"
];
const EXTERNAL_AUTH_PORTAL_MAP = {
    "jobstreet.com": [
        "login.seek.com",
        "auth.seek.com"
    ],
    "jobstreet.co.id": [
        "login.seek.com",
        "auth.seek.com"
    ]
};

/**
 * Penjaga keamanan & domain untuk Ekstensi Browser Chrome/Edge Applify.
 *
 * Aturan utama:
 *   - Lowongan/domain LinkedIn selalu ditolak (manual-only).
 *   - Hanya URL http(s) yang sah; remote API wajib HTTPS kecuali localhost/127.0.0.1.
 *   - Token wajib berawalan `ext_tok_v1.` (menolak JWT Supabase penuh agar pemisahan scope terjaga).
 *   - Tangkapan layar `captureVisibleTab` hanya diizinkan pada tab lowongan/ATS terkait.
 */
const EXTENSION_TOKEN_PREFIX = "ext_tok_v1.";
function parseHttpUrl(raw) {
    if (typeof raw !== "string")
        return null;
    const trimmed = raw.trim();
    if (!trimmed)
        return null;
    try {
        const u = new URL(trimmed);
        if (u.protocol !== "http:" && u.protocol !== "https:")
            return null;
        return u;
    }
    catch {
        return null;
    }
}
function isLinkedInUrl(rawUrl) {
    const u = parseHttpUrl(rawUrl);
    if (!u)
        return false;
    const h = u.hostname.toLowerCase().replace(/^www\./, "");
    return h === "linkedin.com" || h.endsWith(".linkedin.com");
}
function normalizeServerUrl(raw) {
    const u = parseHttpUrl(raw);
    if (!u)
        return null;
    const isLocal = u.hostname === "localhost" || u.hostname === "127.0.0.1";
    if (u.protocol === "http:" && !isLocal)
        return null;
    return u.origin + u.pathname.replace(/\/+$/, "");
}
function isValidExtensionTokenFormat(token) {
    if (typeof token !== "string")
        return false;
    const trimmed = token.trim();
    if (!trimmed.startsWith(EXTENSION_TOKEN_PREFIX))
        return false;
    const parts = trimmed.split(".");
    return parts.length === 3 && parts[1].length > 8 && parts[2].length > 8;
}
function isScreenshotTabAllowed(tabUrl, expectedApplyUrl) {
    const tab = parseHttpUrl(tabUrl);
    if (!tab || isLinkedInUrl(tab.toString()))
        return false;
    const tabHost = tab.hostname.toLowerCase().replace(/^www\./, "");
    if (KNOWN_ATS_DOMAINS.some((d) => tabHost === d || tabHost.endsWith(`.${d}`))) {
        return true;
    }
    const exp = parseHttpUrl(expectedApplyUrl);
    if (!exp)
        return false;
    if (tab.origin === exp.origin)
        return true;
    const expHost = exp.hostname.toLowerCase().replace(/^www\./, "");
    return tabHost === expHost || tabHost.endsWith(`.${expHost}`) || expHost.endsWith(`.${tabHost}`);
}

/**
 * Status kesehatan runner antrean, disimpan di `chrome.storage.session` supaya panel bisa menampilkannya.
 *
 * - Token kedaluwarsa atau dicabut (401) menghentikan polling antrean sampai pengguna menghubungkan ulang
 *   (`clearRunnerAuthExpired`, dipanggil saat token baru tersimpan). Tanpa ini, poll tiap menit menghasilkan 401
 *   yang sama terus-menerus.
 * - Galat lain hanya dicatat (`lastError`, `consecutiveFailures`) supaya panel bisa menjelaskannya.
 * - Fungsi di bagian "murni" tidak menyentuh storage, jadi mudah diuji.
 *
 * Nilai token tidak pernah masuk ke status ini; hanya sidik jari 32-bit (`tokenId`) untuk menolak 401 milik token lama.
 */
const RUNNER_HEALTH_KEY = "applify_runner_health";
/** Jeda cadangan setelah 401. Penghentian utama tetap `authExpired`, yang hanya dicabut oleh token baru. */
const AUTH_BACKOFF_MS = 60 * 60 * 1000;
const AUTH_EXPIRED_MESSAGE = "Sambungan ke Applify kedaluwarsa. Buat token baru di Pengaturan Applify, lalu hubungkan ulang.";
const MAX_ERROR_LENGTH = 200;
const AUTH_CODES = new Set(["unauthorized", "token_expired", "token_revoked"]);
/** Sidik jari 32-bit (FNV-1a) token, 8 digit heksadesimal. Hanya untuk membandingkan dua token, bukan untuk keamanan. */
function tokenFingerprint(token) {
    let hash = 0x811c9dc5;
    for (let i = 0; i < token.length; i++) {
        hash ^= token.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return hash.toString(16).padStart(8, "0");
}
const EMPTY_RUNNER_HEALTH = {
    authExpired: false,
    lastError: null,
    lastErrorCode: null,
    lastHeartbeatAt: null,
    consecutiveFailures: 0,
    backoffUntilMs: null,
    lockLease: null,
};
// ---------- murni ----------
function isRunnerAuthError(err) {
    if (!err)
        return false;
    if (err.status === 401)
        return true;
    return typeof err.code === "string" && AUTH_CODES.has(err.code);
}
function recordRunnerSuccess(h, nowMs, opts = {}) {
    return {
        ...h,
        lastError: null,
        lastErrorCode: null,
        consecutiveFailures: 0,
        ...(opts.heartbeat ? { lastHeartbeatAt: nowMs } : {}),
    };
}
/** 401 dari token yang bukan token tersimpan sekarang: permintaan lama yang baru kembali sesudah pengguna menyimpan token baru. */
function isStaleAuthError(h, err) {
    return (isRunnerAuthError(err) &&
        typeof err?.tokenId === "string" &&
        typeof h.tokenId === "string" &&
        err.tokenId !== h.tokenId);
}
function recordRunnerError(h, err, nowMs) {
    // Token sudah diganti sejak permintaan ini dikirim: 401-nya milik token lama dan diabaikan sepenuhnya.
    if (isStaleAuthError(h, err))
        return h;
    const code = typeof err?.code === "string" && err.code ? err.code : null;
    const status = typeof err?.status === "number" ? String(err.status) : null;
    const message = typeof err?.message === "string" && err.message ? err.message : "Galat tidak dikenal.";
    const base = {
        ...h,
        consecutiveFailures: h.consecutiveFailures + 1,
        lastError: clip$1(message),
        lastErrorCode: code ?? status,
    };
    if (!isRunnerAuthError(err))
        return base;
    return {
        ...base,
        authExpired: true,
        backoffUntilMs: nowMs + AUTH_BACKOFF_MS,
        lastError: AUTH_EXPIRED_MESSAGE,
        lastErrorCode: code ?? "unauthorized",
    };
}
/** Dipanggil saat token baru tersimpan atau koneksi ulang berhasil. `tokenId`: sidik jari token baru (`tokenFingerprint`). */
function clearRunnerAuthExpired(h, tokenId) {
    return {
        ...h,
        authExpired: false,
        backoffUntilMs: null,
        consecutiveFailures: 0,
        lastError: null,
        lastErrorCode: null,
        ...(typeof tokenId === "string" && tokenId ? { tokenId } : {}),
    };
}
/** `true` bila polling antrean harus dilewati: sambungan kedaluwarsa, atau masih dalam jeda cadangan. */
function shouldSkipPollForHealth(h, nowMs) {
    if (h.authExpired)
        return true;
    return h.backoffUntilMs !== null && nowMs < h.backoffUntilMs;
}
function clip$1(text) {
    return text.length > MAX_ERROR_LENGTH ? `${text.slice(0, MAX_ERROR_LENGTH - 3)}...` : text;
}
// ---------- storage ----------
/** Nilai mentah dari storage menjadi `RunnerHealth` yang aman. Bentuk yang rusak dianggap kosong. */
function normalizeRunnerHealth(raw) {
    if (!raw || typeof raw !== "object")
        return { ...EMPTY_RUNNER_HEALTH };
    const r = raw;
    const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : null);
    const str = (v) => (typeof v === "string" && v ? v : null);
    const lease = r.lockLease;
    const failures = num(r.consecutiveFailures);
    const tokenId = str(r.tokenId);
    return {
        ...(tokenId ? { tokenId } : {}),
        authExpired: r.authExpired === true,
        lastError: str(r.lastError),
        lastErrorCode: str(r.lastErrorCode),
        lastHeartbeatAt: num(r.lastHeartbeatAt),
        consecutiveFailures: failures !== null && failures >= 0 ? Math.floor(failures) : 0,
        backoffUntilMs: num(r.backoffUntilMs),
        lockLease: lease && typeof lease.holderId === "string" && typeof lease.expiresAtMs === "number"
            ? { holderId: lease.holderId, expiresAtMs: lease.expiresAtMs }
            : null,
    };
}
/** Baca status. Tanpa area (tes, atau `storage.session` tidak tersedia) atau galat baca: status kosong. */
async function loadRunnerHealth(area) {
    if (!area)
        return { ...EMPTY_RUNNER_HEALTH };
    try {
        const res = await area.get(RUNNER_HEALTH_KEY);
        return normalizeRunnerHealth(res?.[RUNNER_HEALTH_KEY]);
    }
    catch {
        return { ...EMPTY_RUNNER_HEALTH };
    }
}
/** Tulisan dibuat berurutan supaya dua pembaruan yang datang bersamaan tidak saling menimpa. */
let writeChain = Promise.resolve();
/**
 * Baca-ubah-tulis status. Galat tulis ditelan: status kesehatan hanya petunjuk dan tidak boleh menghentikan antrean.
 */
function updateRunnerHealth(area, update) {
    const run = writeChain.then(async () => {
        const current = await loadRunnerHealth(area);
        const next = update(current);
        if (area)
            await area.set({ [RUNNER_HEALTH_KEY]: next }).catch(() => undefined);
        return next;
    });
    writeChain = run.catch(() => undefined);
    return run;
}

/**
 * Berkas lamaran yang dipasang ke input file halaman: jenis, batas ukuran, dan pembersihan metadata dari respons backend.
 *
 * Berkas hanya hidup di memori service worker dan skrip konten selama satu pengisian. Tidak pernah ditulis ke
 * `chrome.storage` (session maupun local).
 */
const FILE_KINDS = ["resume", "cover_letter", "transcript", "portfolio"];
/** Batas satu berkas dari endpoint dokumen: 5 MB (5 MiB). Lebih besar ditolak sebelum dan sesudah dibaca. */
const MAX_DOCUMENT_BYTES = 5 * 1024 * 1024;
const emptyFilesAttached = () => ({ resume: false, cover_letter: false, transcript: false, portfolio: false });
/** Nama jenis berkas untuk pesan ke pengguna. */
const FILE_KIND_LABELS = {
    resume: "CV",
    cover_letter: "surat lamaran",
    transcript: "transkrip",
    portfolio: "portofolio",
};
function isFileKind(value) {
    return typeof value === "string" && FILE_KINDS.includes(value);
}
/** Id kontrol yang dibuat ekstensi (`applify_c_3`). Pola ketat supaya id dari luar tidak merusak selector. */
const CONTROL_ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
/**
 * Rapikan `fileTargets` dari backend: buang bentuk yang salah, satu kontrol hanya untuk satu jenis, satu jenis hanya
 * untuk satu kontrol (yang pertama menang).
 */
function normalizeFileTargets(raw) {
    if (!Array.isArray(raw))
        return [];
    const out = [];
    const usedControls = new Set();
    const usedKinds = new Set();
    for (const item of raw) {
        const controlId = item?.controlId;
        const kind = item?.kind;
        if (typeof controlId !== "string" || !CONTROL_ID_RE.test(controlId) || !isFileKind(kind))
            continue;
        if (usedControls.has(controlId) || usedKinds.has(kind))
            continue;
        usedControls.add(controlId);
        usedKinds.add(kind);
        out.push({ controlId, kind });
    }
    return out;
}
/** Nama berkas dari header `Content-Disposition` (`filename*` didahulukan), atau null. Belum disanitasi. */
function parseDispositionFilename(header) {
    if (!header)
        return null;
    const star = /filename\*\s*=\s*([^;]+)/i.exec(header);
    if (star) {
        const m = /^\s*[A-Za-z0-9._-]+'[^']*'(.*)$/.exec(star[1].trim());
        if (m) {
            try {
                return decodeURIComponent(m[1].trim());
            }
            catch {
                // Percent-encoding rusak: coba bentuk `filename=` biasa di bawah.
            }
        }
    }
    const quoted = /filename\s*=\s*"((?:[^"\\]|\\.)*)"/i.exec(header);
    if (quoted)
        return quoted[1].replace(/\\(.)/g, "$1");
    const bare = /filename\s*=\s*([^;]+)/i.exec(header);
    return bare ? bare[1].trim() : null;
}
const MAX_FILENAME_LENGTH = 120;
/** Ekstensi bawaan menurut MIME, untuk nama cadangan. */
const EXTENSION_BY_MIME = {
    "application/pdf": ".pdf",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "image/png": ".png",
    "image/jpeg": ".jpg",
};
const FALLBACK_BASENAME = {
    resume: "resume",
    cover_letter: "cover-letter",
    transcript: "transcript",
    portfolio: "portfolio",
};
function fallbackFilename(kind, mimeType) {
    return `${FALLBACK_BASENAME[kind]}${EXTENSION_BY_MIME[mimeType] ?? ""}`;
}
/**
 * Nama berkas aman untuk `new File(...)`: tanpa path, karakter kontrol, karakter pengarah teks (spoofing ekstensi),
 * titik atau spasi di ujung, dan dipotong 120 karakter dengan ekstensi dipertahankan. Kosong jadi nama cadangan.
 */
function sanitizeFilename(raw, kind, mimeType) {
    const fallback = fallbackFilename(kind, mimeType);
    if (typeof raw !== "string")
        return fallback;
    let name = raw.split(/[\\/]/).pop() ?? "";
    name = name
        // eslint-disable-next-line no-control-regex
        .replace(/[\u0000-\u001f\u007f-\u009f]/g, "")
        .replace(/[​-‏‪-‮⁦-⁩﻿]/g, "")
        .replace(/[<>:"|?*;]/g, "_")
        .replace(/\s+/g, " ")
        .replace(/^[.\s]+/, "")
        .replace(/[.\s]+$/, "");
    if (!/[\p{L}\p{N}]/u.test(name))
        return fallback;
    if (name.length > MAX_FILENAME_LENGTH) {
        const dot = name.lastIndexOf(".");
        const ext = dot > 0 && name.length - dot <= 10 ? name.slice(dot) : "";
        name = name.slice(0, MAX_FILENAME_LENGTH - ext.length) + ext;
    }
    return name;
}
/** Jenis media dari `Content-Type` (tanpa parameter), atau `application/octet-stream` bila tidak sah. */
function parseMimeType(header) {
    const base = String(header ?? "")
        .split(";")[0]
        .trim()
        .toLowerCase();
    return /^[a-z0-9][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*$/.test(base) ? base : "application/octet-stream";
}
function bytesToBase64$1(bytes) {
    let bin = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk)
        bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
    return btoa(bin);
}

class ExtensionApiError extends Error {
    status;
    code;
    /** Sidik jari token yang dipakai permintaan ini (bukan token). Dipakai runner menolak 401 milik token yang sudah diganti. */
    tokenId;
    constructor(status, code, message, tokenId) {
        super(message);
        this.status = status;
        this.code = code;
        this.tokenId = tokenId;
    }
}
/**
 * Backend membalas 409 `{ error: "lease_lost" }` bila browser lain sudah mengambil tugas antrean ini. Tugas itu
 * bukan lagi milik ekstensi ini: berhenti, tutup tab antrean, dan jangan melapor.
 */
function isLeaseLostError(err) {
    const e = err;
    return e?.status === 409 && (e?.code === "lease_lost" || e?.message === "lease_lost");
}
/**
 * Batas waktu satu permintaan ke backend. Tanpa batas, fetch yang menggantung membuat antrean menganggap tugas masih
 * berjalan (flag `busy`) dan tidak pernah mengambil tugas lagi sampai service worker dimatikan Chrome.
 */
const REQUEST_TIMEOUT_MS = 15_000;
/**
 * `plan-form` memakai batas sendiri: backend menjalankan kueri DB lalu sampai 12 detik menunggu LLM, jadi 15 detik terlalu
 * sempit dan memutus permintaan yang sebenarnya masih berjalan.
 */
const PLAN_FORM_TIMEOUT_MS = 25_000;
/** Unduh berkas lamaran (maksimal 5 MB) lewat backend. Tanpa batas, unduhan yang macet menahan flag `busy` runner selamanya. */
const DOCUMENT_TIMEOUT_MS = 30_000;
/** Galat batas waktu dari `AbortSignal.timeout`, baik saat menunggu header maupun saat membaca badan. */
function isTimeoutAbort(err) {
    return err?.name === "TimeoutError";
}
function requestTimeoutError() {
    return new ExtensionApiError(0, "request_timeout", "Permintaan ke Applify melewati batas waktu. Coba lagi sebentar.");
}
function timeoutSignal(ms) {
    return typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function" ? AbortSignal.timeout(ms) : undefined;
}
class ExtensionApiClient {
    serverUrl;
    token;
    fetchImpl;
    timeoutMs;
    planFormTimeoutMs;
    documentTimeoutMs;
    // Bawaan dibungkus: `fetch` yang dipanggil sebagai method (`this.fetchImpl(...)`) melempar
    // "TypeError: Illegal invocation" di service worker Chrome, dan itu tampil sebagai galat jaringan.
    constructor(serverUrl, token, fetchImpl = (input, init) => fetch(input, init), timeoutMs = REQUEST_TIMEOUT_MS, timeouts = {}) {
        this.serverUrl = serverUrl;
        this.token = token;
        this.fetchImpl = fetchImpl;
        this.timeoutMs = timeoutMs;
        this.planFormTimeoutMs = timeouts.planForm ?? PLAN_FORM_TIMEOUT_MS;
        this.documentTimeoutMs = timeouts.document ?? DOCUMENT_TIMEOUT_MS;
    }
    base() {
        const clean = normalizeServerUrl(this.serverUrl);
        if (!clean)
            throw new ExtensionApiError(400, "invalid_server_url", "URL server Applify tidak valid.");
        return clean;
    }
    async requestRaw(path, init = {}, timeoutMs = this.timeoutMs) {
        try {
            return await this.fetchImpl(`${this.base()}${path}`, {
                ...init,
                credentials: "omit",
                signal: init.signal ?? timeoutSignal(timeoutMs),
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${this.token}`,
                    ...(init.headers ?? {}),
                },
            });
        }
        catch (err) {
            if (isTimeoutAbort(err))
                throw requestTimeoutError();
            throw err;
        }
    }
    /** Galat dari respons non-2xx, ditandai sidik jari token yang dipakai (lihat `ExtensionApiError.tokenId`). */
    responseError(status, json) {
        return new ExtensionApiError(status, json?.code, json?.error ?? `HTTP ${status}`, tokenFingerprint(this.token));
    }
    /** Baca badan respons. Batas waktu yang habis di tengah badan juga dilaporkan sebagai `request_timeout`. */
    async readBody(res) {
        try {
            return await res.text();
        }
        catch (err) {
            if (isTimeoutAbort(err))
                throw requestTimeoutError();
            throw err;
        }
    }
    async request(path, init = {}, timeoutMs = this.timeoutMs) {
        const res = await this.requestRaw(path, init, timeoutMs);
        const text = await this.readBody(res);
        let json = {};
        try {
            json = text ? JSON.parse(text) : {};
        }
        catch {
            json = {};
        }
        if (!res.ok) {
            throw this.responseError(res.status, json);
        }
        return json;
    }
    /**
     * Ambil satu berkas lamaran lewat backend (ekstensi tidak butuh izin host Supabase). Galat endpoint dilempar sebagai
     * `ExtensionApiError` dengan kode backend (`document_not_found` 404, `not_approved` 409, `too_large` 413).
     * Berkas lebih dari 5 MB ditolak lewat `Content-Length` sebelum dibaca, dan dicek lagi sesudah dibaca.
     */
    async fetchDocument(approvalId, kind) {
        if (!isFileKind(kind))
            throw new ExtensionApiError(400, "invalid_kind", "Jenis berkas tidak dikenal.");
        let res;
        try {
            res = await this.fetchImpl(`${this.base()}/api/extension/documents/${encodeURIComponent(approvalId)}/${kind}`, {
                method: "GET",
                credentials: "omit",
                signal: timeoutSignal(this.documentTimeoutMs),
                headers: { Authorization: `Bearer ${this.token}` },
            });
        }
        catch (err) {
            if (isTimeoutAbort(err))
                throw requestTimeoutError();
            throw err;
        }
        if (!res.ok) {
            let json = {};
            try {
                json = JSON.parse(await this.readBody(res));
            }
            catch (err) {
                if (err?.code === "request_timeout")
                    throw err;
                json = {};
            }
            throw this.responseError(res.status, json);
        }
        const declared = Number(res.headers.get("content-length"));
        if (Number.isFinite(declared) && declared > MAX_DOCUMENT_BYTES) {
            throw new ExtensionApiError(413, "too_large", "Berkas lebih dari 5 MB.");
        }
        let buffer;
        try {
            buffer = await res.arrayBuffer();
        }
        catch (err) {
            if (isTimeoutAbort(err))
                throw requestTimeoutError();
            throw err;
        }
        const bytes = new Uint8Array(buffer);
        if (bytes.length > MAX_DOCUMENT_BYTES)
            throw new ExtensionApiError(413, "too_large", "Berkas lebih dari 5 MB.");
        if (bytes.length === 0)
            throw new ExtensionApiError(404, "document_not_found", "Berkas kosong.");
        const mimeType = parseMimeType(res.headers.get("content-type"));
        const filename = sanitizeFilename(parseDispositionFilename(res.headers.get("content-disposition")), kind, mimeType);
        return { kind, filename, mimeType, size: bytes.length, base64: bytesToBase64$1(bytes) };
    }
    /** Simpan jawaban pertanyaan dari panel ke `user_form_answers` (validasi persetujuan dan pemilik di backend). */
    saveAnswers(payload) {
        return this.request("/api/extension/answers", {
            method: "POST",
            body: JSON.stringify(payload),
        });
    }
    fetchPendingApprovals() {
        return this.request("/api/extension/pending-approvals", { method: "GET" });
    }
    planForm(payload) {
        if (isLinkedInUrl(payload.pageUrl)) {
            throw new ExtensionApiError(403, "linkedin_manual_only", "Ekstensi dinonaktifkan di domain LinkedIn.");
        }
        return this.request("/api/extension/plan-form", { method: "POST", body: JSON.stringify(payload) }, this.planFormTimeoutMs);
    }
    /** Ambil satu tugas antrean `extension_apply` milik pengguna (204 jika kosong -> null). */
    async claimNextJob(claimer) {
        const res = await this.requestRaw("/api/extension/jobs/claim", {
            method: "POST",
            body: JSON.stringify(claimer ? { claimer } : {}),
        });
        if (res.status === 204)
            return null;
        const text = await this.readBody(res);
        let json = {};
        try {
            json = text ? JSON.parse(text) : {};
        }
        catch {
            json = {};
        }
        if (!res.ok) {
            throw this.responseError(res.status, json);
        }
        return (json?.job ?? null);
    }
    /** Tanpa `leaseId` (backend lama) badan permintaan tetap `{}`. Dengan `leaseId`: `{ lease_id }`. */
    heartbeatJob(queueJobId, leaseId) {
        return this.request(`/api/extension/jobs/${encodeURIComponent(queueJobId)}/heartbeat`, {
            method: "POST",
            body: JSON.stringify(leaseId ? { lease_id: leaseId } : {}),
        });
    }
    releaseJob(queueJobId, opts = {}) {
        const { leaseId, ...rest } = opts;
        return this.request(`/api/extension/jobs/${encodeURIComponent(queueJobId)}/release`, {
            method: "POST",
            body: JSON.stringify(leaseId ? { ...rest, lease_id: leaseId } : rest),
        });
    }
    authorizeSubmit(payload) {
        if (isLinkedInUrl(payload.pageUrl)) {
            throw new ExtensionApiError(403, "linkedin_manual_only", "Pengiriman otomatis dilarang di LinkedIn.");
        }
        return this.request("/api/extension/authorize-submit", {
            method: "POST",
            body: JSON.stringify(payload),
        });
    }
    reportRun(payload) {
        if (isLinkedInUrl(payload.pageUrl) || isLinkedInUrl(payload.loginUrl ?? null)) {
            throw new ExtensionApiError(403, "linkedin_manual_only", "Pelaporan di domain LinkedIn tidak diizinkan.");
        }
        return this.request("/api/extension/report-run", {
            method: "POST",
            body: JSON.stringify(payload),
        });
    }
}

/** Semua domain yang izin situsnya dimiliki ekstensi sejak pasang: ATS yang dikenal ditambah portal login. */
const EXTENSION_HOST_DOMAINS = [...KNOWN_ATS_DOMAINS, ...EXTENSION_LOGIN_PORTAL_DOMAINS];
/**
 * Google Forms (lowongan di luar portal sering memakai tautan `forms.gle`). Bukan ATS dan bukan portal login, jadi
 * tidak masuk daftar domain bersama (`domains.json`): ini kasus tersendiri dengan izin yang dibatasi PATH.
 * `docs.google.com` juga rumah Docs, Sheets, dan Drive, jadi izinnya hanya `https://docs.google.com/forms/*`.
 * `forms.gle` hanya pengalih HTTP ke sana: tidak butuh izin sendiri (tab berakhir di docs.google.com).
 */
const GOOGLE_FORMS_HOST = "docs.google.com";
const GOOGLE_FORMS_SHORT_HOST = "forms.gle";
const GOOGLE_FORMS_PERMISSION_PATTERN = `https://${GOOGLE_FORMS_HOST}/forms/*`;
/** URL minimal yang dicakup `GOOGLE_FORMS_PERMISSION_PATTERN`, untuk meminta atau memeriksa izinnya per host. */
const GOOGLE_FORMS_PERMISSION_URL = `https://${GOOGLE_FORMS_HOST}/forms/`;
/**
 * URL Google Forms yang dicakup izin di atas: `forms.gle/<kode>` (pengalih), atau `docs.google.com/forms/...`. Hanya
 * HTTPS. Path `/u/0/forms/` dan `/a/<domain>/forms/` (akun Workspace) tidak dicakup pola `/forms/*`, jadi bukan cocok.
 */
function isGoogleFormsUrl(rawUrl) {
    const url = parseHttpUrl(rawUrl);
    if (!url || url.protocol !== "https:")
        return false;
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (host === GOOGLE_FORMS_SHORT_HOST)
        return url.pathname.length > 1;
    return host === GOOGLE_FORMS_HOST && (url.pathname === "/forms" || url.pathname.startsWith("/forms/"));
}
/** Pola untuk memeriksa akses (`permissions.contains`) ke sebuah URL: Google Forms memakai pola path, lainnya origin penuh. Null bila bukan http(s). */
function accessPatternForUrl(rawUrl) {
    const url = parseHttpUrl(rawUrl);
    if (!url)
        return null;
    return isGoogleFormsUrl(url.href) ? GOOGLE_FORMS_PERMISSION_PATTERN : `${url.origin}/*`;
}
const isIpLike = (host) => /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(":") || host.startsWith("[");
/**
 * Host `rawHost` adalah salah satu domain di daftar atau subdomainnya (aturan yang sama dengan `hostMatchesDomain`
 * di backend). Bawaannya HANYA ATS (`KNOWN_ATS_DOMAINS`), jadi `id.jobstreet.com` bukan ATS di sini, sama seperti di
 * backend. Untuk "situs yang boleh diminta izinnya" (ATS atau portal login) pakai `hostIsExtensionSite`.
 */
function hostIsKnownAts(rawHost, domains = KNOWN_ATS_DOMAINS) {
    const host = String(rawHost ?? "")
        .trim()
        .toLowerCase()
        .replace(/\.$/, "");
    if (!host || isIpLike(host))
        return false;
    return domains.some((d) => host === d || host.endsWith(`.${d}`));
}
/** Host `rawHost` boleh diminta izin situsnya: ATS yang dikenal atau portal login, termasuk subdomain. */
function hostIsExtensionSite(rawHost) {
    return hostIsKnownAts(rawHost, EXTENSION_HOST_DOMAINS);
}
/**
 * Pola izin untuk SATU host lowongan: `https://<host persis>/*`, atau null bila host itu bukan ATS atau portal login
 * di daftar. Hanya HTTPS. Dipakai untuk `chrome.permissions.request`, sehingga host di luar daftar tidak pernah
 * diminta izinnya (tetap lewat `activeTab`).
 *
 * Pengecualian tersendiri: Google Forms (`forms.gle/<kode>` atau `docs.google.com/forms/...`) memakai pola path
 * `GOOGLE_FORMS_PERMISSION_PATTERN`, bukan host persis, supaya Docs, Sheets, dan Drive tidak ikut terbuka. Hanya
 * berlaku untuk daftar bawaan; daftar domain khusus (tes) tidak pernah menerimanya.
 */
function atsPermissionPattern(rawUrl, domains = EXTENSION_HOST_DOMAINS) {
    const url = parseHttpUrl(rawUrl);
    if (!url || url.protocol !== "https:")
        return null;
    if (domains === EXTENSION_HOST_DOMAINS && isGoogleFormsUrl(url.href))
        return GOOGLE_FORMS_PERMISSION_PATTERN;
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (!hostIsKnownAts(host, domains))
        return null;
    return `https://${host}/*`;
}
/** Daftar seluruh host autentikasi eksternal dikenal milik portal (mis. `login.seek.com` untuk JobStreet). */
const EXTERNAL_AUTH_HOSTS = [
    ...new Set(Object.values(EXTERNAL_AUTH_PORTAL_MAP).flat()),
];
/** Cek apakah `rawUrl` berada di host autentikasi eksternal milik portal `portalUrl` (atau semua portal jika kosong). */
function isExternalAuthUrl(rawUrl, portalUrl) {
    const u = parseHttpUrl(rawUrl);
    if (!u)
        return false;
    const host = u.hostname.toLowerCase().replace(/\.$/, "");
    return hostIsKnownAts(host, EXTERNAL_AUTH_HOSTS);
}

/** Origin hasil `getAll()` yang bukan izin wajib manifest: tepat itulah izin opsional yang sedang diberikan. */
function optionalOriginsToRevoke(granted, required) {
    const requiredSet = new Set(required ?? []);
    return (granted ?? []).filter((origin) => typeof origin === "string" && origin !== "" && !requiredSet.has(origin));
}
/**
 * Cabut semua izin host opsional yang sedang aktif (dipanggil saat Putus). Izin wajib (origin backend) tidak
 * disentuh. Mengembalikan jumlah origin yang diminta dicabut; galat ditelan (pencabutan best-effort).
 */
async function revokeOptionalPermissions(api, requiredOrigins) {
    if (!api)
        return 0;
    try {
        const current = await api.getAll();
        const origins = optionalOriginsToRevoke(current?.origins, requiredOrigins);
        if (origins.length === 0)
            return 0;
        await api.remove({ origins });
        return origins.length;
    }
    catch {
        return 0;
    }
}

/**
 * URL backend Applify yang tetap (bukan isian pengguna).
 *
 * Nilai bawaan adalah backend production. Build lokal untuk dev dapat menimpanya lewat variabel lingkungan
 * `APPLIFY_API_URL` yang dibaca `build.mjs` (lihat README). Build menyisipkan `__APPLIFY_API_URL__` di atas
 * modul ini; di luar build (misalnya saat tes) simbol itu tidak ada dan nilai bawaan dipakai.
 */
const PRODUCTION_API_URL = "https://backend-production-efa7dfef.up.railway.app";
const API_URL = typeof __APPLIFY_API_URL__ === "string" && __APPLIFY_API_URL__ !== "" ? __APPLIFY_API_URL__ : PRODUCTION_API_URL;
/**
 * Ubah isi `chrome.storage.local` menjadi konfigurasi yang dipakai. URL selalu URL tetap build ini:
 * `serverUrl` tersimpan dari versi lama (kolom yang dulu bisa diisi pengguna) diabaikan, supaya pengguna
 * tidak perlu menempel token lagi. `legacy` bernilai true bila isi penyimpanan masih memuat `serverUrl`
 * dan sebaiknya ditulis ulang hanya berisi token.
 */
function resolveStoredConfig(raw, apiUrl = API_URL) {
    if (!raw || typeof raw !== "object")
        return null;
    const stored = raw;
    if (typeof stored.token !== "string" || stored.token.trim() === "")
        return null;
    return {
        config: { serverUrl: apiUrl, token: stored.token },
        legacy: "serverUrl" in stored,
    };
}

/**
 * Pemetaan kode galat backend `/api/extension/*` ke pesan Indonesia yang singkat untuk side panel.
 *
 * Kode `already_claimed`, `approval_already_used`, dan `approval_resolved` bersifat final: persetujuan itu tidak
 * boleh dikirim lagi dari ekstensi. Setiap kode di sini wajib punya sedikitnya satu tindakan di panel
 * (`panelActions.ts`, dijaga `tests/panelActions.test.ts`): tidak boleh ada galat yang buntu.
 */
const TERMINAL_CODES = new Set(["already_claimed", "approval_already_used", "approval_resolved"]);
/** Masa berlaku token ekstensi (keputusan Hans 26 Nov 2026: 8 jam, sama dengan backend `DEFAULT_EXTENSION_TTL_SEC`). */
const TOKEN_LIFETIME_LABEL = "8 jam";
/** Langkah membuat token baru, sama persis dengan yang tertulis di Bantuan Applify (#ekstensi). */
const TOKEN_RENEW_STEPS = "Buka Applify, lalu Pengaturan, lalu Hubungkan Ekstensi Chrome/Edge, salin token baru, dan tempel di kolom token di panel ini.";
/** Token tidak sah atau kedaluwarsa (401). Memuat langkahnya, bukan hanya "hubungkan ulang". */
const TOKEN_EXPIRED_MESSAGE = `Token ekstensi sudah kedaluwarsa atau tidak sah (token berlaku ${TOKEN_LIFETIME_LABEL}). Hubungkan ulang: ${TOKEN_RENEW_STEPS}`;
const MESSAGES_BY_CODE = {
    token_revoked: `Token ekstensi sudah dicabut dari Pengaturan Applify. Hubungkan ulang: ${TOKEN_RENEW_STEPS}`,
    already_claimed: "Persetujuan ini sedang dipakai atau sudah dikirim di tempat lain. Jangan kirim lagi.",
    approval_already_used: "Persetujuan ini sudah pernah dipakai untuk mengirim lamaran. Jangan kirim lagi.",
    approval_resolved: "Persetujuan ini sudah ditutup atau diganti di Applify. Muat ulang daftar, atau buka Persetujuan di Applify untuk melihat yang baru.",
    page_mismatch: "Halaman ini bukan halaman lamaran untuk lowongan tersebut. Buka halaman lamaran yang benar.",
    claim_unavailable: "Layanan penguncian persetujuan sedang tidak tersedia. Coba lagi beberapa saat lagi.",
    approval_expired: "Persetujuan sudah kedaluwarsa. Setujui ulang draf di Applify.",
    approval_not_approved: "Persetujuan belum disetujui di Applify.",
    approval_not_found: "Persetujuan tidak ditemukan. Muat ulang daftar persetujuan.",
    approval_job_mismatch: "Persetujuan ini untuk lowongan lain.",
    missing_required_fields: "Masih ada kolom wajib yang belum terisi. Lengkapi dulu di halaman.",
    daily_quota_exceeded: "Batas kiriman harian sudah penuh.",
    linkedin_manual_only: "LinkedIn hanya boleh dilamar manual.",
    invalid_url: "Alamat halaman di tab tidak valid.",
    invalid_answers: "Jawaban tidak valid. Periksa isian lalu coba lagi.",
    too_many_answers: "Terlalu banyak jawaban sekaligus. Kurangi lalu simpan lagi.",
    answer_too_long: "Ada jawaban yang terlalu panjang. Persingkat lalu simpan lagi.",
    secret_question: "Kolom rahasia (kata sandi, PIN, OTP, kartu) tidak disimpan di Applify. Isi sendiri di halaman.",
    answers_unavailable: "Penyimpanan jawaban sedang tidak tersedia. Coba lagi beberapa saat lagi.",
};
const MESSAGES_BY_STATUS = {
    401: TOKEN_EXPIRED_MESSAGE,
    403: "Akses ditolak oleh server Applify.",
    429: "Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.",
    503: "Layanan Applify sedang tidak tersedia. Coba lagi beberapa saat lagi.",
};
/** Status HTTP yang punya pesan sendiri. Dipakai tes penjaga yang sama. */
Object.keys(MESSAGES_BY_STATUS).map(Number);
function isTerminalApprovalCode(code) {
    return typeof code === "string" && TERMINAL_CODES.has(code);
}
/** Pesan untuk galat jaringan (`fetch` gagal sebelum ada respons). */
const NETWORK_ERROR_MESSAGE = "Tidak dapat menghubungi server Applify. Periksa koneksi internet lalu coba lagi (hubungkan ulang ekstensi bila terus gagal).";
function mapApiError(status, code, fallback) {
    const terminal = isTerminalApprovalCode(code);
    let message;
    // 409 dengan kode yang dikenal dipetakan lewat kode. 503 selalu dianggap klaim/layanan tidak tersedia.
    if (code && MESSAGES_BY_CODE[code])
        message = MESSAGES_BY_CODE[code];
    else if (status === 503)
        message = MESSAGES_BY_CODE.claim_unavailable;
    else if (status && MESSAGES_BY_STATUS[status])
        message = MESSAGES_BY_STATUS[status];
    return { message: message ?? (fallback || "Terjadi kesalahan tak terduga."), code, status, terminal };
}
/** Ubah galat apa pun (ExtensionApiError, TypeError jaringan, Error biasa) menjadi pesan siap tampil. */
function describeError(err) {
    const e = err;
    const status = typeof e?.status === "number" ? e.status : undefined;
    const code = typeof e?.code === "string" ? e.code : undefined;
    const message = typeof e?.message === "string" ? e.message : String(err ?? "");
    if (status === undefined && (e?.name === "TypeError" || /failed to fetch|networkerror|load failed/i.test(message))) {
        return { message: NETWORK_ERROR_MESSAGE, code: "network_error", status: undefined, terminal: false };
    }
    return mapApiError(status, code, message);
}

/**
 * Saklar "Isi otomatis di latar" (kill switch antrean).
 *
 * Disimpan di `chrome.storage.local`. Bawaan AKTIF begitu ekstensi terhubung: persetujuan di sisi server sudah
 * menentukan tugas mana yang ada di antrean. Hanya nilai `false` yang eksplisit mematikannya. Saat mati, alarm
 * poll tidak mengklaim tugas baru (tugas yang sudah berjalan tetap dirawat sampai selesai atau dilepas).
 * Pilihan ini sengaja TIDAK dihapus saat Putus: saklar yang dimatikan tidak boleh hidup lagi sendiri.
 */
const BACKGROUND_FILL_KEY = "applify_ext_bg_fill";
async function loadBackgroundFill(area) {
    try {
        const data = await area.get(BACKGROUND_FILL_KEY);
        return data?.[BACKGROUND_FILL_KEY] !== false;
    }
    catch {
        return true;
    }
}
async function saveBackgroundFill(area, enabled) {
    await area.set({ [BACKGROUND_FILL_KEY]: enabled === true });
}

/**
 * Catatan "situs butuh izin": host lowongan yang tugas antreannya dilepas karena izin host opsionalnya belum
 * diberikan pengguna. Panel memakainya untuk menampilkan tombol "Izinkan <host>", dan ikon memakainya untuk
 * lencana "!".
 *
 * Disimpan di `chrome.storage.local` supaya selamat dari service worker yang dimatikan. Isinya hanya nama host
 * (bukan URL lowongan, bukan data pengguna), dibatasi jumlahnya, dan kedaluwarsa sendiri: tugas yang masih
 * terblokir mengklaim ulang tiap poll dan memperbarui catatannya, jadi catatan yang tidak diperbarui berarti
 * tugasnya sudah tidak menunggu izin.
 *
 * Setiap host divalidasi ulang dengan `atsPermissionPattern`: tidak pernah ada host di luar daftar ATS, portal
 * login, atau Google Forms (`docs.google.com`, hanya path `/forms/`) yang bisa lolos dari sini ke
 * `chrome.permissions.request`.
 */
const PERMISSION_NEEDED_KEY = "applify_ext_permission_needed";
const MAX_PERMISSION_NEEDED = 10;
const PERMISSION_NEEDED_TTL_MS = 15 * 60 * 1000;
const PERMISSION_BADGE_TEXT = "!";
const PERMISSION_BADGE_TITLE = "Applify: butuh izin situs. Buka panel ekstensi lalu klik Izinkan.";
/** Awalan kode alasan di `error` saat melepas tugas; backend dan web app membacanya sebagai kode mesin. */
const PERMISSION_REQUIRED_CODE = "permission_required";
const PERMISSION_REQUIRED_TEXT = "Izin situs ATS belum diberikan di ekstensi.";
/**
 * URL minimal untuk satu host: bentuk yang diterima `requestAtsPermission` dan `hasOriginPermission`. Google Forms
 * (`docs.google.com`) izinnya dibatasi path `/forms/`, jadi URL-nya ikut path itu, bukan akar situs.
 */
const permissionUrlForHost = (host) => (host === GOOGLE_FORMS_HOST ? GOOGLE_FORMS_PERMISSION_URL : `https://${host}/`);
/**
 * URL untuk memeriksa atau mencatat izin sebuah origin (iframe lintas-origin): `docs.google.com` lewat path `/forms/`
 * karena izinnya dibatasi path itu, selain itu `<origin>/`.
 */
function permissionUrlForOrigin(origin) {
    const host = parseHttpUrl(origin)?.hostname.toLowerCase();
    return host === GOOGLE_FORMS_HOST ? GOOGLE_FORMS_PERMISSION_URL : `${origin}/`;
}
/** Host lowongan yang izinnya bisa diminta, atau null bila bukan HTTPS atau tidak ada di daftar ATS, portal login, dan Google Forms. */
function permissionHostForUrl(applyUrl) {
    const pattern = atsPermissionPattern(applyUrl);
    // Pola host persis `https://<host>/*` atau pola path Google Forms `https://docs.google.com/forms/*`: host = segmen sebelum path.
    return pattern ? (pattern.slice("https://".length).split("/")[0] ?? null) : null;
}
const isRequestableHost = (host) => typeof host === "string" && host !== "" && permissionHostForUrl(permissionUrlForHost(host)) === host;
/** Bersihkan isi storage: buang entri rusak, host di luar daftar, duplikat, dan yang kedaluwarsa; terbaru dulu, dibatasi. */
function normalizePermissionNeeded(raw, nowMs) {
    if (!Array.isArray(raw))
        return [];
    const byHost = new Map();
    for (const item of raw) {
        const host = item?.host;
        const atMs = item?.atMs;
        if (!isRequestableHost(host) || typeof atMs !== "number" || !Number.isFinite(atMs))
            continue;
        if (nowMs - atMs > PERMISSION_NEEDED_TTL_MS)
            continue;
        const current = byHost.get(host);
        if (!current || atMs > current.atMs)
            byHost.set(host, { host, atMs });
    }
    return [...byHost.values()].sort((a, b) => b.atMs - a.atMs).slice(0, MAX_PERMISSION_NEEDED);
}
async function loadPermissionNeeded(area, nowMs) {
    const data = await area.get(PERMISSION_NEEDED_KEY);
    return normalizePermissionNeeded(data?.[PERMISSION_NEEDED_KEY], nowMs);
}
async function save$2(area, entries) {
    if (entries.length === 0)
        await area.remove(PERMISSION_NEEDED_KEY);
    else
        await area.set({ [PERMISSION_NEEDED_KEY]: entries });
}
/** Catat (atau perbarui) host lowongan yang butuh izin. Null bila hostnya tidak bisa diminta izinnya. */
async function recordPermissionNeeded(area, applyUrl, nowMs) {
    const host = permissionHostForUrl(applyUrl);
    if (!host)
        return null;
    const entry = { host, atMs: nowMs };
    const current = await loadPermissionNeeded(area, nowMs);
    await save$2(area, normalizePermissionNeeded([entry, ...current.filter((e) => e.host !== host)], nowMs));
    return entry;
}
/**
 * Samakan catatan dengan izin yang sungguh dimiliki: catatan yang izinnya sudah ada (`isGranted`) dihapus, catatan
 * kedaluwarsa atau rusak ikut dibersihkan. `changed` true bila isi storage berubah.
 */
async function syncPermissionNeeded(area, nowMs, isGranted) {
    const data = await area.get(PERMISSION_NEEDED_KEY);
    const stored = data?.[PERMISSION_NEEDED_KEY];
    const entries = normalizePermissionNeeded(stored, nowMs);
    const cleared = [];
    for (const entry of entries) {
        if (await isGranted(entry.host).catch(() => false))
            cleared.push(entry.host);
    }
    const remaining = entries.filter((e) => !cleared.includes(e.host));
    // Hanya normalisasi yang disimpan, jadi isi yang sama persis berarti tidak ada yang perlu ditulis.
    const same = stored === undefined ? remaining.length === 0 : JSON.stringify(stored) === JSON.stringify(remaining);
    if (!same)
        await save$2(area, remaining);
    return { cleared, remaining, changed: !same };
}
async function clearPermissionNeeded(area) {
    await area.remove(PERMISSION_NEEDED_KEY);
}
/**
 * Teks `error` untuk melepas tugas yang terblokir izin: `permission_required:<host> — <pesan>`. Backend menyimpannya
 * apa adanya di `automation_queue.error_message` dan membaca kodenya dari awalan; web app memakai host-nya untuk
 * petunjuk. Host di luar daftar tidak bisa diizinkan lewat tombol, jadi tetap memakai pesan lama tanpa kode.
 */
function permissionReleaseError(applyUrl) {
    const host = permissionHostForUrl(applyUrl);
    return host ? `${PERMISSION_REQUIRED_CODE}:${host} — ${PERMISSION_REQUIRED_TEXT}` : PERMISSION_REQUIRED_TEXT;
}
/** Awalan kode alasan saat tugas dilepas permanen karena host lowongannya tidak bisa diminta izinnya sama sekali. */
const UNSUPPORTED_HOST_CODE = "unsupported_host";
const UNSUPPORTED_HOST_TEXT = "Situs ini tidak ada di daftar izin ekstensi, jadi tidak bisa diisi lewat antrean. Buka halaman lowongan lalu klik ikon ekstensi untuk mengisi manual.";
/**
 * Teks `error` untuk tugas yang host-nya tidak bisa diizinkan lewat tombol (bukan HTTPS, atau di luar daftar ATS dan
 * portal login): `unsupported_host:<host> — <pesan>`. Tugas ini dilepas permanen, bukan menunggu izin yang tidak akan
 * pernah ada. Hanya nama host yang ikut (tanpa path atau query, yang bisa membawa token).
 */
function unsupportedHostReleaseError(applyUrl) {
    const host = parseHttpUrl(applyUrl)?.hostname.toLowerCase().replace(/\.$/, "").slice(0, 60);
    return host ? `${UNSUPPORTED_HOST_CODE}:${host} — ${UNSUPPORTED_HOST_TEXT}` : `${UNSUPPORTED_HOST_CODE} — ${UNSUPPORTED_HOST_TEXT}`;
}
const permissionButtonLabel = (host) => (host === GOOGLE_FORMS_HOST ? "Izinkan Google Forms" : `Izinkan ${host}`);

/**
 * Pemberitahuan antrean di panel. Antrean latar mengisi lowongan tanpa pengguna membuka ekstensi, dan beberapa hasilnya
 * dulu hanya tampil sebagai tulisan di halaman lowongan (lencana overlay) sementara panel kosong: situs yang belum
 * didukung, menunggu login, CAPTCHA, dihentikan, gagal, formulir tidak ditemukan. Aturan UAT Hans (26 November 2026):
 * tidak boleh ada status buntu. Setiap hasil seperti itu kini dicatat di sini dan digambar panel sebagai kartu dengan
 * tombol langkah berikutnya.
 *
 * Disimpan di `chrome.storage.session` (id tab hanya berlaku selama peramban hidup). Isinya hanya jenis, host, URL
 * tanpa query dan hash, id tab, id persetujuan, dan waktu: tanpa isian formulir, jawaban, atau teks halaman. Dibatasi
 * jumlahnya dan kedaluwarsa sendiri.
 */
const QUEUE_NOTICE_KEY = "applify_ext_queue_notices";
const MAX_QUEUE_NOTICES = 5;
const QUEUE_NOTICE_TTL_MS = 24 * 60 * 60 * 1000;
const KINDS = new Set([
    "unsupported_host",
    "no_apply_url",
    "linkedin_manual",
    "awaiting_login",
    "login_timeout",
    "captcha",
    "stopped",
    "failed",
    "form_not_found",
    "blocked",
]);
/** Host dan URL (tanpa query dan hash) dari alamat lowongan, atau `null` keduanya bila bukan http atau https. */
function noticeLocation(rawUrl) {
    const u = parseHttpUrl(rawUrl);
    if (!u)
        return { host: null, url: null };
    return { host: u.hostname.toLowerCase().replace(/\.$/, "").slice(0, 80), url: `${u.origin}${u.pathname}`.slice(0, 300) };
}
function isNotice(v) {
    const n = v;
    return (Boolean(n) &&
        typeof n.id === "string" &&
        n.id !== "" &&
        typeof n.kind === "string" &&
        KINDS.has(n.kind) &&
        typeof n.atMs === "number" &&
        Number.isFinite(n.atMs));
}
/** Bersihkan isi storage: buang entri rusak dan kedaluwarsa, satu per tugas (terbaru menang), terbaru dulu, dibatasi. */
function normalizeQueueNotices(raw, nowMs) {
    if (!Array.isArray(raw))
        return [];
    const byId = new Map();
    for (const item of raw) {
        if (!isNotice(item) || nowMs - item.atMs > QUEUE_NOTICE_TTL_MS)
            continue;
        const notice = {
            id: item.id.slice(0, 64),
            kind: item.kind,
            host: typeof item.host === "string" && item.host ? item.host.slice(0, 80) : null,
            url: typeof item.url === "string" && /^https?:\/\//i.test(item.url) ? item.url.slice(0, 300) : null,
            tabId: Number.isInteger(item.tabId) ? item.tabId : null,
            approvalId: typeof item.approvalId === "string" && item.approvalId ? item.approvalId.slice(0, 64) : null,
            atMs: item.atMs,
        };
        const current = byId.get(notice.id);
        if (!current || notice.atMs >= current.atMs)
            byId.set(notice.id, notice);
    }
    return [...byId.values()].sort((a, b) => b.atMs - a.atMs).slice(0, MAX_QUEUE_NOTICES);
}
async function loadQueueNotices(area, nowMs) {
    const data = await area.get(QUEUE_NOTICE_KEY);
    return normalizeQueueNotices(data?.[QUEUE_NOTICE_KEY], nowMs);
}
async function save$1(area, notices) {
    if (notices.length === 0)
        await area.remove(QUEUE_NOTICE_KEY);
    else
        await area.set({ [QUEUE_NOTICE_KEY]: notices });
}
/** Catat (atau ganti) pemberitahuan untuk satu tugas. */
async function recordQueueNotice(area, notice, nowMs) {
    const current = await loadQueueNotices(area, nowMs);
    await save$1(area, normalizeQueueNotices([notice, ...current.filter((n) => n.id !== notice.id)], nowMs));
}
/** Hapus pemberitahuan satu tugas (tugas selesai, diganti, atau pengguna menutupnya). `true` bila ada yang dihapus. */
async function clearQueueNotice(area, id, nowMs) {
    if (typeof id !== "string" || id === "")
        return false;
    const current = await loadQueueNotices(area, nowMs);
    const remaining = current.filter((n) => n.id !== id);
    if (remaining.length === current.length)
        return false;
    await save$1(area, remaining);
    return true;
}
async function clearAllQueueNotices(area) {
    await area.remove(QUEUE_NOTICE_KEY);
}

/**
 * Sesi pengisian formulir yang disimpan di `chrome.storage.session`.
 *
 * Service worker MV3 dimatikan Chrome setelah sekitar 30 detik menganggur, padahal pengguna butuh
 * waktu untuk memeriksa formulir sebelum menekan "Kirim". Karena itu sesi tidak boleh hanya hidup
 * di memori service worker. `storage.session` tidak ditulis ke disk dan hilang saat peramban ditutup.
 */
const FILL_SESSION_KEY = "applify_fill_session";
function isFillSession(v) {
    if (!v ||
        typeof v !== "object" ||
        v.version !== 1 ||
        typeof v.runId !== "string" ||
        typeof v.approvalId !== "string" ||
        typeof v.jobId !== "string" ||
        !Number.isInteger(v.tabId) ||
        !Number.isInteger(v.frameId) ||
        v.frameId < 0 ||
        typeof v.pageUrl !== "string" ||
        typeof v.tabOrigin !== "string" ||
        typeof v.frameOrigin !== "string") {
        return false;
    }
    const page = parseHttpUrl(v.pageUrl);
    // Sesi lama (tanpa frame) atau rusak ditolak: pengguna cukup mengisi ulang.
    return page !== null && parseHttpUrl(v.tabOrigin) !== null && parseHttpUrl(v.frameOrigin) !== null && page.origin === v.frameOrigin;
}
/**
 * Sesi pengisian dari antrean latar disimpan terpisah, satu per tab (`applify_queue_fill_session_<tabId>`), supaya
 * tidak menimpa sesi manual yang sedang dipakai panel (`FILL_SESSION_KEY`). Jumlahnya dibatasi.
 */
const QUEUE_FILL_SESSION_PREFIX = "applify_queue_fill_session_";
const MAX_QUEUE_FILL_SESSIONS = 5;
const queueFillSessionKey = (tabId) => `${QUEUE_FILL_SESSION_PREFIX}${tabId}`;
async function saveFillSession(area, session, key = FILL_SESSION_KEY) {
    try {
        await area.set({ [key]: session });
    }
    catch (err) {
        // Kuota penuh: simpan tanpa tangkapan layar agar tombol Kirim tetap berfungsi.
        if (session.filledScreenshot === null)
            throw err;
        await area.set({ [key]: { ...session, filledScreenshot: null } });
    }
}
async function loadFillSession(area, key = FILL_SESSION_KEY) {
    const res = await area.get(key);
    const raw = res?.[key];
    return isFillSession(raw) ? raw : null;
}
async function clearFillSession(area, key = FILL_SESSION_KEY) {
    await area.remove(key);
}
/** Simpan sesi antrean untuk satu tab, lalu buang yang tertua bila lebih dari `MAX_QUEUE_FILL_SESSIONS`. */
async function saveQueueFillSession(area, session) {
    await saveFillSession(area, session, queueFillSessionKey(session.tabId));
    try {
        const all = await area.get(null);
        const entries = Object.entries(all ?? {})
            .filter(([k]) => k.startsWith(QUEUE_FILL_SESSION_PREFIX))
            .map(([k, v]) => ({ key: k, createdAt: Number(v?.createdAt) || 0 }))
            .sort((a, b) => b.createdAt - a.createdAt);
        const stale = entries.slice(MAX_QUEUE_FILL_SESSIONS).map((e) => e.key);
        if (stale.length > 0)
            await area.remove(stale);
    }
    catch {
        // Pembersihan hanya penghematan ruang: gagal tidak membatalkan penyimpanan.
    }
}
function clearQueueFillSession(area, tabId) {
    return typeof tabId === "number" ? clearFillSession(area, queueFillSessionKey(tabId)) : Promise.resolve();
}
/**
 * Sesi yang berlaku untuk tab aktif: sesi manual bila miliknya tab itu; bila tidak, sesi antrean tab itu (formulir yang
 * diisi di latar); bila tidak ada, sesi manual apa adanya (pengiriman lalu menolak karena tab berbeda).
 */
async function loadFillSessionForTab(area, tabId) {
    const manual = await loadFillSession(area);
    if (manual && (tabId === undefined || manual.tabId === tabId))
        return { session: manual, key: FILL_SESSION_KEY };
    if (tabId !== undefined) {
        const key = queueFillSessionKey(tabId);
        const queued = await loadFillSession(area, key);
        if (queued && queued.tabId === tabId)
            return { session: queued, key };
    }
    return manual ? { session: manual, key: FILL_SESSION_KEY } : null;
}
/** Pengiriman hanya boleh di tab yang tadi diisi, dan origin tab tingkat atas harus sama dengan saat diisi. */
function checkSubmitTarget(session, tab) {
    if (isLinkedInUrl(tab.url)) {
        return { ok: false, code: "linkedin_manual_only", error: "Pengiriman pada LinkedIn dilarang (manual-only)." };
    }
    if (tab.id !== session.tabId) {
        return {
            ok: false,
            code: "tab_mismatch",
            error: "Tab aktif bukan tab yang tadi diisi. Pindah ke tab lowongan yang sudah diisi, lalu klik Kirim lagi.",
        };
    }
    const current = parseHttpUrl(tab.url);
    const filled = parseHttpUrl(session.tabOrigin);
    if (!current || !filled) {
        return { ok: false, code: "no_tab_url", error: "Alamat tab tidak dapat dibaca. Pengiriman dibatalkan." };
    }
    if (current.origin !== filled.origin) {
        return {
            ok: false,
            code: "origin_mismatch",
            error: "Situs di tab ini berbeda dari halaman yang tadi diisi. Pengiriman dibatalkan.",
        };
    }
    return { ok: true };
}
/**
 * Frame yang tadi diisi harus masih ada dan origin-nya sama. `liveFrameUrl` adalah URL frame bernomor
 * `session.frameId` saat ini (null bila frame itu sudah tidak ada). Yang dibandingkan origin frame tersimpan,
 * bukan origin tab, jadi embed lintas origin tetap bisa dikirim sementara frame lain tidak bisa menggantikannya.
 */
function checkSubmitFrame(session, liveFrameUrl) {
    if (liveFrameUrl === null) {
        return {
            ok: false,
            code: "frame_lost",
            error: "Frame formulir yang tadi diisi sudah tidak ada. Pengiriman dibatalkan. Isi ulang formulir lalu klik Kirim lagi.",
        };
    }
    if (isLinkedInUrl(liveFrameUrl)) {
        return { ok: false, code: "linkedin_manual_only", error: "Pengiriman pada LinkedIn dilarang (manual-only)." };
    }
    const live = parseHttpUrl(liveFrameUrl);
    if (!live || live.origin !== session.frameOrigin) {
        return {
            ok: false,
            code: "frame_origin_changed",
            error: "Frame formulir berpindah ke situs lain sejak diisi. Pengiriman dibatalkan. Isi ulang formulir lalu klik Kirim lagi.",
        };
    }
    return { ok: true };
}
/** Ringkasan aman untuk side panel: tanpa tangkapan layar atau data halaman. */
function summarizeSession(session, tab) {
    if (!session)
        return null;
    return {
        approvalId: session.approvalId,
        jobId: session.jobId,
        /** Tab yang tadi diisi, untuk tombol "Kembali ke tab yang diisi" di panel. Hanya id. */
        tabId: session.tabId,
        filledCount: session.filledCount,
        missingRequiredCount: session.missingRequiredCount,
        canSubmit: session.missingRequiredCount === 0 && Boolean(session.submitControlId),
        targetOk: tab ? checkSubmitTarget(session, tab).ok : false,
        pendingQuestions: session.pendingQuestions,
        filesAttached: session.filesAttached ?? null,
    };
}

/**
 * Pemilihan frame yang diisi. Fungsi murni agar bisa diuji tanpa `chrome.*`.
 *
 * Frame dipilih SEKALI saat pengisian dan disimpan di `FillSession`. Semua langkah sesudahnya
 * (cek kolom kurang, klik kirim, deteksi hasil) memakai frame yang tersimpan itu, tidak memilih ulang.
 */
/**
 * Pilih frame dengan kontrol formulir terbanyak. Frame yang tidak terbaca atau terlarang (hitungan negatif,
 * misalnya LinkedIn) dilewati. Hitungan sama: frame ber-ID lebih kecil menang, supaya hasilnya tidak
 * bergantung pada urutan hasil dari Chrome. Tanpa kandidat sama sekali: frame utama (0).
 */
function chooseBestFrame(probes) {
    let bestFrame = -1;
    let bestCount = -1;
    for (const probe of probes) {
        const count = Number(probe?.result?.count ?? -1);
        const frameId = typeof probe?.frameId === "number" && Number.isInteger(probe.frameId) && probe.frameId >= 0 ? probe.frameId : 0;
        if (!Number.isFinite(count) || count < 0)
            continue;
        if (count > bestCount || (count === bestCount && frameId < bestFrame)) {
            bestCount = count;
            bestFrame = frameId;
        }
    }
    return bestFrame < 0 ? 0 : bestFrame;
}

/**
 * Pesan dan teks lapisan tampilan (overlay) di halaman lowongan saat antrean mengisi dalam mode tampil.
 * Murni data dan fungsi tanpa `chrome.*` atau DOM, dipakai bersama oleh service worker dan skrip konten.
 */
/** Nama elemen dan atribut penanda host overlay. Penelusuran DOM (`deepDom.ts`) melewati elemen ini. */
const OVERLAY_TITLE_DONE = "Selesai mengisi · periksa lalu kirim sendiri di sini";
const OVERLAY_TITLE_PARTIAL = "Selesai mengisi sebagian · lengkapi sisanya, periksa, lalu kirim sendiri di sini";
const OVERLAY_TITLE_STOPPED = "Dihentikan · formulir tidak dikirim";
const OVERLAY_TITLE_LOGIN = "Butuh login · masuk ke akunmu di tab ini";
const OVERLAY_TITLE_CAPTCHA = "Butuh kamu · selesaikan CAPTCHA di tab ini";
const OVERLAY_TITLE_NO_FORM = "Formulir lamaran tidak ditemukan di halaman ini";
const OVERLAY_TITLE_FORM_IN_IFRAME = "Formulir ada di iframe yang belum bisa dibaca Applify";
const OVERLAY_TITLE_BLOCKED = "Applify tidak bisa mengisi halaman ini · isi sendiri di tab ini";
const OVERLAY_TITLE_FAILED = "Applify berhenti sebelum selesai · periksa halaman ini";
const OVERLAY_TITLE_LOGIN_TIMEOUT = "Applify berhenti menunggu login · masuk lalu isi sendiri di tab ini";
const OVERLAY_TITLE_NEEDS_INPUT = "Applify butuh jawabanmu · klik ikon Applify di toolbar untuk membuka panel";
/** Galat yang dikembalikan pengisian bila pengguna menekan Hentikan. */
const USER_STOPPED_CODE = "user_stopped";
const USER_STOPPED_ERROR = "Dihentikan oleh pengguna sebelum formulir dikirim.";
const MAX_DETAIL_CHARS = 140;
function clip(text) {
    const clean = text.replace(/\s+/g, " ").trim();
    return clean.length > MAX_DETAIL_CHARS ? `${clean.slice(0, MAX_DETAIL_CHARS - 1)}…` : clean;
}
function stoppedOverlay() {
    return {
        type: "AGENT_OVERLAY",
        mode: "stopped",
        title: OVERLAY_TITLE_STOPPED,
        detail: "Tab ini tetap terbuka. Kamu bisa mengisi dan mengirim sendiri.",
    };
}
function loginTimeoutOverlay() {
    return { type: "AGENT_OVERLAY", mode: "attention", title: OVERLAY_TITLE_LOGIN_TIMEOUT };
}
/**
 * Serah-terima mode latar: formulir berhenti menunggu jawaban pengguna. Panel tidak bisa dibuka dari service worker
 * (butuh gestur), jadi lencana di halaman menunjuk ke ikon ekstensi yang membuka panel dengan pertanyaannya.
 */
function needsInputOverlay(questions) {
    const open = Math.max(0, Math.floor(Number(questions)) || 0);
    return {
        type: "AGENT_OVERLAY",
        mode: "attention",
        title: OVERLAY_TITLE_NEEDS_INPUT,
        detail: open > 0 ? `${open} pertanyaan menunggu jawabanmu di panel` : "Ada kolom wajib yang belum terisi di halaman ini",
    };
}
/**
 * Lencana akhir untuk hasil satu pengisian. `null` berarti lapisan dilepas (tab bukan urusan antrean lagi).
 * Semua keadaan "berhenti sebelum kirim" menyisakan lencana yang bisa ditutup pengguna.
 */
function finalOverlayFor(res) {
    if (res.leaseLost)
        return { type: "AGENT_OVERLAY", mode: "remove" };
    if (res.aborted)
        return stoppedOverlay();
    if (res.awaitingLogin) {
        return {
            type: "AGENT_OVERLAY",
            mode: "attention",
            title: OVERLAY_TITLE_LOGIN,
            detail: "Applify melanjutkan pengisian otomatis setelah kamu masuk.",
        };
    }
    if (res.blocked === "captcha_blocked") {
        return {
            type: "AGENT_OVERLAY",
            mode: "attention",
            title: OVERLAY_TITLE_CAPTCHA,
            detail: "Setelah itu lanjutkan dari panel Applify, atau isi sendiri.",
        };
    }
    if (res.blocked)
        return { type: "AGENT_OVERLAY", mode: "attention", title: OVERLAY_TITLE_BLOCKED };
    if (res.formNotFound) {
        if (res.foreignFrameHost) {
            return {
                type: "AGENT_OVERLAY",
                mode: "attention",
                title: OVERLAY_TITLE_FORM_IN_IFRAME,
                detail: clip(`Formulirnya ada di iframe dari ${res.foreignFrameHost}. Izinkan situs itu di panel Applify, atau isi sendiri.`),
            };
        }
        return { type: "AGENT_OVERLAY", mode: "attention", title: OVERLAY_TITLE_NO_FORM, detail: "Periksa halamannya, atau isi sendiri." };
    }
    if (!res.ok) {
        return {
            type: "AGENT_OVERLAY",
            mode: "attention",
            title: OVERLAY_TITLE_FAILED,
            ...(res.error ? { detail: clip(res.error) } : {}),
        };
    }
    const filled = Math.max(0, Math.floor(Number(res.summary?.filledCount ?? 0)) || 0);
    const missing = Math.max(0, Math.floor(Number(res.summary?.missingRequiredCount ?? 0)) || 0);
    const open = Array.isArray(res.questions) ? res.questions.length : 0;
    const partial = missing > 0 || open > 0;
    const parts = [`${filled} kolom terisi`];
    if (missing > 0)
        parts.push(`${missing} kolom wajib masih kosong`);
    else if (open > 0)
        parts.push(`${open} pertanyaan butuh jawabanmu`);
    return {
        type: "AGENT_OVERLAY",
        mode: "done",
        title: partial ? OVERLAY_TITLE_PARTIAL : OVERLAY_TITLE_DONE,
        detail: parts.join(" · "),
    };
}

/**
 * Saklar "Tampilkan tab saat mengisi" (mode tampil).
 *
 * Disimpan di `chrome.storage.local`. Bawaan AKTIF: tab lowongan dibuka sebagai tab aktif di jendela pengguna supaya
 * prosesnya terlihat. Hanya nilai `false` yang eksplisit memilih mode latar (tab tidak aktif, tanpa tangkapan layar).
 * Saklar ini hanya menentukan CARA tugas dikerjakan; saklar "Isi otomatis di latar" (`backgroundFill.ts`) menentukan
 * APAKAH tugas diambil. Pilihan tidak dihapus saat Putus, sama seperti saklar yang satunya.
 */
const VISIBLE_RUN_KEY = "applify_ext_visible_run";
async function loadVisibleRun(area) {
    try {
        const data = await area.get(VISIBLE_RUN_KEY);
        return data?.[VISIBLE_RUN_KEY] !== false;
    }
    catch {
        return true;
    }
}
async function saveVisibleRun(area, enabled) {
    await area.set({ [VISIBLE_RUN_KEY]: enabled === true });
}

/**
 * Anggaran ukuran tangkapan layar bukti.
 *
 * Backend hanya menerima PNG asli (magic bytes) dan route `report-run` punya batas body sekitar 6 MB.
 * Karena itu format tetap PNG, tetapi gambar diperkecil lebih dulu (lebar maksimal 1280 px) dan
 * diperkecil bertahap lagi sampai tiap berkas di bawah anggaran (sekitar 700 KB). Bila tetap
 * terlalu besar, tangkapan layar dibuang (bukan dikirim) supaya laporan hasil kirim tidak ditolak.
 */
const PNG_DATA_URL_PREFIX = "data:image/png;base64,";
const MAX_SCREENSHOT_WIDTH = 1280;
const MIN_SCREENSHOT_WIDTH = 480;
const SCREENSHOT_BYTE_BUDGET = 700_000;
const SCREENSHOT_SHRINK_FACTOR = 0.75;
function isPngDataUrl(value) {
    return typeof value === "string" && value.startsWith(PNG_DATA_URL_PREFIX) && value.length > PNG_DATA_URL_PREFIX.length;
}
/** Ukuran byte hasil dekode dari data URL base64. */
function dataUrlByteLength(dataUrl) {
    const comma = dataUrl.indexOf(",");
    const b64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
    if (!b64)
        return 0;
    const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
    return Math.max(0, Math.floor((b64.length * 3) / 4) - padding);
}
function isWithinScreenshotBudget(bytes, budget = SCREENSHOT_BYTE_BUDGET) {
    return Number.isFinite(bytes) && bytes > 0 && bytes <= budget;
}
/** Ukuran target dengan rasio tetap. Tidak pernah memperbesar gambar. */
function targetSize(width, height, maxWidth = MAX_SCREENSHOT_WIDTH) {
    if (!(width > 0) || !(height > 0))
        return { width: 1, height: 1 };
    const w = Math.min(Math.round(width), Math.max(1, Math.round(maxWidth)));
    return { width: w, height: Math.max(1, Math.round((height * w) / width)) };
}
/** Lebar berikutnya yang lebih kecil, atau null bila sudah di batas bawah. */
function nextShrinkWidth(width) {
    const next = Math.floor(width * SCREENSHOT_SHRINK_FACTOR);
    return next >= MIN_SCREENSHOT_WIDTH ? next : null;
}
/**
 * Perkecil PNG sampai muat di anggaran. Mengembalikan data URL PNG, atau null bila tidak bisa
 * dimuat di anggaran, bukan PNG, atau pengodean gagal. Selalu memperkecil dari sumber asli agar
 * kualitas tidak turun berlapis.
 */
async function fitScreenshotToBudget(sourceDataUrl, codec, opts = {}) {
    if (!isPngDataUrl(sourceDataUrl))
        return null;
    const budget = opts.byteBudget ?? SCREENSHOT_BYTE_BUDGET;
    let width = opts.maxWidth ?? MAX_SCREENSHOT_WIDTH;
    try {
        while (width !== null) {
            const out = await codec.rescale(sourceDataUrl, width);
            if (isPngDataUrl(out.dataUrl) && isWithinScreenshotBudget(dataUrlByteLength(out.dataUrl), budget))
                return out.dataUrl;
            width = nextShrinkWidth(Math.min(width, out.width));
        }
    }
    catch {
        return null;
    }
    return null;
}
function bytesToBase64(bytes) {
    let bin = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
        bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return btoa(bin);
}
function base64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++)
        out[i] = bin.charCodeAt(i);
    return out;
}
/** Kodek nyata untuk service worker MV3 (OffscreenCanvas tersedia tanpa DOM). */
const offscreenPngCodec = {
    async rescale(sourceDataUrl, maxWidth) {
        const bytes = base64ToBytes(sourceDataUrl.slice(PNG_DATA_URL_PREFIX.length));
        const bitmap = await createImageBitmap(new Blob([bytes], { type: "image/png" }));
        try {
            const { width, height } = targetSize(bitmap.width, bitmap.height, maxWidth);
            const canvas = new OffscreenCanvas(width, height);
            const ctx = canvas.getContext("2d");
            if (!ctx)
                throw new Error("canvas_unavailable");
            ctx.drawImage(bitmap, 0, 0, width, height);
            const blob = await canvas.convertToBlob({ type: "image/png" });
            const out = new Uint8Array(await blob.arrayBuffer());
            return { dataUrl: PNG_DATA_URL_PREFIX + bytesToBase64(out), width, height };
        }
        finally {
            bitmap.close();
        }
    },
};

/**
 * Menunggu tab selesai dimuat. Dipisah dari `serviceWorker.ts` agar bisa diuji dengan jam dan getter tiruan.
 *
 * Hasil `null` berarti GAGAL: tab sudah hilang, atau batas waktu habis dan tab belum `complete`. Batas waktu
 * tidak boleh dianggap berhasil (dulu tab yang masih memuat dikembalikan apa adanya, lalu diisi setengah jadi).
 */
const TAB_READY_POLL_MS = 250;
const realClock = {
    now: () => Date.now(),
    sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
};
async function waitForTabComplete(getTab, tabId, timeoutMs = 20_000, clock = realClock, pollMs = TAB_READY_POLL_MS) {
    const deadline = clock.now() + timeoutMs;
    for (;;) {
        const tab = await getTab(tabId).catch(() => null);
        if (!tab)
            return null;
        if (tab.status === "complete")
            return tab;
        if (clock.now() >= deadline)
            return null;
        await clock.sleep(pollMs);
    }
}

/**
 * Membuka tab lowongan untuk antrean.
 *
 * Mode latar: tab tidak aktif, apa adanya seperti sebelumnya (tanpa jendela pilihan, tanpa grup).
 * Mode tampil: tab AKTIF di jendela biasa yang terakhir difokuskan pengguna, lalu dimasukkan ke grup tab "Applify"
 * (biru) bila API grup tab tersedia. Pengelompokan hanya hiasan: gagal tidak pernah menggagalkan pembukaan tab.
 *
 * Tidak memakai izin host. `tabs.create` dan `tabs.group` tidak butuh izin; judul dan warna grup butuh izin `tabGroups`.
 */
const APPLIFY_GROUP_TITLE = "Applify";
const APPLIFY_GROUP_COLOR = "blue";
/** Id jendela biasa yang terakhir difokuskan, atau undefined (biarkan Chrome memilih jendela bawaan). */
async function lastFocusedNormalWindowId(api) {
    if (!api.windowsGetLastFocused)
        return undefined;
    try {
        const win = await api.windowsGetLastFocused({ windowTypes: ["normal"] });
        if (!win || typeof win.id !== "number")
            return undefined;
        // Jendela popup atau aplikasi tidak cocok untuk tab lowongan.
        if (typeof win.type === "string" && win.type !== "normal")
            return undefined;
        return win.id;
    }
    catch {
        return undefined;
    }
}
/** Masukkan tab ke grup "Applify" di jendelanya (memakai ulang grup yang ada). Mengembalikan id grup, atau null. */
async function groupInApplifyGroup(api, tab) {
    if (!api.tabsGroup || !api.tabGroupsUpdate || typeof tab.id !== "number")
        return null;
    try {
        let existing;
        if (api.tabGroupsQuery) {
            const found = await api.tabGroupsQuery({
                title: APPLIFY_GROUP_TITLE,
                ...(typeof tab.windowId === "number" ? { windowId: tab.windowId } : {}),
            });
            existing = found?.[0]?.id;
        }
        const groupId = await api.tabsGroup(typeof existing === "number"
            ? { tabIds: tab.id, groupId: existing }
            : { tabIds: tab.id, ...(typeof tab.windowId === "number" ? { createProperties: { windowId: tab.windowId } } : {}) });
        await api.tabGroupsUpdate(groupId, typeof existing === "number"
            ? { collapsed: false }
            : { title: APPLIFY_GROUP_TITLE, color: APPLIFY_GROUP_COLOR, collapsed: false });
        return groupId;
    }
    catch {
        return null;
    }
}
async function openRunTab(api, url, visible) {
    if (!visible)
        return api.tabsCreate({ url, active: false });
    const windowId = await lastFocusedNormalWindowId(api);
    const tab = await api.tabsCreate({ url, active: true, ...(typeof windowId === "number" ? { windowId } : {}) });
    await groupInApplifyGroup(api, tab);
    return tab;
}

/**
 * Menampilkan tab antrean ke pengguna saat butuh login. Hanya memakai `tabs.update` (aktifkan tab) dan
 * `windows.update` (fokus jendela): keduanya tidak butuh izin `tabs`. Badge ikon memakai `action.setBadgeText`.
 * Tidak ada notifikasi sistem.
 */
const LOGIN_BADGE_TEXT = "Login";
const CAPTCHA_BADGE_TEXT = "CAPTCHA";
/** Aktifkan tab, lalu fokuskan jendelanya bila API-nya ada. Gagal diam-diam (tab atau jendela sudah hilang). */
async function surfaceManagedTab(api, tabId) {
    const tab = await api.tabsUpdate(tabId, { active: true }).catch(() => null);
    if (typeof tab?.windowId === "number" && api.windowsUpdate) {
        await api.windowsUpdate(tab.windowId, { focused: true }).catch(() => undefined);
    }
}

const NO_TAB_ACCESS_MESSAGE = "Ekstensi belum punya akses ke tab ini. Klik ikon Applify di toolbar saat berada di tab lowongan (panel tetap terbuka), lalu coba lagi. Untuk situs ATS dan portal lowongan yang dikenal (JobStreet, Glints, Kalibrr, Dealls), tombol Buka Situs Lowongan atau Isi Formulir Sekarang juga meminta izin situsnya.";
/** Galat bila tab aktif tidak bisa dibaca (belum diberi akses). Dibawa sebagai `code` agar panel bisa menandainya. */
class TabAccessError extends Error {
    code = "no_tab_access";
    constructor(message = NO_TAB_ACCESS_MESSAGE) {
        super(message);
        this.name = "TabAccessError";
    }
}
function describeTabAccess(tab) {
    if (!tab || typeof tab.id !== "number")
        return { state: "no_access", host: null };
    const url = parseHttpUrl(tab.url);
    if (!url)
        return { state: "no_access", host: null };
    if (isLinkedInUrl(tab.url))
        return { state: "linkedin", host: url.hostname };
    return { state: "ok", host: url.hostname };
}

/**
 * Catatan "hasil belum terlapor".
 *
 * Setelah tombol kirim ditekan, lamaran mungkin sudah terkirim walau laporan ke Applify gagal.
 * Catatan kecil ini disimpan di `chrome.storage.local` dan dicoba lagi saat ekstensi dimulai.
 * Isinya sengaja minimal: ID persetujuan, ID lowongan, ID lokal run, hasil, URL tanpa query,
 * dan waktu. Tidak ada tangkapan layar, teks halaman, atau isian formulir.
 */
const UNREPORTED_KEY = "applify_unreported_results";
const MAX_REPORT_ATTEMPTS = 8;
const MIN_RETRY_INTERVAL_MS = 30_000;
const UNREPORTED_WARNING = "Lamaran mungkin SUDAH terkirim, tetapi laporannya ke Applify gagal. Jangan kirim ulang lamaran ini. " +
    "Periksa email atau portal lowongan. Ekstensi akan mencoba melapor lagi secara otomatis.";
const UNREPORTED_OUTCOMES = new Set([
    "submitted",
    "submit_unverified",
    "validation_error",
    "not_submitted",
    "incomplete",
]);
/** Lamaran mungkin sudah terkirim: kirim ulang diblokir dan pengguna diperingatkan. */
const isSentOutcome = (outcome) => outcome === "submitted" || outcome === "submit_unverified";
const RELEASE_PENDING_WARNING = "Formulir tidak jadi terkirim, tetapi laporan pelepasan persetujuan ke Applify belum sampai. " +
    "Kirim ulang baru bisa setelah laporan itu berhasil. Ekstensi mencoba lagi otomatis.";
/** Buang query dan hash dari URL: token atau ID pribadi sering ada di sana. */
function stripUrlForRecord(raw) {
    const u = parseHttpUrl(raw);
    return u ? u.origin + u.pathname : "";
}
function makeUnreported(input) {
    return {
        approvalId: input.approvalId,
        jobId: input.jobId,
        runId: input.runId,
        outcome: UNREPORTED_OUTCOMES.has(input.outcome) ? input.outcome : "submit_unverified",
        // Hanya hasil pelepasan yang membawa alasan; catatan hasil kirim tetap tanpa kunci `reason`.
        ...(typeof input.reason === "string" && /^[a-z0-9_]{1,40}$/.test(input.reason) ? { reason: input.reason } : {}),
        pageUrl: stripUrlForRecord(input.pageUrl),
        filledCount: Number.isFinite(input.filledCount) ? Math.max(0, Math.floor(input.filledCount)) : 0,
        createdAt: input.now,
        attempts: 0,
        lastAttemptAt: null,
        gaveUp: false,
    };
}
function isUnreported(v) {
    return (v &&
        typeof v === "object" &&
        typeof v.approvalId === "string" &&
        typeof v.jobId === "string" &&
        UNREPORTED_OUTCOMES.has(v.outcome) &&
        typeof v.pageUrl === "string");
}
async function listUnreported(area) {
    const res = await area.get(UNREPORTED_KEY);
    const raw = res?.[UNREPORTED_KEY];
    return Array.isArray(raw) ? raw.filter(isUnreported) : [];
}
async function writeAll(area, items) {
    const trimmed = items.slice(-20);
    if (trimmed.length === 0)
        await area.remove(UNREPORTED_KEY);
    else
        await area.set({ [UNREPORTED_KEY]: trimmed });
}
/** Simpan atau perbarui (kunci: approvalId). */
async function saveUnreported(area, rec) {
    const all = await listUnreported(area);
    const idx = all.findIndex((r) => r.approvalId === rec.approvalId);
    if (idx >= 0) {
        const prev = all[idx];
        const merged = { ...prev, ...rec, attempts: prev.attempts, lastAttemptAt: prev.lastAttemptAt, gaveUp: prev.gaveUp };
        // Alasan milik catatan lama tidak ikut terbawa ke catatan baru yang tidak punya alasan.
        if (rec.reason === undefined)
            delete merged.reason;
        all[idx] = merged;
    }
    else
        all.push(rec);
    await writeAll(area, all);
}
async function removeUnreported(area, approvalId) {
    const all = await listUnreported(area);
    await writeAll(area, all.filter((r) => r.approvalId !== approvalId));
}
async function markAttempt(area, approvalId, now) {
    const all = await listUnreported(area);
    const next = all.map((r) => {
        if (r.approvalId !== approvalId)
            return r;
        const attempts = r.attempts + 1;
        return { ...r, attempts, lastAttemptAt: now, gaveUp: attempts >= MAX_REPORT_ATTEMPTS };
    });
    await writeAll(area, next);
}
/** Ada hasil kirim yang belum terlapor untuk persetujuan ini (lamaran mungkin sudah terkirim). Pelepasan tidak dihitung. */
async function hasUnreportedFor(area, approvalId) {
    return (await listUnreported(area)).some((r) => r.approvalId === approvalId && isSentOutcome(r.outcome));
}
/** Ada laporan pelepasan klaim yang belum sampai ke server untuk persetujuan ini. */
async function hasPendingRelease(area, approvalId) {
    return (await listUnreported(area)).some((r) => r.approvalId === approvalId && !isSentOutcome(r.outcome));
}
/** Peringatan untuk panel: hasil kirim yang belum terlapor didahulukan; sisa pelepasan punya peringatannya sendiri. */
function unreportedWarningFor(list) {
    if (list.some((r) => isSentOutcome(r.outcome)))
        return UNREPORTED_WARNING;
    return list.length > 0 ? RELEASE_PENDING_WARNING : null;
}
/** Bentuk ringkas untuk side panel. */
function summarizeUnreported(list) {
    return list.map((r) => ({ approvalId: r.approvalId, outcome: r.outcome, createdAt: r.createdAt, gaveUp: r.gaveUp }));
}
/**
 * Coba lapor ulang catatan yang tertunda. `force` melewati jeda minimal dan batas percobaan
 * otomatis (dipakai tombol "Coba lagi" dari pengguna).
 */
async function retryUnreported(area, client, now, opts = {}) {
    const all = await listUnreported(area);
    let sent = 0;
    for (const rec of all) {
        if (!opts.force) {
            if (rec.gaveUp)
                continue;
            if (rec.lastAttemptAt !== null && now - rec.lastAttemptAt < MIN_RETRY_INTERVAL_MS)
                continue;
        }
        const pageUrl = rec.pageUrl && !isLinkedInUrl(rec.pageUrl) ? rec.pageUrl : "";
        if (!pageUrl) {
            await markAttempt(area, rec.approvalId, now);
            continue;
        }
        try {
            await client.reportRun({
                approvalId: rec.approvalId,
                jobId: rec.jobId,
                pageUrl,
                outcome: rec.outcome,
                ...(rec.reason ? { reason: rec.reason } : {}),
                runId: rec.runId,
                filledCount: rec.filledCount,
                remainingRequired: 0,
            });
            await removeUnreported(area, rec.approvalId);
            sent++;
        }
        catch (err) {
            const code = err?.code;
            if (typeof code === "string" && isTerminalApprovalCode(code)) {
                // Server sudah punya catatan pengiriman untuk persetujuan ini.
                await removeUnreported(area, rec.approvalId);
                sent++;
            }
            else {
                await markAttempt(area, rec.approvalId, now);
            }
        }
    }
    return { sent, remaining: (await listUnreported(area)).length };
}

/**
 * Catatan audit per aksi pengisian. Dibuat skrip konten (tiap kontrol) dan alur latar (klik Lanjut/pembuka), lalu
 * ikut dilaporkan ke backend sebagai `actionLog`.
 *
 * Aturan privasi: catatan TIDAK PERNAH memuat nilai isian, jawaban, atau teks halaman. Hanya ID kontrol buatan
 * ekstensi, jenis kontrol, jenis aksi, hasil, dan kode alasan dari daftar tertutup.
 */
const MAX_ACTION_LOG = 200;
const ACTION_KINDS = ["set", "select", "check", "click", "attach", "skip", "peek"];
const ACTION_RESULTS = ["verified", "retried", "unverified", "missing", "skipped"];
const CONTROL_KINDS = new Set(["text", "textarea", "select", "checkbox", "radio", "file", "button"]);
const REASON_RE = /^[a-z0-9_]{1,40}$/;
/** Bentuk satu catatan dengan batas dan daftar tertutup. Mengembalikan null bila aksi atau hasil tidak dikenal. */
function sanitizeActionEntry(raw, step) {
    if (!raw || typeof raw !== "object")
        return null;
    const r = raw;
    const action = ACTION_KINDS.find((a) => a === r.action);
    const result = ACTION_RESULTS.find((x) => x === r.result);
    if (!action || !result)
        return null;
    const ref = String(r.ref ?? "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 64) || "unknown";
    const kind = typeof r.kind === "string" && CONTROL_KINDS.has(r.kind) ? r.kind : "other";
    const entry = { step: Math.max(1, Math.min(20, Math.floor(step) || 1)), ref, kind, action, result };
    if (typeof r.reason === "string" && REASON_RE.test(r.reason))
        entry.reason = r.reason;
    return entry;
}
/** Tambahkan catatan ke daftar sampai `MAX_ACTION_LOG`; sisanya dibuang. Mengembalikan jumlah yang masuk. */
function appendActionLog(target, raw, step) {
    if (!Array.isArray(raw))
        return 0;
    let added = 0;
    for (const item of raw) {
        if (target.length >= MAX_ACTION_LOG)
            break;
        const entry = sanitizeActionEntry(item, step);
        if (!entry)
            continue;
        target.push(entry);
        added++;
    }
    return added;
}

/**
 * Jawaban pertanyaan yang diketik pengguna di side panel, sebelum dikirim ke `POST /api/extension/answers`.
 * Batas sama dengan backend (30 jawaban, nilai paling panjang 2000 karakter); dirapikan di sini supaya
 * permintaan tidak ditolak karena ukuran.
 */
const MAX_ANSWERS = 30;
const MAX_ANSWER_VALUE_LENGTH = 2000;
const MAX_KEY_LENGTH = 200;
const MAX_LABEL_LENGTH = 300;
/** Buang jawaban kosong atau salah bentuk, pangkas spasi, potong ke batas, dan batasi jumlahnya. Kunci kembar: yang pertama menang. */
function sanitizeAnswers(raw) {
    if (!Array.isArray(raw))
        return [];
    const out = [];
    const seen = new Set();
    for (const item of raw) {
        const a = item;
        if (typeof a?.key !== "string" || typeof a.value !== "string")
            continue;
        const key = a.key.trim().slice(0, MAX_KEY_LENGTH);
        const value = a.value.trim().slice(0, MAX_ANSWER_VALUE_LENGTH);
        if (!key || !value || seen.has(key))
            continue;
        seen.add(key);
        const label = (typeof a.label === "string" ? a.label : "").replace(/\s+/g, " ").trim().slice(0, MAX_LABEL_LENGTH) || key;
        out.push({ key, label, value });
        if (out.length >= MAX_ANSWERS)
            break;
    }
    return out;
}

/**
 * Petunjuk jenis kontrol yang tidak boleh menjadi pertanyaan pilihan di panel dan kartu Persetujuan:
 *
 *   - Pemilih kode negara telepon (label "IDN", "+62", "Kode negara"; pilihan memuat kode telepon). Diisi Indonesia
 *     (+62) oleh perencana dan tidak pernah ditanyakan.
 *   - Kontrol unggah berkas yang tampil sebagai dropdown ("File PDF", "Unggah berkas"). Bukan pilihan: dilaporkan
 *     sebagai pertanyaan jenis `file` (unggah sendiri), tanpa daftar pilihan.
 *
 * Logika yang sama ada di backend (`backend/services/extension-control-hints.ts`). Ubah keduanya bersama.
 */
const DIAL_OPTION_RE = /\+\s?\d{1,4}\b/;
const COUNTRY_CODE_LABEL_RE = /\b(?:kode\s+(?:negara|telepon|telp|area|panggilan)|country\s+code|dial(?:ing)?\s+code|calling\s+code|phone\s+(?:code|prefix|country))\b/i;
/** Label yang hanya berisi kode: "+62", "IDN", "INA". Dealls menampilkan kode negara terpilih sebagai label kolomnya. */
const BARE_INDONESIA_CODE_RE = /^\s*(?:\+\s?62|IDN|INA)\s*(?:\(\s*opsional\s*\))?\s*$/i;
const BARE_ANY_CODE_RE = /^\s*(?:\+\s?\d{1,4}|[A-Za-z]{2,3})\s*$/;
const INDONESIA_NAME_RE = /\bindonesia\b/i;
const ownText = (c) => [c.label, c.groupLabel, c.name, c.placeholder, c.elementId].map((v) => v ?? "").join(" ");
/** Pemilih kode negara telepon: pilihannya (paling sedikit tiga) sebagian besar memuat kode telepon, atau labelnya menyebut kode negara. */
function isCountryCodeSelect(c) {
    if (c.kind !== "select")
        return false;
    const options = Array.isArray(c.options) ? c.options : [];
    const dialOptions = options.filter((o) => DIAL_OPTION_RE.test(o)).length;
    if (options.length >= 3 && dialOptions / options.length >= 0.6)
        return true;
    if (COUNTRY_CODE_LABEL_RE.test(ownText(c)))
        return true;
    const shown = [c.label, c.currentValue].map((v) => String(v ?? "").trim()).filter(Boolean);
    if (shown.some((v) => BARE_INDONESIA_CODE_RE.test(v)))
        return true;
    // Label berupa kode negara lain ("SGP", "+65") hanya dihitung bila pilihannya memang daftar negara atau kode telepon.
    return shown.some((v) => BARE_ANY_CODE_RE.test(v)) && options.some((o) => DIAL_OPTION_RE.test(o) || INDONESIA_NAME_RE.test(o));
}
const FILE_LABEL_RE = /\b(?:file|berkas|pdf|docx?|unggah|upload|lampiran|lampirkan|attach(?:ment)?)\b/i;
const FILE_OPTION_RE = /\b(?:file|berkas|pdf|docx?|unggah|upload|lampiran|lampirkan|attach(?:ment)?|browse|choose|pilih)\b/i;
/**
 * Kontrol pilihan yang sebenarnya unggah berkas: labelnya menyebut file/berkas/PDF/unggah, dan pilihannya kosong
 * atau seluruhnya juga kata unggah ("File PDF"). Dropdown yang pilihannya jawaban nyata (mis. "Dokumen identitas"
 * dengan KTP atau Paspor) bukan unggahan.
 */
function isFileLikeSelect(c) {
    if (c.kind !== "select")
        return false;
    const options = Array.isArray(c.options) ? c.options : [];
    if (options.length === 0)
        return FILE_LABEL_RE.test(ownText(c));
    return options.every((o) => FILE_OPTION_RE.test(o)) && (FILE_LABEL_RE.test(ownText(c)) || options.every((o) => FILE_LABEL_RE.test(o)));
}

const MAX_LABEL = 120;
const LOGIN_NEXT_STEP = { kind: "login", label: "Masuk ke akunmu di tab lowongan" };
const GENERIC_NEXT_PAGE_LABEL = "Lanjut ke langkah berikutnya";
const clean = (raw) => String(raw ?? "").replace(/\s+/g, " ").trim().slice(0, MAX_LABEL);
/** Label pertanyaan tanpa penanda "(opsional)" atau "(wajib)" yang ditambahkan tampilan. */
const bareLabel = (label) => clean(label).replace(/\s*\((?:opsional|wajib)\)\s*$/i, "");
/**
 * Daftar langkah berikutnya, urut dari yang paling dulu dikerjakan: jawab pertanyaan wajib, unggah berkas wajib,
 * simpan sub-formulir yang terbuka, lalu ke halaman berikutnya. Langkah dari halaman (simpan dan berikutnya) hanya
 * ada bila formulir tidak punya tombol kirim akhir di halaman ini. Kosong bila tidak ada yang perlu dilakukan.
 */
function buildNextSteps(input) {
    const out = [];
    const questions = Array.isArray(input.questions) ? input.questions : [];
    const answerable = questions.filter((q) => q?.required === true && q.kind !== "file" && q.kind !== "secret_skip");
    if (answerable.length === 1)
        out.push({ kind: "answer_required", label: `Jawab: ${bareLabel(answerable[0].label)}`.slice(0, MAX_LABEL) });
    else if (answerable.length > 1)
        out.push({ kind: "answer_required", label: `Jawab ${answerable.length} pertanyaan wajib` });
    for (const q of questions) {
        if (q?.required !== true || q.kind !== "file")
            continue;
        const label = bareLabel(q.label);
        if (label)
            out.push({ kind: "upload_file", label });
    }
    if (!input.hasSubmitControl) {
        const save = clean(input.hints?.subformSave);
        const next = clean(input.hints?.nextPage);
        if (save)
            out.push({ kind: "subform_save", label: save });
        if (next)
            out.push({ kind: "next_page", label: next });
        else if (save)
            out.push({ kind: "next_page", label: GENERIC_NEXT_PAGE_LABEL });
    }
    return out.slice(0, 6);
}

/**
 * Bahan murni (tanpa DOM, tanpa chrome.*) untuk dua tambahan alur pengisian:
 *   1. mengintip pilihan dropdown kustom yang masih tertutup sebelum perencana bekerja, dan
 *   2. putaran kedua perencanaan untuk kontrol yang gagal menempel sesudah dibaca ulang.
 *
 * Tidak ada nilai isian di sini. Petunjuk putaran kedua hanya kode alasan dari daftar tertutup.
 */
/** Paling banyak dropdown yang diintip per langkah formulir. */
const PEEK_MAX_CONTROLS = 15;
const PEEK_MAX_OPTIONS = 50;
const PEEK_MAX_LABEL_CHARS = 120;
/**
 * Anggaran putaran kedua per pengisian. Terburuk: satu `plan-form` per langkah (`MAX_FORM_STEPS` = 6) ditambah 4
 * putaran kedua = 10 permintaan, di bawah batas 15 per menit per pengguna di backend dan tetap menyisakan ruang untuk
 * tab lain milik pengguna yang sama.
 */
const MAX_RETRY_PASSES_PER_RUN = 4;
/**
 * Alasan di catatan audit pengisi -> kode alasan perencanaan ulang.
 * `element_gone` dan `field_error` dipetakan ke `value_mismatch` agar tetap lolos kontrak tertutup backend
 * (`EXT_RETRY_REASONS`) sementara pesan error aktualnya dikirim lewat `errorText` dan `validationErrors`.
 */
const RETRYABLE = {
    option_missing: "option_not_found",
    option_unmatched: "option_not_found",
    option_ambiguous: "option_ambiguous",
    selection_mismatch: "option_not_found",
    readback_mismatch: "value_mismatch",
    reverted: "value_mismatch",
    field_error: "value_mismatch",
    element_gone: "value_mismatch",
};
const AUDITED_ACTIONS = new Set(["set", "select", "check"]);
/** Sama dengan `safeRef` di `fillControls.ts`: ID kontrol di catatan audit. */
const refOf = (id) => String(id ?? "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 64) || "unknown";
const cleanLabel = (raw) => String(raw ?? "").replace(/\s+/g, " ").trim().slice(0, PEEK_MAX_LABEL_CHARS);
/**
 * ID dropdown kustom yang perlu diintip: jenis `select`, belum punya pilihan, boleh disentuh, belum berisi nilai, dan
 * belum terbuka. Yang wajib lebih dulu, lalu urutan dokumen. Paling banyak `PEEK_MAX_CONTROLS`. Skrip konten yang
 * memutuskan akhirnya (dropdown asli `<select>` dan kontrol yang bukan combobox dilewati di sana).
 */
function selectPeekTargets(controls) {
    if (!Array.isArray(controls))
        return [];
    const targets = controls.filter((c) => c?.kind === "select" &&
        Array.isArray(c.options) &&
        c.options.length === 0 &&
        c.disabled !== true &&
        c.readOnly !== true &&
        c.toggle !== true &&
        c.expanded !== true &&
        !String(c.currentValue ?? "").trim());
    const ordered = [...targets.filter((c) => c.required === true), ...targets.filter((c) => c.required !== true)];
    return ordered.slice(0, PEEK_MAX_CONTROLS).map((c) => c.controlId);
}
/**
 * Salinan `controls` dengan `options` dari hasil intip untuk dropdown yang tadinya tanpa pilihan. Hanya `select` tanpa
 * pilihan yang diubah; label dirapikan dan dibatasi (50 x 120). Entri intip yang tidak dikenal diabaikan.
 */
function applyPeekedOptions(controls, peeks) {
    if (!Array.isArray(peeks) || peeks.length === 0)
        return controls;
    const byId = new Map();
    for (const p of peeks) {
        const id = typeof p?.controlId === "string" ? p.controlId : "";
        if (!id || !Array.isArray(p?.options))
            continue;
        const labels = [];
        for (const raw of p.options) {
            const label = cleanLabel(raw);
            if (label)
                labels.push(label);
            if (labels.length >= PEEK_MAX_OPTIONS)
                break;
        }
        if (labels.length > 0)
            byId.set(id, labels);
    }
    if (byId.size === 0)
        return controls;
    return controls.map((c) => (c.kind === "select" && c.options.length === 0 && byId.has(c.controlId) ? { ...c, options: byId.get(c.controlId) } : c));
}
/**
 * Kontrol yang layak direncanakan ulang beserta kode alasannya. Syarat: kontrol itu gagal terisi atau tidak
 * terverifikasi karena nilai tidak menempel, error validasi (`field_error`), elemen diganti saat re-render
 * (`element_gone`), opsi tidak ditemukan, atau opsi ambigu. TIDAK diminta ulang: kontrol nonaktif atau hanya-baca,
 * sakelar mode (`toggle`), klik yang ditolak penjaga (`click_refused`), elemen tidak pernah ada (`element_missing`),
 * berkas, dan tombol kirim. Kontrol yang dikirim kembali dikosongkan `currentValue`-nya sambil tetap membawa
 * `errorText` (bila ada).
 */
function buildRetryPlan(input) {
    const none = { controls: [], hints: [] };
    if (!Array.isArray(input.controls) || !Array.isArray(input.unfilledControlIds) || input.unfilledControlIds.length === 0)
        return none;
    const log = Array.isArray(input.actionLog) ? input.actionLog : [];
    const controls = [];
    const hints = [];
    const seen = new Set();
    for (const rawId of input.unfilledControlIds) {
        const id = String(rawId);
        if (seen.has(id))
            continue;
        seen.add(id);
        const control = input.controls.find((c) => c.controlId === id);
        if (!control || control.disabled === true || control.readOnly === true || control.toggle === true)
            continue;
        if (control.kind === "file" || control.kind === "submit")
            continue;
        const ref = refOf(id);
        const last = [...log].reverse().find((e) => e?.ref === ref && AUDITED_ACTIONS.has(String(e.action)));
        const reason = last && typeof last.reason === "string" ? RETRYABLE[last.reason] : undefined;
        if (!reason)
            continue;
        const errorText = typeof control.errorText === "string"
            ? control.errorText.replace(/\s+/g, " ").trim()
            : "";
        const nextControl = { ...control, currentValue: "" };
        if (errorText)
            nextControl.errorText = errorText;
        controls.push(nextControl);
        hints.push({ controlId: id, reasons: [reason] });
    }
    return { controls, hints };
}
const sameValue = (a, b) => String(a ?? "").trim().toLowerCase() === String(b ?? "").trim().toLowerCase();
/**
 * Aksi putaran kedua yang boleh diterapkan: hanya untuk kontrol yang diminta ulang, bukan berkas atau tombol kirim.
 * Untuk kontrol non-checkbox yang bukan `element_gone`, nilai yang persis sama dengan rencana pertama diabaikan
 * karena sudah gagal menempel; `checkbox` dan `element_gone` tetap diizinkan mengirim ulang nilai yang sama.
 */
function selectRetryActions(actions, requestedIds, firstPlanActions, allowSameValueIds) {
    if (!Array.isArray(actions))
        return [];
    const out = [];
    const used = new Set();
    for (const a of actions) {
        if (!a || typeof a.controlId !== "string" || !requestedIds.has(a.controlId) || used.has(a.controlId))
            continue;
        if (!["text", "textarea", "select", "radio", "checkbox"].includes(String(a.kind)))
            continue;
        if (a.kind === "checkbox") {
            if (typeof a.value !== "boolean")
                continue;
        }
        else if (typeof a.value !== "string" || !a.value.trim()) {
            continue;
        }
        const before = (firstPlanActions ?? []).find((f) => f.controlId === a.controlId);
        if (a.kind !== "checkbox" && !allowSameValueIds?.has(a.controlId) && before && sameValue(before.value, a.value))
            continue;
        used.add(a.controlId);
        out.push(a);
    }
    return out;
}
/**
 * Putaran baca ulang (uji JobStreet 25 November 2026, meniru siklus baca-bertindak-baca ulang Claude in Chrome secara
 * terbatas). Sesudah satu langkah diisi, halaman diekstrak lagi. Yang direncanakan hanya kontrol yang BARU muncul
 * (mis. kolom bersyarat sesudah memilih "Ya") atau select yang pilihannya baru terisi (kota sesudah provinsi), dan
 * masih kosong. Kontrol yang sudah ditangani rencana sebelumnya tidak diminta lagi, jadi tidak ada pertanyaan ganda.
 * Tombol kirim, berkas, dan sakelar mode tidak pernah ikut. Batas: 2 putaran per langkah, 4 per pengisian.
 */
const MAX_REREAD_ROUNDS_PER_STEP = 2;
const MAX_REREAD_ROUNDS_PER_RUN = 4;
const REREAD_MAX_CONTROLS = 30;
const REREAD_KINDS = new Set(["text", "textarea", "select", "radio", "checkbox"]);
function selectRereadTargets(before, after, handledIds) {
    if (!Array.isArray(after))
        return [];
    const prev = new Map((before ?? []).map((c) => [c.controlId, c]));
    const out = [];
    for (const c of after) {
        if (!c || !REREAD_KINDS.has(String(c.kind)) || c.disabled === true || c.readOnly === true || c.toggle === true)
            continue;
        if (handledIds.has(c.controlId))
            continue;
        if (String(c.currentValue ?? "").trim() !== "")
            continue;
        const old = prev.get(c.controlId);
        const optionsGrew = old !== undefined && (c.kind === "select" || c.kind === "radio") && (old.options?.length ?? 0) <= 1 && (c.options?.length ?? 0) > 1;
        if (old !== undefined && !optionsGrew)
            continue;
        out.push({ ...c, currentValue: "" });
        if (out.length >= REREAD_MAX_CONTROLS)
            break;
    }
    return out;
}
/** Aksi putaran baca ulang: hanya untuk kontrol yang diminta, satu aksi per kontrol, tanpa berkas atau tombol kirim. */
function selectRereadActions(actions, requestedIds) {
    if (!Array.isArray(actions))
        return [];
    const out = [];
    const used = new Set();
    for (const a of actions) {
        if (!a || typeof a.controlId !== "string" || !requestedIds.has(a.controlId) || used.has(a.controlId))
            continue;
        if (!REREAD_KINDS.has(String(a.kind)))
            continue;
        if (typeof a.value === "string" ? !a.value.trim() : typeof a.value !== "boolean")
            continue;
        used.add(a.controlId);
        out.push(a);
    }
    return out;
}
/**
 * Batas kontrol per pembacaan halaman (`MAX_EXTRACTED_CONTROLS` di `extractControls.ts`; tes menjaga keduanya sama).
 * Pembacaan sepenuh ini mungkin terpangkas, jadi tidak boleh dipakai untuk menyimpulkan ada kontrol yang hilang.
 */
const READ_CONTROL_CAP = 150;
/**
 * Kontrol yang dikenal sebelum baca ulang tetapi sudah tidak ada di halaman sesudah memilih sesuatu (mis. pilihan
 * "Tidak" menutup sub-kolom). Hanya `text | textarea | select | radio | checkbox`: berkas dan tombol kirim dilewati.
 * Kosong bila pembacaan baru tidak ada, kosong, atau sepenuh batas (bisa terpangkas), supaya pembacaan yang meragukan
 * tidak membuang pertanyaan yang sah.
 */
function findVanishedControlIds(known, after) {
    const gone = new Set();
    if (!Array.isArray(known) || !Array.isArray(after) || after.length === 0 || after.length >= READ_CONTROL_CAP)
        return gone;
    const live = new Set(after.map((c) => c?.controlId));
    for (const c of known) {
        if (c && REREAD_KINDS.has(String(c.kind)) && !live.has(c.controlId))
            gone.add(c.controlId);
    }
    return gone;
}
/** Jenis isian yang nilainya terbaca dari `currentValue` pembacaan halaman (centang tidak, nilainya tidak seragam). */
const COUNTABLE_MISSING_KINDS = new Set(["text", "textarea", "select", "radio"]);
/**
 * Hitung ulang kolom wajib yang kurang sesudah kontrol yang hilang dari halaman dicoret (lihat `findVanishedControlIds`).
 * `count` dihitung pengisi sebelum sub-kolom bersyarat ditutup pilihan tadi, jadi masih memuat kolom yang sudah tidak ada.
 *
 * - Kurangi satu per kontrol hilang yang wajib dan belum terisi (`filledIds` tidak memuatnya); label ikut dicoret.
 * - Batas bawah dari pembacaan terakhir: kolom wajib yang masih tampil, belum terisi, dan kosong tetap terhitung kurang,
 *   walau hitungan awal tidak memuat kontrol yang hilang tadi (mis. wajib karena pesan galat, bukan atribut `required`).
 * - Tidak pernah menambah hitungan di atas `count`, dan tidak pernah di bawah 0.
 */
function pruneMissingRequired(missing, known, gone, filledIds, after) {
    const baseline = Math.max(0, Math.floor(Number(missing.count)) || 0);
    const labels = Array.isArray(missing.labels) ? missing.labels.filter((l) => typeof l === "string") : [];
    if (gone.size === 0 || !Array.isArray(known))
        return { count: baseline, labels };
    const dropped = known.filter((c) => c && gone.has(c.controlId) && c.required === true && !filledIds.has(c.controlId));
    if (dropped.length === 0)
        return { count: baseline, labels };
    const liveMissing = (Array.isArray(after) ? after : []).filter((c) => c &&
        c.required === true &&
        c.disabled !== true &&
        COUNTABLE_MISSING_KINDS.has(String(c.kind)) &&
        !filledIds.has(c.controlId) &&
        String(c.currentValue ?? "").trim() === "").length;
    const remainingLabels = [...labels];
    for (const c of dropped) {
        const label = String(c.label || c.groupLabel || c.name || "").trim().toLowerCase();
        const at = label ? remainingLabels.findIndex((l) => l.trim().toLowerCase() === label) : -1;
        if (at >= 0)
            remainingLabels.splice(at, 1);
    }
    return { count: Math.max(baseline - dropped.length, Math.min(baseline, liveMissing)), labels: remainingLabels };
}
/** Pertanyaan tertunda tanpa yang kontrolnya sudah hilang dari halaman. Daftar yang sama dikembalikan bila tidak ada yang dicoret. */
function dropVanishedQuestions(questions, gone) {
    return gone.size === 0 ? questions : questions.filter((q) => !gone.has(q.key));
}

const QUEUE_POLL_ALARM = "applify_queue_poll";
const QUEUE_HEARTBEAT_ALARM = "applify_queue_heartbeat";
const AWAITING_LOGIN_ALARM = "applify_awaiting_login_check";
const ACTIVE_QUEUE_RUN_KEY = "applify_ext_active_queue_run";
const AWAITING_LOGIN_TIMEOUT_MS = 15 * 60 * 1000;
const HEARTBEAT_PERIOD_MINUTES = 0.5;
const POLL_PERIOD_MINUTES = 1;
const LOGIN_PATH_RE = /\/(?:login|signin|sign-in|signup|sign-up|oauth|authorize|auth|sso|masuk|daftar)(?:\/|$)/i;
/** Bersihkan query & hash agar token/state OAuth atau OTP di URL login tidak pernah tersimpan. */
function stripUrlQueryAndHash(rawUrl) {
    if (typeof rawUrl !== "string")
        return null;
    const trimmed = rawUrl.trim();
    if (!trimmed)
        return null;
    try {
        const u = new URL(trimmed);
        if (u.protocol !== "http:" && u.protocol !== "https:")
            return null;
        return `${u.origin}${u.pathname}`;
    }
    catch {
        return null;
    }
}
function isPortalLoginPath(rawUrl) {
    const clean = stripUrlQueryAndHash(rawUrl);
    if (!clean)
        return false;
    try {
        return LOGIN_PATH_RE.test(new URL(clean).pathname);
    }
    catch {
        return false;
    }
}
function isLoginRedirectOrRedacted(tabUrl) {
    if (!tabUrl)
        return true;
    return isExternalAuthUrl(tabUrl) || isPortalLoginPath(tabUrl);
}
function claimedJobToApproval(job) {
    return {
        approvalId: job.approvalId,
        jobId: job.jobId,
        applicationId: job.applicationId,
        title: job.title,
        company: job.company,
        platform: job.platform,
        applyUrl: job.applyUrl,
        channel: job.channel,
        manualOnly: false,
        extensionSupported: true,
        reason: "",
        // Tidak menyimpan isi surat lamaran ke chrome.storage.local; backend plan-form membacanya dari DB.
        coverLetter: null,
        expiresAt: job.expiresAt,
        queueJobId: job.queueJobId,
        queueStatus: "processing",
    };
}
async function loadActiveQueueRun(area) {
    const data = (await area.get(ACTIVE_QUEUE_RUN_KEY).catch(() => null));
    const raw = data?.[ACTIVE_QUEUE_RUN_KEY];
    if (!raw || typeof raw !== "object" || typeof raw.queueJobId !== "string" || typeof raw.approvalId !== "string") {
        return null;
    }
    return raw;
}
async function saveActiveQueueRun(area, run) {
    await area.set({ [ACTIVE_QUEUE_RUN_KEY]: run });
}
async function clearActiveQueueRun(area) {
    await area.remove(ACTIVE_QUEUE_RUN_KEY);
}
// ---------- Tab yang dibuka antrean (storage.session: hilang saat browser ditutup, jadi id lama tidak salah sasaran) ----------
const QUEUE_TABS_KEY = "applify_ext_queue_tabs";
async function loadTrackedTabs(area) {
    const data = (await area.get(QUEUE_TABS_KEY).catch(() => null));
    const raw = data?.[QUEUE_TABS_KEY];
    return Array.isArray(raw) ? raw.filter((id) => Number.isInteger(id)) : [];
}
/** Catat tab yang DIBUKA antrean. Hanya tab seperti ini yang boleh ditutup atau difokuskan oleh antrean. */
async function trackQueueTab(area, tabId) {
    const ids = await loadTrackedTabs(area);
    if (!ids.includes(tabId))
        ids.push(tabId);
    await area.set({ [QUEUE_TABS_KEY]: ids.slice(-20) });
}
/** Lepas catatan: tab itu sekarang milik pengguna (mis. formulir terisi yang menunggu diperiksa). */
async function untrackQueueTab(area, tabId) {
    if (typeof tabId !== "number")
        return;
    const ids = await loadTrackedTabs(area);
    if (!ids.includes(tabId))
        return;
    await area.set({ [QUEUE_TABS_KEY]: ids.filter((id) => id !== tabId) });
}
async function isQueueTab(area, tabId) {
    if (typeof tabId !== "number")
        return false;
    return (await loadTrackedTabs(area)).includes(tabId);
}
// ---------- Jatah pemulihan per tugas (storage.local: bertahan walau service worker mati) ----------
const QUEUE_ATTEMPTS_KEY = "applify_ext_queue_attempts";
/** Pemulihan tanpa kemajuan yang dilepas gratis (tanpa menghitung retry di server). Yang ke-3 dan seterusnya dihitung. */
const MAX_FREE_RECOVERIES = 2;
const ATTEMPT_TTL_MS = 24 * 60 * 60 * 1000;
const MAX_ATTEMPT_ENTRIES = 20;
async function loadAttempts(area) {
    const data = (await area.get(QUEUE_ATTEMPTS_KEY).catch(() => null));
    const raw = data?.[QUEUE_ATTEMPTS_KEY];
    if (!raw || typeof raw !== "object" || Array.isArray(raw))
        return {};
    const out = {};
    for (const [id, rec] of Object.entries(raw)) {
        if (rec && Number.isFinite(rec.count) && Number.isFinite(rec.updatedAtMs)) {
            out[id] = { count: Math.max(0, Math.floor(rec.count)), updatedAtMs: rec.updatedAtMs };
        }
    }
    return out;
}
/**
 * Catat satu pelepasan tugas tanpa kemajuan (SW mati, tab ditutup, halaman tak termuat) dan tentukan apakah retry
 * di server dihitung. Dua pelepasan pertama gratis; sesudahnya `countRetry: true` supaya formulir yang terus
 * macet akhirnya gagal di server, bukan membuka tab baru tiap siklus selamanya.
 */
async function claimRecoverySlot(area, queueJobId, nowMs) {
    const all = await loadAttempts(area);
    const prior = all[queueJobId]?.count ?? 0;
    all[queueJobId] = { count: prior + 1, updatedAtMs: nowMs };
    const kept = Object.entries(all)
        .filter(([, rec]) => nowMs - rec.updatedAtMs < ATTEMPT_TTL_MS)
        .sort((a, b) => b[1].updatedAtMs - a[1].updatedAtMs)
        .slice(0, MAX_ATTEMPT_ENTRIES);
    await area.set({ [QUEUE_ATTEMPTS_KEY]: Object.fromEntries(kept) }).catch(() => undefined);
    return { countRetry: prior >= MAX_FREE_RECOVERIES, recoveries: prior + 1 };
}
/** Ada kemajuan nyata (laporan terkirim, atau sampai di halaman login): hitungan pemulihan tugas ini dimulai dari nol. */
async function resetRecoveryCount(area, queueJobId) {
    const all = await loadAttempts(area);
    if (!(queueJobId in all))
        return;
    delete all[queueJobId];
    await area.set({ [QUEUE_ATTEMPTS_KEY]: all }).catch(() => undefined);
}

const SUBMIT_SETTLE_MS = 2500;
/** Batas tunggu formulir SPA tergambar (antrean latar): periksa tiap 500 ms, paling lama 8 detik. */
const FORM_WAIT_MAX_MS = 8_000;
const FORM_WAIT_POLL_MS = 500;
/** Cadangan bila skrip konten tidak menjawab `WAIT_SETTLE` (versi lama atau halaman tidak merespons). */
const SETTLE_FALLBACK_SLEEP_MS = 150;
const SETTLE_RETRY_FALLBACK_SLEEP_MS = 200;
/** Batas langkah maksimum saat otomatis mengeklik Lanjut / Next pada formulir multi-langkah. */
const MAX_FORM_STEPS = 6;
function fail(error, code, extra = {}) {
    return { ok: false, error, code, ...extra };
}
/** Batas jumlah pertanyaan yang dilaporkan dan ditampilkan (sama dengan backend). */
const MAX_PENDING_QUESTIONS = 20;
/**
 * Tambahkan kolom pilihan yang dibiarkan kosong oleh pengisi ke daftar pertanyaan belum terjawab. Urutan tetap:
 * yang wajib dulu (urutan backend dipertahankan di dalam kelompoknya), paling banyak 20.
 *
 * `secondPass` (opsional): hasil putaran kedua. Kontrol yang berhasil terisi di putaran itu dicoret dari daftar, jadi
 * tidak muncul sebagai pertanyaan; kontrol yang masih gagal tetap ada. Pertanyaan bawaan rencana pertama
 * (`planned`) tidak disentuh: putaran kedua hanya meminta ulang kontrol yang aksinya sudah ada tetapi gagal menempel.
 */
function mergeUnfilledQuestions(planned, unfilledControlIds, controls, secondPass) {
    if (!Array.isArray(unfilledControlIds) || unfilledControlIds.length === 0 || !Array.isArray(controls))
        return planned;
    const repaired = new Set(Array.isArray(secondPass?.filledControlIds) ? (secondPass?.filledControlIds).map(String) : []);
    const extra = [];
    for (const id of unfilledControlIds) {
        if (repaired.has(String(id)))
            continue;
        const control = controls.find((c) => c.controlId === id);
        if (!control || planned.some((q) => q.key === id) || extra.some((q) => q.key === id))
            continue;
        // Sakelar mode ("File PDF" di samping unggahan CV) dan pemilih kode negara telepon (IDN, +62) bukan pertanyaan.
        if (control.toggle === true || isCountryCodeSelect(control))
            continue;
        const label = control.label || control.groupLabel || control.name || "Kolom pilihan";
        // Dropdown unggah berkas dilaporkan sebagai berkas yang diunggah sendiri, tanpa daftar pilihan.
        if (control.kind === "file" || isFileLikeSelect(control)) {
            extra.push({ key: control.controlId, label, kind: "file", required: control.required === true });
            continue;
        }
        extra.push({
            key: control.controlId,
            label,
            kind: control.kind === "checkbox" ? "check" : control.kind,
            options: control.options,
            required: control.required === true,
        });
    }
    if (extra.length === 0)
        return planned;
    const all = [...planned, ...extra];
    return [...all.filter((q) => q.required === true), ...all.filter((q) => q.required !== true)].slice(0, MAX_PENDING_QUESTIONS);
}
/**
 * Ringkasan satu langkah sesudah putaran kedua: isian dan catatan audit digabung (putaran pertama lebih dulu), kontrol
 * yang terisi di putaran kedua dicoret dari daftar belum terisi, dan kolom wajib kurang diambil dari putaran kedua
 * karena dihitung ulang atas seluruh halaman.
 */
function mergeRetrySummary(first, retried) {
    const ids = (v) => (Array.isArray(v) ? v.map(String) : []);
    const repaired = new Set(ids(retried.filledControlIds));
    return {
        ...first,
        filledCount: (first.filledCount ?? 0) + (retried.filledCount ?? 0),
        filledControlIds: [...ids(first.filledControlIds), ...ids(retried.filledControlIds)],
        unfilledControlIds: ids(first.unfilledControlIds).filter((id) => !repaired.has(id)),
        missingRequiredCount: retried.missingRequiredCount,
        missingLabels: retried.missingLabels,
        actionLog: [...(Array.isArray(first.actionLog) ? first.actionLog : []), ...(Array.isArray(retried.actionLog) ? retried.actionLog : [])],
    };
}
/**
 * Jumlah pertanyaan WAJIB yang masih terbuka dan bisa dijawab: `required: true` dan bukan `secret_skip`. Kolom rahasia
 * diisi pengguna sendiri di halaman, jadi tidak dihitung sebagai kolom wajib yang kurang di laporan.
 */
function countRemainingRequired(questions) {
    return (questions ?? []).filter((q) => q?.required === true && q.kind !== "secret_skip").length;
}
/**
 * Tandai kontrol sebagai `searchable` bagi perencana bila intip menemukan combobox pencarian tanpa pilihan (daftarnya
 * baru muncul sesudah mengetik). Perencana lalu menjawab dengan teks yang diketik, bukan memilih dari daftar.
 */
function markSearchable(controls, peeks) {
    if (!Array.isArray(peeks))
        return controls;
    const ids = new Set();
    for (const p of peeks) {
        if (p?.searchable === true && typeof p.controlId === "string")
            ids.add(p.controlId);
    }
    if (ids.size === 0)
        return controls;
    return controls.map((c) => (c.kind === "select" && ids.has(c.controlId) ? { ...c, searchable: true } : c));
}
/**
 * Pertanyaan "unggah manual" untuk berkas yang tidak terpasang atau tidak terbukti masuk. Jenis `file` ditampilkan panel
 * sebagai kolom yang diisi sendiri di halaman (tanpa isian). Satu kunci hanya sekali.
 */
function withFileQuestions(questions, failedTargets, controls) {
    const extra = [];
    for (const t of failedTargets) {
        if (questions.some((q) => q.key === t.controlId) || extra.some((q) => q.key === t.controlId))
            continue;
        extra.push({
            key: t.controlId,
            label: `Unggah ${FILE_KIND_LABELS[t.kind]} secara manual`,
            kind: "file",
            required: controls.find((c) => c.controlId === t.controlId)?.required === true,
        });
    }
    if (extra.length === 0)
        return questions;
    const all = [...questions, ...extra];
    return [...all.filter((q) => q.required === true), ...all.filter((q) => q.required !== true)].slice(0, MAX_PENDING_QUESTIONS);
}
const idList = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === "string") : []);
/**
 * `remainingRequired` untuk `report-run`: pertanyaan wajib non-rahasia yang tersisa, atau jumlah kolom wajib kosong di halaman
 * (setelah dikurangi kolom wajib rahasia yang diisi sendiri oleh pengguna) bila itu lebih besar, mis. input file wajib
 * yang gagal dipasang dan tidak punya pertanyaan. Kolom `secret_skip` tidak pernah ikut terhitung.
 */
function remainingRequiredForReport(questions, domMissingRequired) {
    const secretRequired = questions.filter((q) => q.required === true && q.kind === "secret_skip").length;
    return Math.max(countRemainingRequired(questions), Math.max(0, Math.floor(domMissingRequired) - secretRequired));
}
/** Jenis kontrol ekstensi -> kosakata jenis isian di laporan backend (`text | select | check | upload`). */
function reportKind(kind) {
    if (kind === "file")
        return "upload";
    if (kind === "checkbox")
        return "check";
    if (kind === "select" || kind === "radio")
        return "select";
    return "text";
}
function describeFileError(kind, err) {
    const mapped = describeError(err);
    const name = FILE_KIND_LABELS[kind];
    const manual = "Unggah sendiri di halaman.";
    let message;
    if (mapped.code === "document_not_found" || mapped.status === 404) {
        message = `Berkas ${name} belum tersedia di Applify. ${manual}`;
    }
    else if (mapped.code === "too_large" || mapped.status === 413) {
        message = `Berkas ${name} lebih dari 5 MB. ${manual}`;
    }
    else if (mapped.code === "approval_expired" || mapped.status === 410) {
        message = `Persetujuan sudah kedaluwarsa, jadi berkas ${name} tidak diambil. ${manual}`;
    }
    else if (mapped.code === "not_approved" || mapped.code === "approval_already_used" || mapped.status === 409) {
        message = `Persetujuan belum aktif atau sudah dipakai, jadi berkas ${name} tidak diambil. ${manual}`;
    }
    else if (mapped.code === "storage_failed" || mapped.status === 502) {
        message = `Penyimpanan berkas Applify sedang bermasalah, jadi berkas ${name} tidak diambil. ${manual}`;
    }
    else {
        message = `Berkas ${name} gagal diambil dari Applify. ${manual}`;
    }
    return { kind, code: mapped.code, status: mapped.status, message };
}
/**
 * Ambil semua berkas yang direncanakan, paralel. Berkas yang gagal (404, 409, 413, jaringan) dicatat sebagai galat
 * dan TIDAK menghentikan pengisian kolom lain atau berkas lain. Isi berkas hanya dibawa di memori ke pesan
 * `APPLY_FILL_PLAN`; tidak ditulis ke storage.
 */
async function collectFiles(deps, approvalId, targets) {
    const settled = await Promise.allSettled(targets.map(async (t) => deps.client.fetchDocument(approvalId, t.kind)));
    const files = [];
    const errors = [];
    settled.forEach((result, i) => {
        const target = targets[i];
        if (result.status === "rejected") {
            errors.push(describeFileError(target.kind, result.reason));
            return;
        }
        const doc = result.value;
        if (!doc || typeof doc.base64 !== "string" || doc.base64 === "") {
            errors.push(describeFileError(target.kind, { status: 404, code: "document_not_found" }));
        }
        else if (doc.size > MAX_DOCUMENT_BYTES) {
            errors.push(describeFileError(target.kind, { status: 413, code: "too_large" }));
        }
        else {
            files.push({ controlId: target.controlId, kind: target.kind, filename: doc.filename, mimeType: doc.mimeType, base64: doc.base64 });
        }
    });
    return { files, errors };
}
function readFilesAttached(raw, resumeAttached) {
    const out = emptyFilesAttached();
    for (const kind of FILE_KINDS)
        out[kind] = raw?.[kind] === true;
    if (resumeAttached === true)
        out.resume = true;
    return out;
}
const MAX_REPORTED_FIELDS = 100;
/** Label dan jenis kolom yang terisi, tanpa nilai. Hanya kontrol yang benar-benar terisi menurut skrip konten. */
function buildFilledFields(controls, filledIds) {
    if (!Array.isArray(controls) || !Array.isArray(filledIds))
        return [];
    const byId = new Map(controls.map((c) => [c.controlId, c]));
    const seen = new Set();
    const out = [];
    for (const rawId of filledIds) {
        const control = byId.get(String(rawId));
        if (!control || seen.has(control.controlId))
            continue;
        seen.add(control.controlId);
        const label = (control.label || control.groupLabel || control.name || control.placeholder || "")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 120);
        out.push({ label: label || "(tanpa label)", kind: reportKind(control.kind) });
        if (out.length >= MAX_REPORTED_FIELDS)
            break;
    }
    return out;
}
const REFILL_TARGET_MESSAGES = {
    tab_mismatch: "Tab aktif bukan tab yang tadi diisi. Pindah ke tab lowongan itu, lalu klik Simpan jawaban dan isi ulang lagi.",
    origin_mismatch: "Situs di tab ini berbeda dari halaman yang tadi diisi. Isi ulang dibatalkan.",
};
const REFILL_FRAME_MESSAGE = "Frame formulir yang tadi diisi sudah hilang atau berpindah situs. Isi ulang dibatalkan. Klik Isi Formulir Sekarang untuk mengisi dari awal.";
const MAX_PLAN_NOTICE_CHARS = 2500;
const cleanInline = (raw, max = 300) => typeof raw === "string" ? raw.replace(/\s+/g, " ").trim().slice(0, max) : "";
const cleanStringList = (raw, maxItems = 30, maxChars = 250) => {
    if (!Array.isArray(raw))
        return [];
    const out = [];
    for (const item of raw) {
        const cleaned = cleanInline(item, maxChars);
        if (cleaned && !out.includes(cleaned))
            out.push(cleaned);
        if (out.length >= maxItems)
            break;
    }
    return out;
};
const normalizeSigText = (raw, max = 300) => cleanInline(raw, max).toLowerCase();
/**
 * Sidik jari snapshot langkah formulir. Menyertakan `noticeText`, `validationErrors`, dan `errorText` per kontrol
 * agar kegagalan validasi di URL yang sama tidak dianggap "halaman tidak berubah".
 */
function snapshotSignature(snap) {
    const cleanUrl = stripUrlQueryAndHash(snap.pageUrl) ?? snap.pageUrl ?? "";
    const ctrls = (snap.controls ?? [])
        .map((c) => {
        const err = normalizeSigText(c.errorText, 200);
        return err ? `${c.controlId}:${c.kind}:${c.label}:${err}` : `${c.controlId}:${c.kind}:${c.label}`;
    })
        .join("|");
    const valErrs = cleanStringList(snap.validationErrors, 30, 200).map((e) => e.toLowerCase()).join("|");
    const notice = normalizeSigText(snap.noticeText, MAX_PLAN_NOTICE_CHARS);
    return `${cleanUrl}::${ctrls}::${valErrs}::${notice}`;
}
/** Gabungkan `noticeText`, `validationErrors`, `errorText` kontrol gagal, dan `sectionHeadings` untuk putaran retry/reread. */
function buildErrorContext(snap, primaryControls, extraControls = []) {
    const baseNotice = cleanInline(snap?.noticeText, MAX_PLAN_NOTICE_CHARS);
    const validationErrors = cleanStringList(snap?.validationErrors, 30, 250);
    for (const c of [...primaryControls, ...extraControls]) {
        const err = cleanInline(c?.errorText, 250);
        if (err && !validationErrors.includes(err))
            validationErrors.push(err);
    }
    const noticeParts = [];
    if (baseNotice)
        noticeParts.push(baseNotice);
    const baseLower = baseNotice.toLowerCase();
    for (const err of validationErrors) {
        if (!baseLower.includes(err.toLowerCase()))
            noticeParts.push(err);
    }
    return {
        noticeText: noticeParts.join("\n").slice(0, MAX_PLAN_NOTICE_CHARS),
        validationErrors,
        sectionHeadings: cleanStringList(snap?.sectionHeadings, 30, 200),
    };
}
/** ID kontrol yang gagal karena `element_gone` di `actionLog` terbaru, agar nilai sama boleh dicoba lagi pasca re-render. */
function elementGoneControlIds(actionLog) {
    const gone = new Set();
    if (!Array.isArray(actionLog))
        return gone;
    const lastByRef = new Map();
    for (const entry of actionLog) {
        if (!entry || typeof entry.ref !== "string")
            continue;
        if (entry.action === "set" || entry.action === "select" || entry.action === "check") {
            lastByRef.set(entry.ref, typeof entry.reason === "string" ? entry.reason : "");
        }
    }
    for (const [ref, reason] of lastByRef) {
        if (reason === "element_gone")
            gone.add(ref);
    }
    return gone;
}
function mergeFilledFieldList(target, additions) {
    const seen = new Set(target.map((f) => `${f.label}::${f.kind}`));
    for (const field of additions) {
        const key = `${field.label}::${field.kind}`;
        if (seen.has(key))
            continue;
        seen.add(key);
        target.push(field);
        if (target.length >= MAX_REPORTED_FIELDS)
            break;
    }
}
/**
 * Tunggu DOM halaman tenang sesudah klik (tanpa mutasi ~300 ms, paling lama ~4 detik) lewat `WAIT_SETTLE`. Gagal atau
 * tidak dijawab (skrip konten versi lama, frame sudah berpindah): kembali ke tidur tetap `fallbackMs`.
 */
async function waitForSettle(deps, tabId, frameId, fallbackMs) {
    try {
        const res = await deps.sendToTab(tabId, { type: "WAIT_SETTLE" }, frameId);
        if (res?.ok === true && typeof res.settled === "boolean")
            return;
    }
    catch {
        // Jatuh ke tidur tetap di bawah.
    }
    await deps.sleep(fallbackMs);
}
/** Hasil klik tombol (pembuka atau Lanjut) dari jawaban skrip konten, untuk catatan audit. */
function clickLogFields(res) {
    if (res?.clicked === true)
        return { result: "verified" };
    if (res === null || res === undefined)
        return { result: "unverified", reason: "no_response" };
    return { result: "skipped", reason: "no_button" };
}
/**
 * Pilih frame formulir. Dengan `wait`, ulangi (pilih ulang frame, suntik skrip konten, tanya `PROBE_FORM`) sampai ada
 * kolom isian atau tanda login/CAPTCHA: iframe formulir bisa baru muncul belakangan. Skrip konten yang tidak bisa
 * menjawab probe (versi lama) berarti lanjut seperti biasa. Satu-satunya tempat `deps.pickFrame` dipanggil.
 */
async function pickFrameWhenReady(deps, tabId, wait) {
    const maxPolls = Math.floor(FORM_WAIT_MAX_MS / FORM_WAIT_POLL_MS);
    const deadline = deps.now() + FORM_WAIT_MAX_MS;
    for (let i = 0;; i++) {
        if (i > 0)
            await deps.ensureContentScript(tabId).catch(() => undefined);
        const frameId = await deps.pickFrame(tabId);
        if (!wait)
            return { frameId, rendered: true };
        const res = await deps.sendToTab(tabId, { type: "PROBE_FORM" }, frameId).catch(() => null);
        const probe = res?.ok ? res.probe : null;
        if (!probe || typeof probe.fillable !== "number")
            return { frameId, rendered: true };
        if (probe.fillable > 0 || probe.blocker === true)
            return { frameId, rendered: true };
        if (i >= maxPolls || deps.now() >= deadline) {
            const foreignFrames = Array.isArray(probe.foreignFrames)
                ? probe.foreignFrames.filter((o) => typeof o === "string").slice(0, 3)
                : [];
            return { frameId, rendered: false, ...(foreignFrames.length > 0 ? { foreignFrames } : {}) };
        }
        await deps.sleep(FORM_WAIT_POLL_MS);
    }
}
/** Alasan laporan saat formulir tidak terbaca karena berada di iframe lintas-origin yang belum diizinkan. */
const FORM_IN_IFRAME_REASON = "form_in_iframe";
/**
 * Formulir tidak muncul di frame yang dipilih, tetapi ada iframe lintas-origin yang cukup besar (`foreignFrames`).
 * Bila ekstensi belum punya izin ke origin itu, iframe-nya tidak terbaca walau formulirnya terlihat di layar:
 * kembalikan host dan petunjuk berikutnya. Null bila tidak ada iframe, atau semua originnya sudah diizinkan (berarti
 * formulirnya memang tidak ada di sana). Hanya origin yang dibaca; path dan query iframe tidak pernah ikut.
 */
async function describeHiddenFormFrame(deps, origins) {
    for (const raw of origins ?? []) {
        const url = parseHttpUrl(raw);
        if (!url)
            continue;
        const hasAccess = deps.hasHostAccess ? await deps.hasHostAccess(url.origin).catch(() => false) : false;
        if (hasAccess)
            continue;
        const host = url.hostname.toLowerCase();
        // Hanya ATS, portal login, atau Google Forms (docs.google.com, izin path /forms/) yang bisa diminta izinnya lewat
        // tombol Izinkan; sisanya (Typeform, dan sebagainya) hanya bisa diisi lewat klik ikon ekstensi pada tab yang
        // membuka formulirnya.
        const requestable = url.protocol === "https:" && (hostIsExtensionSite(host) || host === GOOGLE_FORMS_HOST);
        if (requestable)
            await deps.noteHostNeedsPermission?.(permissionUrlForOrigin(url.origin)).catch(() => undefined);
        return {
            host,
            note: requestable
                ? `Formulir tampaknya ada di dalam iframe dari ${host}, dan ekstensi belum punya izin ke situs itu. Klik ${permissionButtonLabel(host)} di panel ekstensi, lalu isi lagi.`
                : `Formulir tampaknya ada di dalam iframe dari ${host}, situs yang tidak bisa diizinkan ekstensi. Buka formulirnya langsung di tab baru, lalu klik ikon ekstensi.`,
        };
    }
    return null;
}
/**
 * Isi formulir. Tanpa `locked`: tab aktif dipakai (atau `opts.tabOverride`) dan frame dipilih sekali. Dengan
 * `locked` (isi ulang sesudah jawaban disimpan): tab, origin, dan FRAME harus sama dengan sesi pengisian sebelumnya.
 */
async function fillInternal(deps, approval, locked, opts = {}) {
    if (!approval?.approvalId || !approval?.jobId) {
        return fail("Pilih lowongan yang sudah disetujui terlebih dahulu.", "no_approval");
    }
    if (await hasUnreportedFor(deps.localArea, approval.approvalId)) {
        return fail(UNREPORTED_WARNING, "unreported_result", { terminal: true });
    }
    const tab = opts.tabOverride ?? (await deps.getActiveTab());
    const effectiveQueueJobId = opts.queueJobId ?? approval.queueJobId ?? undefined;
    // Tab terkelola = pengisian antrean latar: sesinya terpisah per tab dan tidak menyentuh sesi manual milik panel.
    const queueRun = Boolean(opts.tabOverride);
    const leaseFields = effectiveQueueJobId && opts.leaseId ? { lease_id: opts.leaseId } : {};
    let leaseLost = false;
    /** Catatan audit seluruh pengisian ini (maks. 200). Tanpa nilai isian; lihat `lib/actionLog.ts`. */
    const actionLog = [];
    const actionLogField = () => (actionLog.length > 0 ? { actionLog: [...actionLog] } : {});
    /** Catat satu klik tombol dan kembalikan entrinya, supaya hasilnya bisa diturunkan bila halaman ternyata tidak berubah. */
    const recordClick = (ref, step, res) => {
        const before = actionLog.length;
        appendActionLog(actionLog, [{ ref, kind: "button", action: "click", ...clickLogFields(res) }], step);
        return actionLog.length > before ? actionLog[actionLog.length - 1] : null;
    };
    /** Lapor ke backend; `true` bila terkirim. 409 `lease_lost` pada antrean menandai sewa pindah ke browser lain. */
    const sendReport = async (payload) => {
        try {
            await deps.client.reportRun(payload);
            return true;
        }
        catch (err) {
            if (queueRun && isLeaseLostError(err))
                leaseLost = true;
            return false;
        }
    };
    const leaseLostResult = () => ({
        ok: false,
        leaseLost: true,
        reported: false,
        code: "lease_lost",
        error: "Tugas antrean sudah diambil browser lain.",
    });
    if (isLinkedInUrl(tab.url)) {
        return fail("LinkedIn hanya boleh dilamar manual (ekstensi dinonaktifkan di LinkedIn).", "linkedin_manual_only");
    }
    const tabId = tab.id;
    const tabOrigin = parseHttpUrl(tab.url)?.origin ?? null;
    if (!tabOrigin)
        return fail("Alamat tab tidak dapat dibaca. Pengisian dibatalkan.", "no_tab_url");
    // Mode tampil (antrean saja): overlay di halaman memberi tahu pengguna apa yang sedang dikerjakan. Hanya hiasan:
    // gagal menampilkannya tidak pernah mengubah hasil pengisian.
    const showOverlay = queueRun && opts.visible === true && typeof deps.overlay === "function";
    const overlay = async (message) => {
        if (!showOverlay)
            return;
        try {
            await deps.overlay(tabId, { type: "AGENT_OVERLAY", ...message });
        }
        catch {
            // Halaman berpindah atau skrip konten belum siap.
        }
    };
    /** Pengguna menekan Hentikan? Dicek di antara aksi; galat saat memeriksa tidak dianggap permintaan berhenti. */
    const stopRequested = async () => {
        if (!queueRun || !opts.shouldAbort)
            return false;
        try {
            return Boolean(await opts.shouldAbort());
        }
        catch {
            return false;
        }
    };
    const stoppedResult = () => ({
        ok: false,
        aborted: true,
        reported: false,
        code: USER_STOPPED_CODE,
        error: USER_STOPPED_ERROR,
    });
    if (locked) {
        const target = checkSubmitTarget(locked, tab);
        if (!target.ok)
            return fail(REFILL_TARGET_MESSAGES[target.code] ?? target.error, target.code);
        // Frame yang tadi diisi harus masih ada dengan origin yang sama. Tidak ada pemilihan ulang.
        const liveUrl = await deps.getFrameUrl(tabId, locked.frameId).catch(() => null);
        const frameCheck = checkSubmitFrame(locked, liveUrl);
        if (!frameCheck.ok) {
            await clearFillSession(deps.sessionArea);
            return fail(frameCheck.code === "linkedin_manual_only" ? frameCheck.error : REFILL_FRAME_MESSAGE, frameCheck.code);
        }
    }
    await deps.ensureContentScript(tabId);
    await overlay({ mode: "working", detail: "Membuka formulir" });
    if (await stopRequested())
        return stoppedResult();
    // Frame dipilih sekali di sini. Ekstraksi, pengisian, cek kolom kurang, klik kirim, dan deteksi hasil
    // semuanya memakai frame ini, supaya tidak ada langkah yang mendarat di frame lain. Isi ulang memakai frame sesi.
    let frameId;
    if (locked) {
        frameId = locked.frameId;
    }
    else {
        let picked = await pickFrameWhenReady(deps, tabId, queueRun && opts.waitForForm === true);
        frameId = picked.frameId;
        if (!picked.rendered) {
            // B5: Jika halaman masih menampilkan tombol pembuka ("Lamar", "Lamaran Cepat", "Apply", "Easy Apply"), klik
            // satu kali sebelum menganggap form tidak ditemukan, lalu tunggu lewat PROBE_FORM lagi.
            const ctaRes = await deps.sendToTab(tabId, { type: "CLICK_OPENING_CTA" }, frameId).catch(() => null);
            const ctaEntry = recordClick("opening_cta", 1, ctaRes);
            if (ctaRes?.clicked === true) {
                await waitForSettle(deps, tabId, frameId, SETTLE_FALLBACK_SLEEP_MS);
                picked = await pickFrameWhenReady(deps, tabId, true);
                frameId = picked.frameId;
                if (!picked.rendered && ctaEntry) {
                    ctaEntry.result = "unverified";
                    ctaEntry.reason = "form_not_opened";
                }
            }
        }
        if (!picked.rendered) {
            const notFoundUrl = stripUrlQueryAndHash(tab.url) ?? tab.url;
            // U2B-06: formulir yang terlihat di layar bisa berada di iframe lintas-origin yang tidak terbaca karena izin
            // hostnya belum ada. Alasannya disebut jelas (host dan langkah berikutnya), bukan "tidak muncul" saja.
            const hidden = await describeHiddenFormFrame(deps, picked.foreignFrames);
            const reported = await sendReport({
                approvalId: approval.approvalId,
                jobId: approval.jobId,
                pageUrl: notFoundUrl,
                ...(effectiveQueueJobId ? { queueJobId: effectiveQueueJobId } : {}),
                ...leaseFields,
                outcome: "incomplete",
                reason: hidden ? FORM_IN_IFRAME_REASON : "form_not_found",
                filledCount: 0,
                remainingRequired: 0,
                ...actionLogField(),
            });
            if (leaseLost)
                return leaseLostResult();
            return {
                ok: true,
                blocked: null,
                formNotFound: true,
                reported,
                note: hidden?.note ?? "Formulir lamaran tidak muncul di halaman.",
                ...(hidden ? { foreignFrameHost: hidden.host } : {}),
            };
        }
    }
    let snapRes = await deps.sendToTab(tabId, { type: "EXTRACT_FORM" }, frameId);
    if (!snapRes?.ok)
        return fail(snapRes?.error ?? "Gagal membaca formulir tab.", "extract_failed");
    // B5 cadangan untuk jalur manual / non-waitForForm ketika halaman lowongan belum membuka form.
    if (!locked && !snapRes.snapshot.hasPasswordInput && !snapRes.snapshot.hasCaptchaIframe && snapRes.snapshot.hasOpeningCta === true) {
        const ctaRes = await deps.sendToTab(tabId, { type: "CLICK_OPENING_CTA" }, frameId).catch(() => null);
        recordClick("opening_cta", 1, ctaRes);
        if (ctaRes?.clicked === true) {
            if (queueRun && opts.waitForForm === true) {
                const picked = await pickFrameWhenReady(deps, tabId, true);
                frameId = picked.frameId;
            }
            else {
                await waitForSettle(deps, tabId, frameId, SETTLE_FALLBACK_SLEEP_MS);
            }
            const nextSnap = await deps.sendToTab(tabId, { type: "EXTRACT_FORM" }, frameId);
            if (nextSnap?.ok)
                snapRes = nextSnap;
        }
    }
    const maxSteps = locked ? 1 : MAX_FORM_STEPS;
    let stepsCount = 0;
    let totalFilledCount = 0;
    const allFilledFields = [];
    const mergedFilesAttached = emptyFilesAttached();
    const allFileErrors = [];
    let prevStepSig = null;
    /** Putaran kedua yang sudah dijalankan dalam pengisian ini, terhadap `MAX_RETRY_PASSES_PER_RUN`. */
    let retryPasses = 0;
    /** Putaran baca ulang yang sudah dijalankan dalam pengisian ini, terhadap `MAX_REREAD_ROUNDS_PER_RUN`. */
    let rereadRounds = 0;
    /** Mati untuk sisa pengisian bila AI gagal, kena batas permintaan, halaman terblokir, atau putaran kedua galat. */
    let retriesEnabled = true;
    /** Klik Lanjut dari langkah sebelumnya, menunggu bukti bahwa halaman benar-benar berganti. */
    let pendingNextClick = null;
    let lastStep = null;
    for (let step = 1; step <= maxSteps; step++) {
        if (step > 1) {
            if (queueRun && opts.waitForForm === true) {
                const picked = await pickFrameWhenReady(deps, tabId, true);
                if (picked.rendered)
                    frameId = picked.frameId;
            }
            const nextSnap = await deps.sendToTab(tabId, { type: "EXTRACT_FORM" }, frameId);
            if (!nextSnap?.ok)
                break;
            snapRes = nextSnap;
            const sig = snapshotSignature(snapRes.snapshot);
            if (prevStepSig !== null && sig === prevStepSig) {
                await waitForSettle(deps, tabId, frameId, SETTLE_RETRY_FALLBACK_SLEEP_MS);
                const retrySnap = await deps.sendToTab(tabId, { type: "EXTRACT_FORM" }, frameId);
                if (!retrySnap?.ok || snapshotSignature(retrySnap.snapshot) === prevStepSig) {
                    if (pendingNextClick) {
                        pendingNextClick.result = "unverified";
                        pendingNextClick.reason = "page_unchanged";
                    }
                    break;
                }
                snapRes = retrySnap;
            }
        }
        pendingNextClick = null;
        prevStepSig = snapshotSignature(snapRes.snapshot);
        if (await stopRequested())
            return stoppedResult();
        await overlay({ mode: "working", detail: `Langkah ${step}: membaca formulir` });
        // `pageUrl` dari skrip konten adalah URL frame yang dibaca, bukan URL tab.
        const pageUrl = snapRes.snapshot.pageUrl;
        const frameOrigin = parseHttpUrl(pageUrl)?.origin ?? null;
        if (!frameOrigin) {
            if (lastStep)
                break;
            return fail("Alamat frame formulir tidak dapat dibaca. Pengisian dibatalkan.", "no_frame_url");
        }
        if (locked && frameOrigin !== locked.frameOrigin) {
            await clearFillSession(deps.sessionArea);
            return fail(REFILL_FRAME_MESSAGE, "frame_origin_changed");
        }
        // Dropdown kustom yang masih tertutup dibuka sebentar supaya perencana melihat pilihan yang ditawarkan halaman.
        // Tidak ada opsi yang dipilih. Halaman login atau CAPTCHA tidak disentuh. Gagal diintip: pakai kontrol apa adanya.
        let stepControls = snapRes.snapshot.controls;
        const peekIds = snapRes.snapshot.hasPasswordInput || snapRes.snapshot.hasCaptchaIframe ? [] : selectPeekTargets(stepControls);
        if (peekIds.length > 0) {
            const peekRes = await deps.sendToTab(tabId, { type: "PEEK_COMBOBOX_OPTIONS", controlIds: peekIds }, frameId).catch(() => null);
            if (peekRes?.ok === true) {
                appendActionLog(actionLog, peekRes.actionLog, step);
                stepControls = markSearchable(applyPeekedOptions(stepControls, peekRes.peeks), peekRes.peeks);
            }
        }
        const initSnap = snapRes.snapshot;
        const initHeadings = cleanStringList(initSnap.sectionHeadings, 30, 200);
        const initValErrors = cleanStringList(initSnap.validationErrors, 30, 250);
        const initialPlanPayload = {
            approvalId: approval.approvalId,
            jobId: approval.jobId,
            pageUrl,
            noticeText: initSnap.noticeText,
            hasPasswordInput: initSnap.hasPasswordInput,
            ...(initSnap.hasCaptchaIframe ? { hasCaptchaIframe: true } : {}),
            ...(typeof initSnap.hasOpeningCta === "boolean" ? { hasOpeningCta: initSnap.hasOpeningCta } : {}),
            ...(typeof initSnap.formRootFound === "boolean" ? { formRootFound: initSnap.formRootFound } : {}),
            ...(initHeadings.length > 0 ? { sectionHeadings: initHeadings } : {}),
            ...(initValErrors.length > 0 ? { validationErrors: initValErrors } : {}),
            controls: stepControls,
        };
        const plan = await deps.client.planForm(initialPlanPayload);
        // AI gagal (galat penyedia atau kuota habis): putaran kedua akan menabrak hal yang sama.
        if (plan.aiError)
            retriesEnabled = false;
        if (await stopRequested())
            return stoppedResult();
        if (plan.blocked) {
            // Halaman tidak bisa diisi: sesi lama (bila ada) tidak lagi mewakili formulir yang terisi.
            await clearFillSession(deps.sessionArea, queueRun ? queueFillSessionKey(tabId) : FILL_SESSION_KEY);
            if (plan.blocked === "auth_required" && opts.waitOnAuthRequired) {
                const cleanLoginUrl = stripUrlQueryAndHash(pageUrl);
                let reported = false;
                if (opts.reportAwaitingLogin !== false) {
                    reported = await sendReport({
                        approvalId: approval.approvalId,
                        jobId: approval.jobId,
                        pageUrl: cleanLoginUrl ?? pageUrl,
                        ...(effectiveQueueJobId ? { queueJobId: effectiveQueueJobId } : {}),
                        ...leaseFields,
                        ...(opts.awaitingUntilIso ? { awaitingUntil: opts.awaitingUntilIso } : {}),
                        ...(cleanLoginUrl ? { loginUrl: cleanLoginUrl } : {}),
                        outcome: "awaiting_login",
                        reason: "awaiting_login",
                        filledCount: totalFilledCount,
                        ...(stepsCount > 0 ? { stepsCount } : {}),
                        remainingRequired: countRemainingRequired(plan.pendingQuestions),
                        questions: plan.pendingQuestions,
                        ...actionLogField(),
                    });
                    if (leaseLost)
                        return leaseLostResult();
                }
                return {
                    ok: false,
                    awaitingLogin: true,
                    reported,
                    code: "auth_required",
                    error: plan.note ?? "Portal mewajibkan login pelamar.",
                    loginUrl: cleanLoginUrl,
                    blocked: plan.blocked,
                    note: plan.note,
                    plan,
                };
            }
            const reported = await sendReport({
                approvalId: approval.approvalId,
                jobId: approval.jobId,
                pageUrl,
                ...(effectiveQueueJobId ? { queueJobId: effectiveQueueJobId } : {}),
                ...leaseFields,
                outcome: "incomplete",
                reason: plan.blocked,
                filledCount: totalFilledCount,
                ...(stepsCount > 0 ? { stepsCount } : {}),
                remainingRequired: countRemainingRequired(plan.pendingQuestions),
                questions: plan.pendingQuestions,
                ...actionLogField(),
            });
            if (leaseLost)
                return leaseLostResult();
            return { ok: true, blocked: plan.blocked, reported, note: plan.note, plan };
        }
        const plannedCount = Array.isArray(plan.actions) ? plan.actions.length : 0;
        await overlay({
            mode: "working",
            detail: plannedCount > 0 ? `Langkah ${step}: mengisi ${plannedCount} kolom` : `Langkah ${step}: memeriksa kolom`,
        });
        // Berkas per input file (rencana server). Jalur lama `resumeUrl` hanya cadangan bila rencana berkas kosong.
        const fileTargets = normalizeFileTargets(plan.fileTargets);
        const fetched = fileTargets.length > 0 ? await collectFiles(deps, approval.approvalId, fileTargets) : { files: [], errors: [] };
        const useLegacyResume = fileTargets.length === 0 && Boolean(plan.resumeUrl);
        const resumeBase64 = useLegacyResume ? await deps.fetchResumeBase64(plan.resumeUrl) : null;
        // Grup radio pemilih sumber CV ("Unggah file" lawan "CV profil") yang ditandai pembaca formulir: dibuka lebih dulu
        // oleh skrip konten bila input file tersembunyi.
        const cvSourceId = stepControls.find((c) => c.kind === "radio" && c.cvSourceUpload === true)?.controlId;
        const filesToSend = cvSourceId ? fetched.files.map((f) => (f.kind === "resume" ? { ...f, sourceControlId: cvSourceId } : f)) : fetched.files;
        const fillRes = await deps.sendToTab(tabId, {
            type: "APPLY_FILL_PLAN",
            actions: plan.actions,
            fileControlId: useLegacyResume ? plan.fileControlId : null,
            resumeBase64,
            files: filesToSend,
        }, frameId);
        if (!fillRes?.ok) {
            if (lastStep)
                break;
            return fail("Gagal menuliskan nilai ke formulir tab.", "fill_failed");
        }
        let summary = fillRes.summary;
        const firstPassSummary = summary;
        // Kolom yang baru terisi berkedip sebentar (hanya garis tepi; tidak mengubah isian halaman).
        await overlay({
            mode: "highlight",
            controlIds: Array.isArray(summary?.filledControlIds) ? summary.filledControlIds.map(String) : [],
            detail: `Langkah ${step}: ${Number(summary?.filledCount ?? 0)} kolom terisi`,
        });
        if (await stopRequested())
            return stoppedResult();
        // Putaran kedua (amati, bertindak, verifikasi): kontrol yang aksinya sudah ada tetapi gagal/tidak menempel sesudah
        // dibaca ulang direncanakan ulang SATU kali dengan kode alasan, `noticeText`, dan pesan error validasi aktual.
        let retried = null;
        if (retriesEnabled && retryPasses < MAX_RETRY_PASSES_PER_RUN) {
            const residual = buildRetryPlan({
                controls: stepControls,
                unfilledControlIds: summary?.unfilledControlIds,
                actionLog: summary?.actionLog,
            });
            if (residual.controls.length > 0) {
                if (await stopRequested())
                    return stoppedResult();
                retryPasses++;
                const retrySnapRes = await deps.sendToTab(tabId, { type: "EXTRACT_FORM", keepFilled: true }, frameId).catch(() => null);
                const retrySnap = retrySnapRes?.ok === true && retrySnapRes.snapshot ? retrySnapRes.snapshot : snapRes.snapshot;
                const freshById = new Map((Array.isArray(retrySnap.controls) ? retrySnap.controls : []).map((c) => [c.controlId, c]));
                const residualControls = residual.controls.map((c) => {
                    const freshErr = cleanInline(freshById.get(c.controlId)?.errorText, 250);
                    return freshErr ? { ...c, errorText: freshErr } : c;
                });
                const retryErrCtx = buildErrorContext(retrySnap, residualControls);
                const retryPayload = {
                    approvalId: approval.approvalId,
                    jobId: approval.jobId,
                    pageUrl,
                    noticeText: retryErrCtx.noticeText,
                    hasPasswordInput: Boolean(retrySnap.hasPasswordInput),
                    ...(retrySnap.hasCaptchaIframe ? { hasCaptchaIframe: true } : {}),
                    ...(typeof retrySnap.hasOpeningCta === "boolean" ? { hasOpeningCta: retrySnap.hasOpeningCta } : {}),
                    ...(typeof retrySnap.formRootFound === "boolean" ? { formRootFound: retrySnap.formRootFound } : {}),
                    ...(retryErrCtx.sectionHeadings.length > 0 ? { sectionHeadings: retryErrCtx.sectionHeadings } : {}),
                    ...(retryErrCtx.validationErrors.length > 0 ? { validationErrors: retryErrCtx.validationErrors } : {}),
                    // Pilihan yang benar-benar terlihat di dropdown yang gagal dipilih: perencana memilih dari daftar nyata.
                    controls: applyPeekedOptions(residualControls, firstPassSummary?.observedOptions),
                    retryHints: residual.hints,
                };
                let retryPlan = null;
                try {
                    retryPlan = await deps.client.planForm(retryPayload);
                }
                catch {
                    // Kena batas permintaan, kuota, atau jaringan: hasil putaran pertama dipakai apa adanya dan tidak diulang lagi.
                    retriesEnabled = false;
                }
                if (retryPlan && (retryPlan.blocked || retryPlan.aiError))
                    retriesEnabled = false;
                const retryActions = retryPlan && !retryPlan.blocked
                    ? selectRetryActions(retryPlan.actions, new Set(residualControls.map((c) => c.controlId)), plan.actions, elementGoneControlIds(summary?.actionLog))
                    : [];
                if (retryActions.length > 0) {
                    const retryRes = await deps
                        .sendToTab(tabId, { type: "APPLY_FILL_PLAN", actions: retryActions, fileControlId: null, resumeBase64: null, files: [] }, frameId)
                        .catch(() => null);
                    if (retryRes?.ok === true && retryRes.summary) {
                        retried = retryRes.summary;
                        summary = mergeRetrySummary(firstPassSummary, retried);
                    }
                }
            }
        }
        // Putaran baca ulang: halaman dibaca lagi sesudah diisi. Kolom yang baru muncul atau select yang pilihannya baru
        // terisi direncanakan dan diisi, paling banyak 2 kali per langkah. Tidak pernah mengklik kirim.
        const rereadPending = [];
        const rereadAsked = new Set();
        // Hanya bila langkah ini memilih sesuatu (radio, select, centang): kolom bersyarat muncul dari pilihan, bukan dari
        // ketikan teks. Tanpa pilihan, halaman tidak dibaca ulang dan tidak ada jeda tambahan.
        const choiceIds = new Set(stepControls.filter((c) => c.kind === "radio" || c.kind === "select" || c.kind === "checkbox").map((c) => c.controlId));
        let choiceMade = (Array.isArray(summary?.filledControlIds) ? summary.filledControlIds.map(String) : []).some((id) => choiceIds.has(id));
        // Pembacaan terakhir yang berhasil: kontrol yang hilang darinya (ditutup oleh pilihan tadi) tidak lagi ditanyakan.
        let liveAfterReread;
        for (let round = 0; choiceMade && retriesEnabled && round < MAX_REREAD_ROUNDS_PER_STEP && rereadRounds < MAX_REREAD_ROUNDS_PER_RUN; round++) {
            if (await stopRequested())
                return stoppedResult();
            await waitForSettle(deps, tabId, frameId, SETTLE_FALLBACK_SLEEP_MS);
            const again = await deps.sendToTab(tabId, { type: "EXTRACT_FORM", keepFilled: true }, frameId).catch(() => null);
            if (again?.ok !== true || !again.snapshot || again.snapshot.hasPasswordInput || again.snapshot.hasCaptchaIframe)
                break;
            const rereadSnap = again.snapshot;
            liveAfterReread = rereadSnap.controls;
            // Sudah ditangani: terisi, sudah ditanyakan, atau sudah diminta di putaran baca ulang sebelumnya. Kontrol lama
            // yang pilihannya tidak berubah dilewati oleh selectRereadTargets.
            const handled = new Set([
                ...(Array.isArray(summary?.filledControlIds) ? summary.filledControlIds.map(String) : []),
                ...(plan.pendingQuestions ?? []).map((q) => q.key),
                ...rereadPending.map((q) => q.key),
                ...rereadAsked,
            ]);
            const ask = selectRereadTargets(stepControls, rereadSnap.controls, handled);
            if (ask.length === 0)
                break;
            rereadRounds++;
            const rereadErrCtx = buildErrorContext(rereadSnap, ask, rereadSnap.controls);
            const rereadPayload = {
                approvalId: approval.approvalId,
                jobId: approval.jobId,
                pageUrl,
                noticeText: rereadErrCtx.noticeText,
                hasPasswordInput: Boolean(rereadSnap.hasPasswordInput),
                ...(rereadSnap.hasCaptchaIframe ? { hasCaptchaIframe: true } : {}),
                ...(typeof rereadSnap.hasOpeningCta === "boolean" ? { hasOpeningCta: rereadSnap.hasOpeningCta } : {}),
                ...(typeof rereadSnap.formRootFound === "boolean" ? { formRootFound: rereadSnap.formRootFound } : {}),
                ...(rereadErrCtx.sectionHeadings.length > 0 ? { sectionHeadings: rereadErrCtx.sectionHeadings } : {}),
                ...(rereadErrCtx.validationErrors.length > 0 ? { validationErrors: rereadErrCtx.validationErrors } : {}),
                controls: ask,
            };
            let rereadPlan = null;
            try {
                rereadPlan = await deps.client.planForm(rereadPayload);
            }
            catch {
                retriesEnabled = false;
                break;
            }
            if (!rereadPlan || rereadPlan.blocked || rereadPlan.aiError) {
                retriesEnabled = false;
                break;
            }
            const askIds = new Set(ask.map((c) => c.controlId));
            for (const id of askIds)
                rereadAsked.add(id);
            stepControls = [...stepControls.filter((c) => !askIds.has(c.controlId)), ...ask];
            for (const q of rereadPlan.pendingQuestions ?? []) {
                if (askIds.has(q.key) && !rereadPending.some((p) => p.key === q.key))
                    rereadPending.push(q);
            }
            const actions = selectRereadActions(rereadPlan.actions, askIds);
            if (actions.length === 0)
                continue;
            const rereadRes = await deps
                .sendToTab(tabId, { type: "APPLY_FILL_PLAN", actions, fileControlId: null, resumeBase64: null, files: [] }, frameId)
                .catch(() => null);
            if (rereadRes?.ok !== true || !rereadRes.summary)
                break;
            const rereadSummary = rereadRes.summary;
            choiceMade = (Array.isArray(rereadSummary.filledControlIds) ? rereadSummary.filledControlIds.map(String) : []).some((id) => ask.some((c) => c.controlId === id && (c.kind === "radio" || c.kind === "select" || c.kind === "checkbox")));
            // mergeRetrySummary mencoret kontrol yang terisi di putaran ini; kontrol baru yang gagal ditambahkan.
            const merged = mergeRetrySummary(summary, rereadSummary);
            summary = {
                ...merged,
                unfilledControlIds: [
                    ...(Array.isArray(merged.unfilledControlIds) ? merged.unfilledControlIds.map(String) : []),
                    ...(Array.isArray(rereadSummary.unfilledControlIds) ? rereadSummary.unfilledControlIds.map(String) : []),
                ],
            };
            await overlay({
                mode: "highlight",
                controlIds: Array.isArray(rereadSummary.filledControlIds) ? rereadSummary.filledControlIds.map(String) : [],
                detail: `Langkah ${step}: ${Number(rereadSummary.filledCount ?? 0)} kolom baru terisi`,
            });
        }
        const filesAttached = readFilesAttached(summary?.filesAttached, summary?.resumeAttached);
        const stepFilledFields = buildFilledFields(stepControls, summary?.filledControlIds);
        // Kolom pilihan yang tidak bisa diisi tanpa menebak (dropdown kustom) dilaporkan sebagai pertanyaan belum terjawab.
        // Kontrol yang terisi di putaran kedua dicoret; yang masih gagal tetap menjadi pertanyaan.
        const fileErrors = [...fetched.errors];
        for (const target of fileTargets) {
            if (!filesAttached[target.kind] && !fileErrors.some((e) => e.kind === target.kind)) {
                fileErrors.push({
                    kind: target.kind,
                    code: "attach_failed",
                    message: `Berkas ${FILE_KIND_LABELS[target.kind]} gagal dipasang di halaman. Unggah sendiri.`,
                });
            }
        }
        // Kontrol yang tadinya ada tetapi sudah hilang dari halaman sesudah baca ulang (sub-kolom yang ditutup pilihan
        // tadi) dicoret dari pertanyaan dan dari daftar belum terisi, supaya panel tidak menanyakan kolom yang sudah tutup.
        const goneControlIds = findVanishedControlIds(stepControls, liveAfterReread);
        if (goneControlIds.size > 0) {
            // Hitungan kolom wajib kurang dibuat sebelum kolom itu tutup: kurangi yang sudah hilang, jangan sampai di bawah
            // jumlah kolom wajib kosong yang masih tampil di pembacaan terakhir.
            const stillMissing = pruneMissingRequired({ count: Number(summary?.missingRequiredCount), labels: summary?.missingLabels }, stepControls, goneControlIds, new Set(idList(summary?.filledControlIds)), liveAfterReread);
            summary = {
                ...summary,
                unfilledControlIds: idList(summary?.unfilledControlIds).filter((id) => !goneControlIds.has(id)),
                missingRequiredCount: stillMissing.count,
                missingLabels: stillMissing.labels,
            };
        }
        // Berkas yang tidak terpasang atau tidak terbukti masuk (tanpa bukti di antarmuka) menjadi pertanyaan "unggah manual".
        const pendingQuestions = withFileQuestions(mergeUnfilledQuestions(dropVanishedQuestions([...(plan.pendingQuestions ?? []), ...rereadPending], goneControlIds), summary?.unfilledControlIds, stepControls, retried), fileTargets.filter((t) => !filesAttached[t.kind]), stepControls);
        appendActionLog(actionLog, summary?.actionLog, step);
        stepsCount++;
        totalFilledCount += summary.filledCount;
        mergeFilledFieldList(allFilledFields, stepFilledFields);
        for (const kind of FILE_KINDS) {
            if (filesAttached[kind])
                mergedFilesAttached[kind] = true;
        }
        for (const fe of fileErrors) {
            if (!allFileErrors.some((existing) => existing.kind === fe.kind && existing.code === fe.code)) {
                allFileErrors.push(fe);
            }
        }
        lastStep = { pageUrl, frameId, frameOrigin, plan, summary, pendingQuestions, controls: stepControls };
        // B3: Jangan pernah mengklik Submit. Maju ke langkah berikutnya hanya jika bukan langkah akhir & tidak ada kolom wajib yang tertinggal.
        if (locked || plan.submitControlId || summary.missingRequiredCount > 0 || step >= maxSteps) {
            break;
        }
        if (await stopRequested())
            return stoppedResult();
        const nextRes = await deps.sendToTab(tabId, { type: "CLICK_NEXT_STEP" }, frameId).catch(() => null);
        const nextEntry = recordClick("next_step", step, nextRes);
        if (nextRes?.clicked !== true)
            break;
        pendingNextClick = nextEntry;
        await waitForSettle(deps, tabId, frameId, SETTLE_FALLBACK_SLEEP_MS);
    }
    if (!lastStep) {
        return fail("Gagal menuliskan nilai ke formulir tab.", "fill_failed");
    }
    if (await stopRequested())
        return stoppedResult();
    // Penegasan akhir: isian teks yang tadinya terverifikasi dibaca lagi. Form yang menginisialisasi ulang, topeng yang
    // memformat ulang, atau halaman yang memuat data awal belakangan bisa mengosongkannya setelah laporan "terisi".
    // Yang berubah ditulis ulang satu kali; yang tetap berubah menjadi pertanyaan (`unverified:reverted`), bukan "terisi".
    await overlay({ mode: "working", detail: "Memeriksa ulang isian" });
    const reassertRes = await deps.sendToTab(tabId, { type: "REASSERT_FILLED" }, lastStep.frameId).catch(() => null);
    const reassert = reassertRes?.ok === true ? reassertRes.summary : null;
    if (reassert) {
        appendActionLog(actionLog, reassert.actionLog, Math.max(1, stepsCount));
        const reverted = idList(reassert.reverted);
        if (reverted.length > 0) {
            const gone = new Set(reverted);
            const revertedRequired = lastStep.controls.filter((c) => gone.has(c.controlId) && c.required === true).length;
            totalFilledCount = Math.max(0, totalFilledCount - reverted.length);
            for (const f of buildFilledFields(lastStep.controls, reverted)) {
                const at = allFilledFields.findIndex((x) => x.label === f.label && x.kind === f.kind);
                if (at >= 0)
                    allFilledFields.splice(at, 1);
            }
            const missingNow = Number(reassert.missing?.count);
            lastStep = {
                ...lastStep,
                summary: {
                    ...lastStep.summary,
                    filledControlIds: idList(lastStep.summary.filledControlIds).filter((id) => !gone.has(id)),
                    unfilledControlIds: [...new Set([...idList(lastStep.summary.unfilledControlIds), ...reverted])],
                    missingRequiredCount: Math.max(Number.isFinite(missingNow) ? missingNow : 0, revertedRequired, lastStep.summary.missingRequiredCount),
                },
                pendingQuestions: mergeUnfilledQuestions(lastStep.pendingQuestions, reverted, lastStep.controls, null),
            };
        }
    }
    if (await stopRequested())
        return stoppedResult();
    // Tangkapan layar bukti: overlay disembunyikan lebih dulu supaya gambarnya menunjukkan formulir, bukan lencana
    // (cahaya tepi ikut disembunyikan; bukti harus bersih). Muncul lagi sesudahnya, juga bila pengambilan gagal.
    await overlay({ mode: "capture_hide" });
    let filledScreenshot;
    try {
        filledScreenshot = await deps.captureEvidence(tabId, approval.applyUrl);
    }
    finally {
        await overlay({ mode: "capture_show" });
    }
    if (await stopRequested())
        return stoppedResult();
    const aggregatedSummary = {
        ...lastStep.summary,
        filledCount: totalFilledCount,
        filesAttached: mergedFilesAttached,
        resumeAttached: mergedFilesAttached.resume,
    };
    const session = {
        version: 1,
        runId: deps.newRunId(),
        approvalId: approval.approvalId,
        jobId: approval.jobId,
        tabId,
        tabOrigin,
        frameId: lastStep.frameId,
        frameOrigin: lastStep.frameOrigin,
        pageUrl: lastStep.pageUrl,
        applyUrl: approval.applyUrl,
        submitControlId: lastStep.plan.submitControlId,
        filledCount: totalFilledCount,
        missingRequiredCount: lastStep.summary.missingRequiredCount,
        pendingQuestions: lastStep.pendingQuestions,
        filesAttached: mergedFilesAttached,
        filledFields: allFilledFields,
        filledScreenshot,
        createdAt: deps.now(),
    };
    if (queueRun) {
        await saveQueueFillSession(deps.sessionArea, session);
    }
    else {
        await saveFillSession(deps.sessionArea, session);
        // Isi ulang manual (mis. Simpan jawaban dan isi ulang) menggantikan sesi antrean tab ini. Dibiarkan, sesi antrean
        // lama menjadi sesi hantu sesudah sesi manual dihapus (audit U2B-03).
        await clearQueueFillSession(deps.sessionArea, tabId).catch(() => undefined);
    }
    // Langkah berikutnya bagi pengguna saat berhenti tanpa tombol kirim akhir (atau masih ada kolom wajib): hanya membaca
    // halaman, tidak mengklik apa pun. Gagal membaca tidak menggagalkan laporan, daftar tetap berisi langkah dari pertanyaan.
    let nextSteps = [];
    const stoppedBeforeFinal = !lastStep.plan.submitControlId || lastStep.summary.missingRequiredCount > 0;
    if (stoppedBeforeFinal) {
        let hints = null;
        if (!lastStep.plan.submitControlId) {
            const hintRes = await deps.sendToTab(tabId, { type: "DETECT_NEXT_STEPS" }, lastStep.frameId).catch(() => null);
            hints = hintRes?.ok === true && hintRes.hints ? hintRes.hints : null;
        }
        nextSteps = buildNextSteps({ hints, questions: lastStep.pendingQuestions, hasSubmitControl: Boolean(lastStep.plan.submitControlId) });
    }
    // Laporan "ready"/"incomplete" hanya informatif: gagal lapor tidak boleh membatalkan hasil pengisian.
    let reportWarning = null;
    let reported = false;
    try {
        await deps.client.reportRun({
            approvalId: approval.approvalId,
            jobId: approval.jobId,
            pageUrl: lastStep.pageUrl,
            ...(effectiveQueueJobId ? { queueJobId: effectiveQueueJobId } : {}),
            ...leaseFields,
            outcome: lastStep.summary.missingRequiredCount === 0 && lastStep.plan.submitControlId ? "ready" : "incomplete",
            reason: lastStep.summary.missingRequiredCount > 0 ? "partly_filled" : null,
            filledCount: totalFilledCount,
            stepsCount,
            remainingRequired: remainingRequiredForReport(lastStep.pendingQuestions, lastStep.summary.missingRequiredCount),
            questions: lastStep.pendingQuestions,
            filesAttached: mergedFilesAttached,
            filledFields: allFilledFields,
            filledScreenshot,
            ...(nextSteps.length > 0 ? { nextSteps } : {}),
            ...actionLogField(),
        });
        reported = true;
    }
    catch (err) {
        if (queueRun && isLeaseLostError(err))
            return leaseLostResult();
        reportWarning = `Formulir terisi, tetapi catatan ke Applify gagal: ${describeError(err).message}`;
    }
    return {
        ok: true,
        blocked: null,
        reported,
        stepsCount,
        summary: aggregatedSummary,
        plan: lastStep.plan,
        /** Daftar pertanyaan sesudah digabung dengan kolom pilihan yang tidak terisi. Inilah yang ditampilkan panel. */
        questions: lastStep.pendingQuestions,
        files: { attached: mergedFilesAttached, errors: allFileErrors },
        session: summarizeSession(session, tab),
        reportWarning,
    };
}
function runFill(deps, approval) {
    return fillInternal(deps, approval, null);
}
/** Mengisi formulir pada tab terkelola (dipakai ExtensionQueueRunner). Tidak pernah memanggil authorizeSubmit. */
function runFillOnTab(deps, approval, tab, opts = {}) {
    // Antrean selalu menunggu formulir SPA tergambar kecuali pemanggil menolak secara eksplisit.
    return fillInternal(deps, approval, null, { waitForForm: true, ...opts, tabOverride: tab });
}
/**
 * Simpan jawaban dari panel ke backend, lalu isi ulang di tab dan frame yang sama dengan pengisian sebelumnya.
 * Jawaban disimpan lebih dulu: ketikan pengguna tidak boleh hilang hanya karena isi ulang tidak bisa jalan
 * (tab lain, frame hilang). Tanpa sesi pengisian untuk persetujuan ini, tidak ada isi ulang otomatis: frame tidak
 * dipilih ulang di sini, pengguna menjalankan Isi Formulir Sekarang.
 */
async function runSaveAnswersAndRefill(deps, approval, rawAnswers, opts = {}) {
    if (!approval?.approvalId || !approval?.jobId) {
        return fail("Pilih lowongan yang sudah disetujui terlebih dahulu.", "no_approval");
    }
    // Jawaban untuk kolom `secret_skip` TIDAK PERNAH dikirim (backend menolak seluruh permintaan dengan secret_question).
    // Panel tidak membuat isian untuk kolom itu; penyaringan ini hanya lapisan kedua, berdasarkan sesi pengisian.
    // Sesi manual milik tab aktif, atau sesi antrean latar tab itu (formulir yang diisi di latar lalu dijawab dari panel).
    const activeTab = await deps.getActiveTab().catch(() => null);
    const session = (await loadFillSessionForTab(deps.sessionArea, activeTab?.id))?.session ?? null;
    const secrets = (session && session.approvalId === approval.approvalId ? session.pendingQuestions : []).filter((q) => q.kind === "secret_skip");
    const secretKeys = new Set(secrets.map((q) => q.key));
    const secretLabels = new Set(secrets.map((q) => q.label.trim().toLowerCase()));
    const answers = sanitizeAnswers(rawAnswers).filter((a) => !secretKeys.has(a.key) && !secretLabels.has(a.label.trim().toLowerCase()));
    // Pengguna bisa menjawab di halaman Persetujuan Applify (jawaban sudah tersimpan di backend), lalu menekan tombol panel
    // tanpa mengetik apa pun. Dengan `useSavedAnswers`, tidak ada yang disimpan: backend memakai jawaban tersimpan saat
    // menyusun ulang rencana isian, dan pertanyaan yang tersisa dibaca ulang dari hasil isi ulang itu.
    if (answers.length === 0 && opts.useSavedAnswers !== true)
        return fail("Isi minimal satu jawaban sebelum menyimpan.", "no_answers");
    let saved = 0;
    if (answers.length > 0) {
        try {
            const res = await deps.client.saveAnswers({ approvalId: approval.approvalId, answers });
            saved = Number.isFinite(res?.saved) ? Number(res.saved) : answers.length;
        }
        catch (err) {
            const mapped = describeError(err);
            return fail(mapped.message, mapped.code, { status: mapped.status, terminal: mapped.terminal });
        }
    }
    if (!session || session.approvalId !== approval.approvalId) {
        return fail(saved > 0
            ? "Jawaban tersimpan, tetapi sesi pengisian untuk lowongan ini tidak ditemukan. Klik Isi Formulir Sekarang untuk mengisi ulang."
            : "Sesi pengisian untuk lowongan ini tidak ditemukan di tab aktif. Klik Isi Formulir Sekarang untuk mengisi ulang; jawaban yang sudah tersimpan di Applify ikut dipakai.", "no_session", { saved });
    }
    const res = await fillInternal(deps, approval, session);
    return { ...res, saved };
}
/** Jumlah bukti untuk laporan: bilangan bulat 0 sampai 999. */
const clampCount = (v) => {
    const n = Math.floor(Number(v));
    return Number.isFinite(n) ? Math.max(0, Math.min(999, n)) : 0;
};
/**
 * Lepas klaim persetujuan untuk percobaan yang tidak mengirim apa pun (audit U2B-02 dan U2B-03). Catatan pelepasan
 * ditulis lebih dulu di penyimpanan lokal (menggantikan catatan "mungkin terkirim" bila ada), jadi laporan yang gagal
 * karena jaringan dicoba lagi otomatis dan persetujuan tidak terkunci selamanya.
 * `released`: laporan sampai dan klaim lepas. `terminal`: server sudah punya catatan lain untuk persetujuan ini, tidak
 * perlu dicoba lagi. `pending`: laporan gagal dan catatan tetap tersimpan untuk dicoba lagi.
 */
async function releaseUnsentClaim(deps, base, kind, submitCheck) {
    await saveUnreported(deps.localArea, makeUnreported({ ...base, outcome: kind.outcome, reason: kind.reason })).catch(() => undefined);
    try {
        await deps.client.reportRun({
            approvalId: base.approvalId,
            jobId: base.jobId,
            pageUrl: base.pageUrl,
            outcome: kind.outcome,
            runId: base.runId,
            ...(kind.reason ? { reason: kind.reason } : {}),
            filledCount: base.filledCount,
            remainingRequired: 0,
            ...(submitCheck ? { submitCheck } : {}),
        });
    }
    catch (err) {
        if (describeError(err).terminal) {
            await removeUnreported(deps.localArea, base.approvalId).catch(() => undefined);
            return "terminal";
        }
        await markAttempt(deps.localArea, base.approvalId, deps.now()).catch(() => undefined);
        return "pending";
    }
    await removeUnreported(deps.localArea, base.approvalId).catch(() => undefined);
    return "released";
}
async function runAuthorizedSubmit(deps) {
    // Sesi untuk tab aktif: sesi manual miliknya, atau sesi antrean latar tab itu. Gerbang di bawah (tab, origin, frame,
    // otorisasi server) sama untuk keduanya, dan pengiriman tetap hanya lewat klik pengguna di panel.
    const activeTab = await deps.getActiveTab().catch(() => null);
    const found = await loadFillSessionForTab(deps.sessionArea, activeTab?.id);
    if (!found)
        return fail("Sesi pengisian tidak ditemukan. Jalankan pengisian formulir dulu sebelum mengirim.", "no_session");
    const session = found.session;
    // Sesi antrean milik tab yang sama ikut dihapus: sesi hasil isi ulang manual menimpa kunci lain, dan sesi antrean yang
    // tertinggal dipulihkan panel sebagai sesi hantu dengan tombol Kirim Sekarang di tab yang sudah dikirim (audit U2B-03).
    const clearSession = async () => {
        await clearFillSession(deps.sessionArea, found.key);
        await clearQueueFillSession(deps.sessionArea, session.tabId).catch(() => undefined);
    };
    if (await hasUnreportedFor(deps.localArea, session.approvalId)) {
        await clearSession();
        return fail(UNREPORTED_WARNING, "unreported_result", { terminal: true });
    }
    // Pelepasan klaim yang tertunda (percobaan sebelumnya tidak mengirim apa pun, tetapi laporannya gagal): coba lagi
    // sekarang. Selama klaim masih tersangkut, otorisasi baru pasti ditolak 409, jadi sesi dibiarkan dan pengguna diberi tahu.
    if (await hasPendingRelease(deps.localArea, session.approvalId)) {
        await retryUnreported(deps.localArea, deps.client, deps.now(), { force: true }).catch(() => undefined);
        if (await hasPendingRelease(deps.localArea, session.approvalId)) {
            return fail(RELEASE_PENDING_WARNING, "release_pending");
        }
    }
    const tab = activeTab ?? (await deps.getActiveTab());
    const target = checkSubmitTarget(session, tab);
    if (!target.ok)
        return fail(target.error, target.code);
    const tabId = tab.id;
    // Frame yang tadi diisi harus masih ada dengan origin yang sama. Tidak ada pemilihan ulang frame:
    // frame hilang atau berpindah situs berarti formulir yang diperiksa pengguna sudah tidak ada.
    const frameUrl = await deps.getFrameUrl(tabId, session.frameId).catch(() => null);
    const frameCheck = checkSubmitFrame(session, frameUrl);
    if (!frameCheck.ok) {
        await clearSession();
        return fail(frameCheck.error, frameCheck.code);
    }
    // URL frame (bukan URL tab) yang diotorisasi dan dilaporkan: pada embed lintas origin, halaman lamaran
    // sebenarnya ada di frame, sedangkan tab menampilkan situs perusahaan.
    const authorizedUrl = frameUrl;
    const frameId = session.frameId;
    await deps.ensureContentScript(tabId);
    const missingCheck = await deps.sendToTab(tabId, { type: "CHECK_MISSING_REQUIRED" }, frameId);
    const missingCount = Number(missingCheck?.missing?.count ?? 0);
    // runId dari backend mengikat klaim persetujuan ke percobaan ini. Laporan sesudah otorisasi wajib membawanya:
    // tanpa runId, laporan "incomplete" tidak melepas klaim dan persetujuan terkunci.
    let serverRunId;
    try {
        const auth = await deps.client.authorizeSubmit({
            approvalId: session.approvalId,
            jobId: session.jobId,
            pageUrl: authorizedUrl,
            missingRequiredCount: missingCount,
        });
        serverRunId = auth.runId;
    }
    catch (err) {
        const mapped = describeError(err);
        // Persetujuan sudah dipakai, dikunci di tempat lain, atau ditutup dan diganti di Applify: sesi ini tidak boleh dipakai lagi.
        // `approvalId` ikut supaya panel menghapus persetujuan yang benar dari daftar lokalnya.
        if (mapped.terminal)
            await clearSession();
        return fail(mapped.message, mapped.code, { status: mapped.status, terminal: mapped.terminal, approvalId: session.approvalId });
    }
    // Klaim sudah diambil di atas: tangkapan layar yang melempar galat tidak boleh meninggalkannya tersangkut.
    const filledShot = session.filledScreenshot ?? (await deps.captureEvidence(tabId, session.applyUrl).catch(() => null));
    let clicked = null;
    let clickErrored = false;
    try {
        clicked = await deps.sendToTab(tabId, { type: "CLICK_AUTHORIZED_SUBMIT", submitControlId: session.submitControlId }, frameId);
    }
    catch {
        // Pesan terputus: klik mungkin sudah terjadi (halaman berpindah). Anggap terkirim tanpa verifikasi.
        clickErrored = true;
    }
    const base = {
        approvalId: session.approvalId,
        jobId: session.jobId,
        runId: serverRunId,
        pageUrl: authorizedUrl,
        filledCount: session.filledCount,
        now: deps.now(),
    };
    if (!clickErrored && !clicked?.ok) {
        // Tidak ada yang diklik. Klaim yang sudah diambil harus lepas: laporan yang gagal (jaringan putus) disimpan dan
        // dicoba lagi, bukan ditelan. Dulu `.catch(() => undefined)` membiarkan klaim tersangkut sampai kedaluwarsa (audit U2B-03).
        const released = await releaseUnsentClaim(deps, base, { outcome: "incomplete", reason: "submit_control_not_found" });
        return fail("Tombol kirim tidak ditemukan di tab aktif. Klik kirim secara manual jika perlu." +
            (released === "pending" ? " Pelepasan persetujuan belum terkirim ke Applify, ekstensi mencoba lagi otomatis." : ""), "submit_control_not_found");
    }
    // Titik tanpa kembali: catatan "mungkin terkirim" ditulis lebih dulu, jadi service worker yang mati atau laporan
    // yang gagal tidak membuka jalan untuk menekan "Kirim" kedua pada persetujuan yang sama (`hasUnreportedFor`
    // memblokirnya). Sesi baru dihapus sesudah hasilnya dibaca (audit U2B-02): formulir yang menolak kiriman karena
    // galat validasi harus bisa diperbaiki dan dikirim ulang dari sesi yang sama.
    await saveUnreported(deps.localArea, makeUnreported({ ...base, outcome: "submit_unverified" })).catch(() => undefined);
    await deps.sleep(SUBMIT_SETTLE_MS);
    const detect = await deps
        .sendToTab(tabId, { type: "DETECT_SUBMIT_OUTCOME", submitControlId: session.submitControlId }, frameId)
        .catch(() => ({ ok: true, outcome: "submit_unverified" }));
    // Tidak terkirim: formulir menolak (galat validasi baru) atau meminta kode keamanan. Klaim dilepas dengan hasil
    // `validation_error` / `not_submitted`, bukan dikunci sebagai "mungkin terkirim".
    if (detect?.outcome === "validation_error" || detect?.outcome === "needs_code") {
        const validation = detect.outcome === "validation_error";
        const released = await releaseUnsentClaim(deps, base, validation ? { outcome: "validation_error" } : { outcome: "not_submitted", reason: "needs_code" }, validation ? { validationMessages: clampCount(detect.evidence?.validationMessages), controlPresent: true } : undefined);
        // Galat validasi: sesi dipertahankan agar pengguna memperbaiki isian lalu menekan Kirim Sekarang lagi. Halaman
        // kode: sesi lama tidak relevan lagi; pengguna mengisi kode lalu mengirim langsung di halaman.
        if (!validation)
            await clearSession();
        return {
            ok: true,
            reported: released !== "pending",
            outcome: validation ? "validation_error" : "needs_code",
            applicationStatus: null,
            ...(released === "pending" ? { warning: RELEASE_PENDING_WARNING } : {}),
        };
    }
    await clearSession();
    const outcome = detect?.outcome === "submitted" ? "submitted" : "submit_unverified";
    if (outcome === "submitted") {
        await saveUnreported(deps.localArea, makeUnreported({ ...base, outcome })).catch(() => undefined);
    }
    const afterShot = await deps.captureEvidence(tabId, session.applyUrl).catch(() => null);
    const payload = {
        approvalId: session.approvalId,
        jobId: session.jobId,
        // URL yang sudah diotorisasi, bukan URL halaman konfirmasi yang bisa berbeda origin.
        pageUrl: authorizedUrl,
        outcome,
        runId: serverRunId,
        filledCount: session.filledCount,
        remainingRequired: 0,
        // Ringkasan pengisian ikut laporan akhir supaya catatan di Applify tidak kehilangan berkas dan kolom yang terisi.
        ...(session.filesAttached ? { filesAttached: session.filesAttached } : {}),
        ...(session.filledFields ? { filledFields: session.filledFields } : {}),
    };
    let lastError = null;
    for (const withShots of [true, false]) {
        try {
            const reported = await deps.client.reportRun(withShots ? { ...payload, filledScreenshot: filledShot, afterScreenshot: afterShot } : payload);
            await removeUnreported(deps.localArea, session.approvalId);
            return {
                ok: true,
                reported: true,
                outcome: reported.logStatus,
                applicationStatus: reported.applicationStatus,
            };
        }
        catch (err) {
            lastError = err;
            const mapped = describeError(err);
            if (mapped.terminal) {
                // Server sudah punya catatan pengiriman untuk persetujuan ini.
                await removeUnreported(deps.localArea, session.approvalId);
                return { ok: true, reported: true, outcome: outcome === "submitted" ? "success" : "submit_unverified", applicationStatus: null };
            }
            const tooBig = mapped.status === 413 || /screenshot/i.test(mapped.code ?? "");
            if (!(withShots && tooBig && (filledShot || afterShot)))
                break;
        }
    }
    await markAttempt(deps.localArea, session.approvalId, deps.now()).catch(() => undefined);
    const mapped = describeError(lastError);
    return {
        ok: true,
        reported: false,
        outcome,
        warning: UNREPORTED_WARNING,
        reportError: mapped.message,
        code: mapped.code,
    };
}

/**
 * Serah-terima antrean ke pengguna: pengisian latar berhenti karena masih ada kolom wajib yang kosong atau pertanyaan
 * wajib yang hanya bisa dijawab pengguna (jawaban manual, berkas, kolom rahasia, kolom yang tidak dikenal).
 *
 * `chrome.sidePanel.open` hanya boleh dipanggil dari gestur pengguna, jadi service worker tidak bisa membuka panel
 * sendiri dari alarm antrean. Gantinya: tab lowongan dibawa ke depan, ikon ekstensi diberi lencana "Jawab" dengan
 * tooltip "Applify butuh jawabanmu", dan klik ikon (gestur) membuka panel yang langsung memulihkan pertanyaannya dari
 * sesi antrean tab itu (`action.onClicked` di service worker).
 *
 * Catatan "tab ini menunggu jawaban" disimpan di `chrome.storage.session` (id tab hanya berlaku selama peramban
 * hidup) supaya lencana bertahan melewati tugas berikutnya dan service worker yang dimatikan. Isinya hanya id tab,
 * id persetujuan, dan jumlah pertanyaan (tanpa label, jawaban, atau URL), dibatasi jumlahnya, dan kedaluwarsa sendiri.
 */
const NEEDS_INPUT_KEY = "applify_ext_needs_input";
const MAX_NEEDS_INPUT = 10;
const NEEDS_INPUT_TTL_MS = 6 * 60 * 60 * 1000;
const NEEDS_INPUT_BADGE_TEXT = "Jawab";
const NEEDS_INPUT_BADGE_TITLE = "Applify butuh jawabanmu. Klik ikon ini untuk membuka panel dan melanjutkan di tab lowongan.";
/**
 * Apakah pengisian ini berhenti menunggu pengguna: ada kolom wajib yang masih kosong di halaman, atau ada pertanyaan
 * wajib yang belum terjawab. Pertanyaan opsional saja tidak menahan pengiriman, jadi bukan "macet".
 * `questions` adalah jumlah pertanyaan yang tampil di panel (wajib dan opsional).
 */
function fillNeedsInput(res) {
    const list = Array.isArray(res?.questions) ? res.questions : [];
    const requiredOpen = list.some((q) => q?.required === true);
    const missingRequired = Math.max(0, Math.floor(Number(res?.summary?.missingRequiredCount ?? 0)) || 0);
    return { stuck: missingRequired > 0 || requiredOpen, questions: list.length, missingRequired };
}
const isEntry = (item) => {
    const e = item;
    return (Number.isInteger(e?.tabId) &&
        typeof e?.approvalId === "string" &&
        e.approvalId !== "" &&
        typeof e?.atMs === "number" &&
        Number.isFinite(e.atMs) &&
        typeof e?.questions === "number" &&
        Number.isFinite(e.questions));
};
/** Bersihkan isi storage: buang entri rusak dan kedaluwarsa, satu entri per tab (terbaru menang), terbaru dulu, dibatasi. */
function normalizeNeedsInput(raw, nowMs) {
    if (!Array.isArray(raw))
        return [];
    const byTab = new Map();
    for (const item of raw) {
        if (!isEntry(item) || nowMs - item.atMs > NEEDS_INPUT_TTL_MS)
            continue;
        const entry = {
            tabId: item.tabId,
            approvalId: item.approvalId.slice(0, 64),
            questions: Math.max(0, Math.min(999, Math.floor(item.questions))),
            atMs: item.atMs,
        };
        const current = byTab.get(entry.tabId);
        if (!current || entry.atMs > current.atMs)
            byTab.set(entry.tabId, entry);
    }
    return [...byTab.values()].sort((a, b) => b.atMs - a.atMs).slice(0, MAX_NEEDS_INPUT);
}
async function loadNeedsInput(area, nowMs) {
    const data = await area.get(NEEDS_INPUT_KEY);
    return normalizeNeedsInput(data?.[NEEDS_INPUT_KEY], nowMs);
}
async function save(area, entries) {
    if (entries.length === 0)
        await area.remove(NEEDS_INPUT_KEY);
    else
        await area.set({ [NEEDS_INPUT_KEY]: entries });
}
/** Catat (atau perbarui) tab yang menunggu jawaban pengguna. */
async function recordNeedsInput(area, entry, nowMs) {
    const current = await loadNeedsInput(area, nowMs);
    await save(area, normalizeNeedsInput([entry, ...current.filter((e) => e.tabId !== entry.tabId)], nowMs));
}
/** Hapus catatan satu tab (panel sudah menampilkan pertanyaannya, atau tab ditutup). `true` bila ada yang dihapus. */
async function clearNeedsInputForTab(area, tabId, nowMs) {
    if (typeof tabId !== "number")
        return false;
    const current = await loadNeedsInput(area, nowMs);
    const remaining = current.filter((e) => e.tabId !== tabId);
    if (remaining.length === current.length)
        return false;
    await save(area, remaining);
    return true;
}
async function clearNeedsInput(area) {
    await area.remove(NEEDS_INPUT_KEY);
}

/** Kode hasil pengisian yang melempar galat tak terduga (lihat `fillGuarded`). */
const FILL_EXCEPTION_CODE = "fill_exception";
/** Alarm satu kali: poll ulang sebentar setelah izin diberikan, saat tugasnya belum jatuh tempo di server. */
const PERMISSION_RECHECK_ALARM = "applify_permission_recheck";
/** Tugas yang terblokir izin dilepas dengan jeda pendek supaya cepat diambil lagi sesudah izin diberikan. */
const PERMISSION_RELEASE_DELAY_SECONDS = 30;
const PERMISSION_RECHECK_DELAY_MINUTES = 0.55;
/**
 * Tugas yang dihentikan pengguna lewat tombol Hentikan dilepas dengan jeda selama yang diizinkan backend (15 menit),
 * tanpa menghitung retry, supaya tidak langsung diisi ulang di depan mata pengguna. Mematikan saklar "Isi otomatis di
 * latar" menghentikan pengambilan tugas sama sekali.
 */
const USER_STOP_RELEASE_DELAY_SECONDS = 900;
class ExtensionQueueRunner {
    deps;
    busy = false;
    /** Catatan izin dibaca-ubah-tulis berurutan: panel, event izin, dan poll bisa menyentuhnya bersamaan. */
    permissionLock = Promise.resolve();
    /** Tugas yang tombol Hentikannya ditekan. Pengisian memeriksanya di antara dua aksi. */
    stopRequested = new Set();
    /**
     * Event tab `complete` untuk tugas yang menunggu login, yang datang saat poll atau pemulihan sedang berjalan.
     * Event itu tidak boleh dibuang (tidak ada event `complete` lagi), jadi diulang sesudah poll selesai.
     */
    deferredTabEvent = null;
    constructor(deps) {
        this.deps = deps;
    }
    async ensurePollAlarm() {
        await this.deps.setAlarm(QUEUE_POLL_ALARM, {
            delayInMinutes: POLL_PERIOD_MINUTES,
            periodInMinutes: POLL_PERIOD_MINUTES,
        });
    }
    async stopAllAlarmsAndState() {
        const active = await loadActiveQueueRun(this.deps.localArea);
        await Promise.all([
            this.deps.clearAlarm(QUEUE_POLL_ALARM),
            this.deps.clearAlarm(QUEUE_HEARTBEAT_ALARM),
            this.deps.clearAlarm(AWAITING_LOGIN_ALARM),
            this.deps.clearAlarm(PERMISSION_RECHECK_ALARM),
            clearActiveQueueRun(this.deps.localArea),
            this.withPermissionLock(() => clearPermissionNeeded(this.deps.localArea)).catch(() => undefined),
            clearNeedsInput(this.deps.sessionArea).catch(() => undefined),
            clearAllQueueNotices(this.deps.sessionArea).catch(() => undefined),
        ]);
        this.deps.queueNoticeChanged?.();
        await this.setBadge("");
        this.deps.permissionNeededChanged?.();
        // Putus: antrean menyerah pada tugas yang berjalan, jadi tab yang dibukanya ikut ditutup.
        if (active)
            await this.dropQueueTab(active.tabId, "close");
    }
    /** Dipanggil saat service worker startup: memulihkan atau melepas tugas yang terputus tanpa pernah auto-submit. */
    async recoverOnStartup() {
        // H-02: pemulihan tidak boleh jalan bersamaan dengan poll yang sedang mengklaim atau mengisi tugas.
        if (this.busy)
            return { action: "busy" };
        this.busy = true;
        try {
            const active = await loadActiveQueueRun(this.deps.localArea);
            if (!active) {
                await this.setBadge("");
                return { action: "none" };
            }
            if (active.phase === "awaiting_login") {
                return await this.checkAwaitingLoginHealth(active);
            }
            // `opening` / `filling` di instance SW sebelumnya mati di tengah jalan -> lepas dan tutup tab-nya. Dua pemulihan
            // pertama tanpa kemajuan tidak menghitung retry; sesudahnya dihitung supaya formulir yang macet akhirnya gagal.
            await this.releaseAbandoned(active, { delaySeconds: 5, error: "service_worker_restarted" });
            return { action: "released_interrupted", queueJobId: active.queueJobId };
        }
        finally {
            this.busy = false;
            this.replayDeferredTabEvent();
        }
    }
    async handleAlarm(alarmName) {
        if (alarmName === QUEUE_POLL_ALARM) {
            // Laporan hasil yang tertunda dicoba lagi di tiap siklus poll, berjalan bersamaan dengan poll dan ditunggu
            // keduanya supaya service worker tidak tidur di tengah jalan.
            const retry = Promise.resolve()
                .then(() => this.deps.retryUnreported?.())
                .catch(() => undefined);
            const polled = await this.pollOnce();
            await retry;
            return polled;
        }
        if (alarmName === QUEUE_HEARTBEAT_ALARM) {
            return this.sendHeartbeat();
        }
        if (alarmName === AWAITING_LOGIN_ALARM) {
            return this.checkAwaitingLoginAlarm();
        }
        if (alarmName === PERMISSION_RECHECK_ALARM) {
            return this.pollOnce();
        }
        return { action: "ignored" };
    }
    async pollOnce() {
        if (this.busy)
            return { action: "busy" };
        this.busy = true;
        try {
            // Sambungan kedaluwarsa (401) atau masih dalam jeda: jangan menyentuh jaringan sampai pengguna menghubungkan ulang.
            if (shouldSkipPollForHealth(await loadRunnerHealth(this.deps.sessionArea), this.deps.now())) {
                return { action: "auth_backoff" };
            }
            // Catatan "butuh izin" yang sudah terpenuhi atau kedaluwarsa dibersihkan lebih dulu, termasuk izin yang
            // diberikan lewat chrome://extensions. Gagal membaca catatan tidak boleh menghentikan antrean.
            await this.syncPermissionNeeded().catch(() => undefined);
            const existing = await loadActiveQueueRun(this.deps.localArea);
            if (existing) {
                if (existing.phase === "awaiting_login") {
                    return this.checkAwaitingLoginHealth(existing);
                }
                // Tidak ada proses yang berjalan di memory instance ini tetapi state masih opening/filling -> pulihkan.
                await this.releaseAbandoned(existing, { delaySeconds: 5, error: "stale_local_queue_run" });
                return { action: "recovered_stale", queueJobId: existing.queueJobId };
            }
            if (this.deps.isBackgroundFillEnabled) {
                const enabled = await this.deps.isBackgroundFillEnabled().catch(() => true);
                if (!enabled)
                    return { action: "disabled" };
            }
            // Galat klaim dicatat (bukan dilempar ke alarm yang diam-diam menelannya). 401 menghentikan poll berikutnya.
            let job;
            try {
                job = await this.deps.client.claimNextJob("chrome-extension");
            }
            catch (err) {
                await updateRunnerHealth(this.deps.sessionArea, (h) => recordRunnerError(h, err, this.deps.now()));
                return { action: "claim_error", reason: err?.code ?? "claim_failed" };
            }
            await updateRunnerHealth(this.deps.sessionArea, (h) => recordRunnerSuccess(h, this.deps.now()));
            if (!job)
                return { action: "idle" };
            return await this.runClaimedJob(job);
        }
        finally {
            this.busy = false;
            this.replayDeferredTabEvent();
        }
    }
    async sendHeartbeat() {
        const active = await loadActiveQueueRun(this.deps.localArea);
        if (!active) {
            await this.deps.clearAlarm(QUEUE_HEARTBEAT_ALARM);
            return { action: "no_active_run" };
        }
        if (active.phase === "awaiting_login" && this.deps.now() >= (active.awaitingLoginUntilMs ?? 0)) {
            await this.expireAwaitingLogin(active);
            return { action: "expired_login", queueJobId: active.queueJobId };
        }
        // Sambungan kedaluwarsa: tidak ada heartbeat sampai pengguna menghubungkan ulang. Lease di server habis sendiri.
        if (shouldSkipPollForHealth(await loadRunnerHealth(this.deps.sessionArea), this.deps.now())) {
            return { action: "auth_backoff", queueJobId: active.queueJobId };
        }
        try {
            await this.deps.client.heartbeatJob(active.queueJobId, active.leaseId);
            await updateRunnerHealth(this.deps.sessionArea, (h) => recordRunnerSuccess(h, this.deps.now(), { heartbeat: true }));
            return { action: "heartbeat_sent", queueJobId: active.queueJobId };
        }
        catch (err) {
            if (isLeaseLostError(err)) {
                await this.abandonLostLease(active);
                return { action: "lease_lost", queueJobId: active.queueJobId };
            }
            const code = err?.code;
            if (code === "job_not_found" || code === "job_not_processing") {
                await this.endRun(active, "close");
                return { action: "cleaned_stale_job", queueJobId: active.queueJobId };
            }
            // Galat heartbeat dicatat supaya panel bisa menampilkannya. 401 menghentikan poll dan heartbeat berikutnya.
            await updateRunnerHealth(this.deps.sessionArea, (h) => recordRunnerError(h, err, this.deps.now()));
            return { action: "heartbeat_error", queueJobId: active.queueJobId, reason: code ?? "heartbeat_failed" };
        }
    }
    async checkAwaitingLoginAlarm() {
        if (this.busy)
            return { action: "busy" };
        const active = await loadActiveQueueRun(this.deps.localArea);
        if (!active || active.phase !== "awaiting_login")
            return { action: "none" };
        return this.checkAwaitingLoginHealth(active);
    }
    async onTabUpdated(tabId, changeInfo, tab) {
        const active = await loadActiveQueueRun(this.deps.localArea);
        if (!active || active.tabId !== tabId || active.phase !== "awaiting_login") {
            return { action: "ignored" };
        }
        if (this.deps.now() >= (active.awaitingLoginUntilMs ?? 0)) {
            await this.expireAwaitingLogin(active);
            return { action: "login_timeout", queueJobId: active.queueJobId };
        }
        const candidateUrl = tab?.url ?? changeInfo?.url;
        if (isLoginRedirectOrRedacted(candidateUrl)) {
            const cleanLogin = stripUrlQueryAndHash(candidateUrl);
            const next = {
                ...active,
                sawNavigationInLogin: true,
                ...(cleanLogin ? { lastLoginUrl: cleanLogin } : {}),
                updatedAtMs: this.deps.now(),
            };
            await saveActiveQueueRun(this.deps.localArea, next);
            return { action: "still_logging_in", queueJobId: active.queueJobId };
        }
        if (changeInfo.status !== "complete") {
            const next = {
                ...active,
                sawNavigationInLogin: true,
                updatedAtMs: this.deps.now(),
            };
            await saveActiveQueueRun(this.deps.localArea, next);
            return { action: "navigating", queueJobId: active.queueJobId };
        }
        const cleanNow = stripUrlQueryAndHash(candidateUrl);
        const urlChanged = Boolean(cleanNow && cleanNow !== active.lastLoginUrl);
        if (!active.sawNavigationInLogin && !urlChanged && this.deps.now() - active.updatedAtMs < 2_000) {
            // H-02: event `complete` di dalam jendela debounce tidak dibuang. Diulang setelah jendela itu lewat.
            // Event kedua yang datang sesudahnya tidak mengulang pengisian: fase sudah berpindah dari awaiting_login.
            const waitMs = 2_000 - (this.deps.now() - active.updatedAtMs);
            this.scheduleDeferredTabEvent(waitMs, tabId, changeInfo, tab);
            return { action: "debounced", queueJobId: active.queueJobId };
        }
        if (this.busy) {
            // H-02: `complete` yang datang saat poll berjalan diulang sesudah poll selesai, bukan dibuang.
            this.deferredTabEvent = { tabId, changeInfo, tab };
            return { action: "busy", queueJobId: active.queueJobId };
        }
        this.busy = true;
        try {
            const freshTab = (await this.deps.getTab(tabId)) ?? tab;
            if (!freshTab?.id || isLoginRedirectOrRedacted(freshTab.url)) {
                return { action: "still_logging_in", queueJobId: active.queueJobId };
            }
            const deadlineMs = active.awaitingLoginUntilMs ?? this.deps.now() + AWAITING_LOGIN_TIMEOUT_MS;
            const fillingRun = {
                ...active,
                phase: "filling",
                updatedAtMs: this.deps.now(),
            };
            await saveActiveQueueRun(this.deps.localArea, fillingRun);
            // Dilanjutkan: lencana "Login" dihapus. Dipasang lagi bila portal ternyata masih meminta login.
            await this.setBadge("");
            const res = await this.fillGuarded(active.approval, freshTab, {
                queueJobId: active.queueJobId,
                awaitingUntilIso: new Date(deadlineMs).toISOString(),
                reportAwaitingLogin: !active.loginReported,
                ...(active.leaseId ? { leaseId: active.leaseId } : {}),
                ...this.visibleFillOpts(active),
            });
            if (res.awaitingLogin) {
                await saveActiveQueueRun(this.deps.localArea, {
                    ...active,
                    phase: "awaiting_login",
                    awaitingLoginUntilMs: deadlineMs,
                    lastLoginUrl: stripUrlQueryAndHash(res.loginUrl ?? freshTab.url) ?? active.lastLoginUrl ?? null,
                    sawNavigationInLogin: false,
                    loginReported: true,
                    updatedAtMs: this.deps.now(),
                });
                await this.setBadge(LOGIN_BADGE_TEXT);
                return { action: "still_auth_required", queueJobId: active.queueJobId };
            }
            const done = await this.finalizeAfterFill(active, res);
            if (done === "lease_lost")
                return { action: "lease_lost", queueJobId: active.queueJobId };
            const resumedAction = res.code === FILL_EXCEPTION_CODE ? "fill_exception" : res.formNotFound ? "form_not_found" : res.ok ? "resumed_filled" : "resumed_finished";
            return { action: resumedAction, queueJobId: active.queueJobId };
        }
        finally {
            this.busy = false;
            this.replayDeferredTabEvent();
        }
    }
    /** Ulangi event tab yang tertunda (lihat `deferredTabEvent`). Dipanggil sesudah poll, pemulihan, atau debounce selesai. */
    replayDeferredTabEvent() {
        const deferred = this.deferredTabEvent;
        if (!deferred)
            return;
        this.deferredTabEvent = null;
        void this.onTabUpdated(deferred.tabId, deferred.changeInfo, deferred.tab).catch(() => undefined);
    }
    scheduleDeferredTabEvent(waitMs, tabId, changeInfo, tab) {
        setTimeout(() => {
            void this.onTabUpdated(tabId, changeInfo, tab).catch(() => undefined);
        }, Math.max(0, waitMs));
    }
    async onTabRemoved(tabId) {
        // Tab apa pun yang ditutup: sesi antrean dan catatan tab-nya tidak berguna lagi.
        await clearQueueFillSession(this.deps.sessionArea, tabId).catch(() => undefined);
        await untrackQueueTab(this.deps.sessionArea, tabId).catch(() => undefined);
        // Tab yang menunggu jawaban ditutup pengguna: tidak ada lagi yang perlu dijawab di sana, lencana "Jawab" dicabut.
        await this.dropNeedsInput(tabId);
        const active = await loadActiveQueueRun(this.deps.localArea);
        if (!active || active.tabId !== tabId)
            return { action: "ignored" };
        await this.releaseAbandoned(active, {
            delaySeconds: 30,
            error: "Tab lowongan ditutup sebelum pengisian selesai.",
        });
        return { action: "tab_removed_released", queueJobId: active.queueJobId };
    }
    /**
     * Tombol Hentikan di overlay ditekan (pesan `AGENT_STOP` dari tab `tabId`). Pengisian yang berjalan berhenti di
     * antara dua aksi (`shouldAbort`) lalu tugas dilepas; bila tidak ada pengisian yang berjalan di instance ini
     * (menunggu login, atau service worker sempat mati) tugas dilepas langsung. Tidak pernah mengirim apa pun.
     */
    async requestStop(tabId) {
        const active = await loadActiveQueueRun(this.deps.localArea);
        if (!active || active.tabId !== tabId)
            return { ok: false, action: "ignored" };
        this.stopRequested.add(active.queueJobId);
        if (this.busy)
            return { ok: true, action: "stop_requested", queueJobId: active.queueJobId };
        await this.releaseUserStopped(active, true);
        return { ok: true, action: "stopped", queueJobId: active.queueJobId };
    }
    /** Lepas tugas yang dihentikan pengguna dan biarkan tab terbuka (mode tampil) dengan lencana "Dihentikan". */
    async releaseUserStopped(run, showOverlay) {
        await resetRecoveryCount(this.deps.localArea, run.queueJobId);
        await this.safeRelease(run.queueJobId, {
            countRetry: false,
            delaySeconds: USER_STOP_RELEASE_DELAY_SECONDS,
            error: USER_STOPPED_CODE,
            ...(run.leaseId ? { leaseId: run.leaseId } : {}),
        });
        if (showOverlay && run.visible)
            await this.showOverlay(run.tabId, stoppedOverlay());
        await this.endRun(run, run.visible ? "keep" : "close");
        await this.noteNotice("stopped", {
            id: run.queueJobId,
            approvalId: run.approvalId,
            url: run.applyUrl,
            ...(run.visible ? { tabId: run.tabId } : {}),
        });
    }
    async showOverlay(tabId, message) {
        if (typeof tabId !== "number")
            return;
        try {
            await this.deps.showOverlay?.(tabId, message);
        }
        catch {
            // Overlay hanya petunjuk visual.
        }
    }
    async isVisibleRun() {
        if (!this.deps.isVisibleRunEnabled)
            return false;
        return this.deps.isVisibleRunEnabled().catch(() => true);
    }
    visibleFillOpts(run) {
        if (run.visible !== true)
            return {};
        return { visible: true, shouldAbort: () => this.stopRequested.has(run.queueJobId) };
    }
    async runClaimedJob(job) {
        const leaseId = typeof job.lease_id === "string" && job.lease_id ? job.lease_id : undefined;
        const leaseFields = leaseId ? { leaseId } : {};
        // Tugas ini diambil lagi: pemberitahuan lama untuknya sudah tidak berlaku.
        await this.dropNotice(job.queueJobId);
        if (!job.applyUrl) {
            await this.safeRelease(job.queueJobId, { terminal: true, error: "missing_apply_url", ...leaseFields });
            await this.noteNotice("no_apply_url", { id: job.queueJobId, approvalId: job.approvalId });
            return { action: "released_invalid", queueJobId: job.queueJobId, reason: "missing_apply_url" };
        }
        if (isLinkedInUrl(job.applyUrl)) {
            await this.safeRelease(job.queueJobId, { terminal: true, error: "linkedin_manual_only", ...leaseFields });
            await this.noteNotice("linkedin_manual", { id: job.queueJobId, approvalId: job.approvalId, url: job.applyUrl });
            return { action: "released_invalid", queueJobId: job.queueJobId, reason: "linkedin_manual_only" };
        }
        const permitted = await this.deps.hasOriginPermission(job.applyUrl);
        if (!permitted && !permissionHostForUrl(job.applyUrl)) {
            // Host di luar daftar ATS dan portal login (atau bukan HTTPS) tidak pernah bisa diizinkan lewat tombol Izinkan,
            // jadi tidak ada kartu izin dan klaim-lepas-klaim tanpa akhir tidak menghasilkan apa pun. Dilepas permanen dengan
            // kode jelas (`unsupported_host`); pengguna masih bisa mengisinya manual lewat klik ikon ekstensi (activeTab).
            await this.safeRelease(job.queueJobId, {
                terminal: true,
                error: unsupportedHostReleaseError(job.applyUrl),
                ...leaseFields,
            });
            // Panel menjelaskannya dan menunjuk ke Applify. Sebelumnya hanya `error_message` backend yang tahu.
            await this.noteNotice("unsupported_host", { id: job.queueJobId, approvalId: job.approvalId, url: job.applyUrl });
            return { action: "released_invalid", queueJobId: job.queueJobId, reason: UNSUPPORTED_HOST_CODE };
        }
        if (!permitted) {
            // Semua host yang didukung ada di `host_permissions` manifest (izin saat pasang), jadi cabang ini hanya tercapai
            // bila pengguna sendiri mencabut akses situs lewat chrome://extensions: kartu Izinkan hanya pemulihan, bukan
            // bagian alur pasang. Tidak pernah ada permintaan izin dari antrean.
            // Catat host yang butuh izin supaya panel menampilkan tombol Izinkan dan ikon memakai lencana "!". Gagal
            // mencatat tidak boleh menahan pelepasan tugas. Kode alasan ikut di `error` supaya web app tahu penyebabnya.
            await this.notePermissionNeeded(job.applyUrl).catch(() => undefined);
            await this.safeRelease(job.queueJobId, {
                countRetry: false,
                delaySeconds: PERMISSION_RELEASE_DELAY_SECONDS,
                error: permissionReleaseError(job.applyUrl),
                ...leaseFields,
            });
            return { action: "permission_required", queueJobId: job.queueJobId };
        }
        const approval = claimedJobToApproval(job);
        this.stopRequested.delete(job.queueJobId);
        const visible = await this.isVisibleRun();
        const baseRun = {
            queueJobId: job.queueJobId,
            approvalId: job.approvalId,
            jobId: job.jobId,
            tabId: null,
            applyUrl: job.applyUrl,
            approval,
            phase: "opening",
            startedAtMs: this.deps.now(),
            updatedAtMs: this.deps.now(),
            ...leaseFields,
            ...(visible ? { visible: true } : {}),
        };
        await saveActiveQueueRun(this.deps.localArea, baseRun);
        await this.deps.setAlarm(QUEUE_HEARTBEAT_ALARM, {
            delayInMinutes: HEARTBEAT_PERIOD_MINUTES,
            periodInMinutes: HEARTBEAT_PERIOD_MINUTES,
        });
        const tab = await this.deps.createTab(job.applyUrl, visible).catch(() => null);
        if (!tab?.id) {
            await this.releaseAbandoned(baseRun, { delaySeconds: 30, error: visible ? "Gagal membuka tab." : "Gagal membuka tab latar belakang." });
            return { action: "tab_create_failed", queueJobId: job.queueJobId };
        }
        // Catat id tab SEGERA: hanya tab yang dibuka antrean yang boleh ditutup atau difokuskan olehnya.
        await trackQueueTab(this.deps.sessionArea, tab.id).catch(() => undefined);
        const runWithTab = { ...baseRun, tabId: tab.id, updatedAtMs: this.deps.now() };
        await saveActiveQueueRun(this.deps.localArea, runWithTab);
        const loaded = await this.deps.waitForTabReady(tab.id, 20_000);
        if (!loaded?.id) {
            // Batas waktu atau tab hilang: gagal, bukan berhasil. Lepas tugas dan tutup tab (bila masih ada).
            const stillOpen = await this.deps.getTab(tab.id).catch(() => null);
            await this.releaseAbandoned(runWithTab, {
                delaySeconds: 30,
                error: stillOpen
                    ? "Halaman lowongan tidak selesai dimuat dalam batas waktu."
                    : "Tab ditutup sebelum halaman selesai dimuat.",
            });
            return { action: stillOpen ? "tab_load_timeout" : "tab_closed", queueJobId: job.queueJobId };
        }
        if (this.stopRequested.has(job.queueJobId)) {
            // Hentikan ditekan selagi halaman dimuat: tidak ada yang diisi.
            await this.releaseUserStopped(runWithTab, true);
            return { action: "stopped_by_user", queueJobId: job.queueJobId };
        }
        const deadlineMs = this.deps.now() + AWAITING_LOGIN_TIMEOUT_MS;
        if (isLoginRedirectOrRedacted(loaded.url)) {
            const safeLoginUrl = stripUrlQueryAndHash(loaded.url) ?? stripUrlQueryAndHash(job.applyUrl) ?? job.applyUrl;
            const entered = await this.enterAwaitingLogin(runWithTab, deadlineMs, safeLoginUrl, true);
            return { action: entered ? "awaiting_login" : "lease_lost", queueJobId: job.queueJobId };
        }
        const fillingRun = { ...runWithTab, phase: "filling", updatedAtMs: this.deps.now() };
        await saveActiveQueueRun(this.deps.localArea, fillingRun);
        const res = await this.fillGuarded(approval, loaded, {
            queueJobId: job.queueJobId,
            awaitingUntilIso: new Date(deadlineMs).toISOString(),
            reportAwaitingLogin: true,
            ...leaseFields,
            ...this.visibleFillOpts(runWithTab),
        });
        if (res.awaitingLogin) {
            const safeLoginUrl = stripUrlQueryAndHash(res.loginUrl ?? loaded.url) ?? stripUrlQueryAndHash(job.applyUrl) ?? job.applyUrl;
            const entered = await this.enterAwaitingLogin(runWithTab, deadlineMs, safeLoginUrl, false // already reported by fillInternal
            );
            return { action: entered ? "awaiting_login" : "lease_lost", queueJobId: job.queueJobId };
        }
        const done = await this.finalizeAfterFill(fillingRun, res);
        if (done === "lease_lost")
            return { action: "lease_lost", queueJobId: job.queueJobId };
        const action = res.aborted
            ? "stopped_by_user"
            : res.code === FILL_EXCEPTION_CODE
                ? "fill_exception"
                : res.formNotFound
                    ? "form_not_found"
                    : res.blocked === "captcha_blocked"
                        ? "captcha_blocked"
                        : res.ok
                            ? "filled"
                            : "finished";
        const notFoundReason = res.foreignFrameHost ? "form_in_iframe" : "form_not_found";
        return { action, queueJobId: job.queueJobId, reason: res.formNotFound ? notFoundReason : (res.blocked ?? res.code) };
    }
    /**
     * `executeFillOnTab` dengan galat tak terduga ditangkap (audit U2B-05): `planForm` timeout atau 500, tab ditutup saat
     * `ensureContentScript`, dan sebagainya. Tanpa ini run tertinggal di fase "filling", heartbeat terus berdetak ke
     * backend, dan tab menggantung sampai poll berikutnya. Galat menjadi hasil gagal tanpa laporan, yang lewat jalur
     * `finalizeAfterFill` seperti pengisian lain yang tidak terlapor: tugas dilepas dengan retry dihitung, state dan alarm
     * dibersihkan. Sewa hilang (409 `lease_lost`) tetap berhenti tanpa melapor atau melepas.
     */
    async fillGuarded(approval, tab, opts) {
        try {
            return await this.deps.executeFillOnTab(approval, tab, opts);
        }
        catch (err) {
            if (isLeaseLostError(err))
                return { ok: false, reported: false, leaseLost: true, code: "lease_lost" };
            const code = typeof err?.code === "string" && /^[a-z0-9_]{1,40}$/.test(err.code) ? `${FILL_EXCEPTION_CODE}:${err.code}` : FILL_EXCEPTION_CODE;
            return { ok: false, reported: false, code: FILL_EXCEPTION_CODE, error: code };
        }
    }
    /** `false` bila sewa hilang saat melapor (tugas sudah dibersihkan, jangan dilanjutkan). */
    async enterAwaitingLogin(run, deadlineMs, safeLoginUrl, reportNow) {
        if (reportNow) {
            try {
                await this.deps.client.reportRun({
                    approvalId: run.approvalId,
                    jobId: run.jobId,
                    queueJobId: run.queueJobId,
                    ...(run.leaseId ? { lease_id: run.leaseId } : {}),
                    pageUrl: safeLoginUrl,
                    loginUrl: safeLoginUrl,
                    awaitingUntil: new Date(deadlineMs).toISOString(),
                    outcome: "awaiting_login",
                    reason: "awaiting_login",
                    filledCount: 0,
                    remainingRequired: 0,
                    nextSteps: [LOGIN_NEXT_STEP],
                });
            }
            catch (err) {
                if (isLeaseLostError(err)) {
                    await this.abandonLostLease(run);
                    return false;
                }
            }
        }
        // Sampai di halaman login adalah kemajuan nyata: hitungan pemulihan tugas ini mulai dari nol.
        await resetRecoveryCount(this.deps.localArea, run.queueJobId);
        await saveActiveQueueRun(this.deps.localArea, {
            ...run,
            phase: "awaiting_login",
            awaitingLoginUntilMs: deadlineMs,
            lastLoginUrl: safeLoginUrl,
            sawNavigationInLogin: false,
            loginReported: true,
            updatedAtMs: this.deps.now(),
        });
        await this.deps.setAlarm(AWAITING_LOGIN_ALARM, { when: deadlineMs });
        await this.surfaceAttentionTab(run, LOGIN_BADGE_TEXT);
        await this.noteNotice("awaiting_login", { id: run.queueJobId, approvalId: run.approvalId, url: safeLoginUrl, tabId: run.tabId });
        return true;
    }
    /** Beri tahu pengguna tanpa notifikasi sistem: tab antrean dibawa ke depan dan ikon diberi badge perhatian (Login / CAPTCHA). */
    async surfaceAttentionTab(run, badgeText) {
        await this.setBadge(badgeText);
        await this.surfaceTabOnce(run);
    }
    /**
     * Bawa tab antrean ke depan. Mode latar: setiap kali dipanggil. Mode tampil: tab sudah dibuka aktif, jadi hanya
     * satu kali per tugas dan hanya bila pengguna sudah berpindah ke tab lain; fokus pengguna tidak direbut berulang.
     */
    async surfaceTabOnce(run) {
        const tabId = run.tabId;
        if (typeof tabId !== "number" || !(await isQueueTab(this.deps.sessionArea, tabId)))
            return;
        if (run.visible) {
            if (run.surfaced)
                return;
            const tab = await this.deps.getTab(tabId).catch(() => null);
            if (!tab?.id || tab.active === true)
                return;
        }
        try {
            await this.deps.surfaceTab?.(tabId);
        }
        catch {
            // Tab atau jendela sudah hilang: badge tetap menjadi petunjuk.
        }
        if (run.visible)
            await this.markSurfaced(run.queueJobId);
    }
    /**
     * Serah-terima ke pengguna saat pengisian latar macet (kolom wajib kosong, pertanyaan wajib, berkas, kolom rahasia).
     * `sidePanel.open` butuh gestur pengguna, jadi panel tidak dibuka dari sini. Yang dilakukan: (1) tab lowongan dibawa
     * ke depan, (2) lencana "Jawab" dan tooltip "Applify butuh jawabanmu" dipasang di ikon dan bertahan sampai
     * panel menampilkan pertanyaannya atau tab ditutup, (3) mode latar menampilkan lencana di halaman yang menunjuk ke
     * ikon, dan panel yang sudah terbuka diminta memuat ulang. Klik ikon membuka panel (`action.onClicked`).
     */
    async handOffToUser(run, questions) {
        if (typeof run.tabId === "number") {
            await recordNeedsInput(this.deps.sessionArea, { tabId: run.tabId, approvalId: run.approvalId, questions, atMs: this.deps.now() }, this.deps.now()).catch(() => undefined);
            // Mode tampil sudah menampilkan lencana akhir ("Selesai mengisi sebagian"); mode latar belum menampilkan apa pun.
            if (!run.visible)
                await this.showOverlay(run.tabId, needsInputOverlay(questions));
        }
        // Fokus sebelum `endRun`: hanya tab yang masih tercatat milik antrean yang boleh difokuskan (lihat `surfaceTabOnce`).
        await this.surfaceTabOnce(run);
        await this.endRun(run, "keep", { clearBadge: false });
        await this.showIdleBadge();
        try {
            this.deps.needsInputChanged?.();
        }
        catch {
            // Panel yang tertutup tidak perlu diberi tahu.
        }
    }
    /** Tab yang menunggu jawaban (terbaru dulu). Entri kedaluwarsa dibuang. */
    async listNeedsInput() {
        return loadNeedsInput(this.deps.sessionArea, this.deps.now()).catch(() => []);
    }
    /**
     * Panel menampilkan pertanyaan tab ini (atau tab ditutup): catatan "butuh jawabanmu" untuk tab itu dicabut dan lencana
     * diperbarui. `true` bila ada catatan yang dihapus.
     */
    async acknowledgeNeedsInput(tabId) {
        return this.dropNeedsInput(tabId);
    }
    async dropNeedsInput(tabId) {
        const removed = await clearNeedsInputForTab(this.deps.sessionArea, tabId, this.deps.now()).catch(() => false);
        if (removed)
            await this.refreshIdleBadgeUnlessRunning();
        return removed;
    }
    async markSurfaced(queueJobId) {
        const stored = await loadActiveQueueRun(this.deps.localArea).catch(() => null);
        if (stored && stored.queueJobId === queueJobId) {
            await saveActiveQueueRun(this.deps.localArea, { ...stored, surfaced: true }).catch(() => undefined);
        }
    }
    async checkAwaitingLoginHealth(active) {
        const tab = active.tabId !== null ? await this.deps.getTab(active.tabId).catch(() => null) : null;
        if (!tab?.id) {
            await this.releaseAbandoned(active, { delaySeconds: 30, error: "Tab login sudah ditutup." });
            return { action: "tab_gone_released", queueJobId: active.queueJobId };
        }
        if (this.deps.now() >= (active.awaitingLoginUntilMs ?? 0)) {
            await this.expireAwaitingLogin(active);
            return { action: "login_timeout", queueJobId: active.queueJobId };
        }
        await this.deps.setAlarm(QUEUE_HEARTBEAT_ALARM, {
            delayInMinutes: HEARTBEAT_PERIOD_MINUTES,
            periodInMinutes: HEARTBEAT_PERIOD_MINUTES,
        });
        // Lencana tetap menyala walau service worker sempat tidur (tanpa mencuri fokus lagi).
        await this.setBadge(LOGIN_BADGE_TEXT);
        return { action: "awaiting_login", queueJobId: active.queueJobId };
    }
    async expireAwaitingLogin(active) {
        const safeUrl = stripUrlQueryAndHash(active.lastLoginUrl) ?? stripUrlQueryAndHash(active.applyUrl) ?? active.applyUrl;
        let reported = false;
        try {
            await this.deps.client.reportRun({
                approvalId: active.approvalId,
                jobId: active.jobId,
                queueJobId: active.queueJobId,
                ...(active.leaseId ? { lease_id: active.leaseId } : {}),
                pageUrl: safeUrl,
                outcome: "incomplete",
                reason: "login_timeout",
                filledCount: 0,
                remainingRequired: 0,
            });
            reported = true;
        }
        catch (err) {
            if (isLeaseLostError(err)) {
                await this.abandonLostLease(active);
                return;
            }
        }
        if (!reported) {
            await this.safeRelease(active.queueJobId, {
                terminal: true,
                error: "login_timeout",
                ...(active.leaseId ? { leaseId: active.leaseId } : {}),
            });
        }
        // Waktu habis: tugas ditinggalkan. Mode latar menutup halaman login yang dibuka antrean; mode tampil membiarkannya
        // terbuka dengan lencana, karena pengguna mungkin sedang berada di sana.
        if (active.visible) {
            await this.showOverlay(active.tabId, loginTimeoutOverlay());
            await this.endRun(active, "keep");
            await this.noteNotice("login_timeout", { id: active.queueJobId, approvalId: active.approvalId, url: safeUrl, tabId: active.tabId });
            return;
        }
        await this.endRun(active, "close");
        await this.noteNotice("login_timeout", { id: active.queueJobId, approvalId: active.approvalId, url: safeUrl });
    }
    /**
     * Sesudah pengisian. Hasil sudah terlapor: tab dibiarkan terbuka untuk diperiksa pengguna (jadi milik pengguna).
     * Belum terlapor: lepas tugas dengan retry dihitung dan tutup tab. Sewa hilang: berhenti tanpa melapor atau melepas.
     * Bila state sudah dibersihkan di tengah jalan (mis. heartbeat mendeteksi sewa hilang), tidak ada yang dilakukan lagi.
     */
    async finalizeAfterFill(run, res) {
        const current = await loadActiveQueueRun(this.deps.localArea);
        if (!current || current.queueJobId !== run.queueJobId)
            return "done";
        if (res.leaseLost) {
            await this.abandonLostLease(current);
            return "lease_lost";
        }
        if (res.aborted) {
            // Pengguna menekan Hentikan: tugas dilepas tanpa laporan, tab dibiarkan dengan lencana "Dihentikan".
            await this.releaseUserStopped(current, true);
            return "done";
        }
        if (res.blocked === "captcha_blocked" && res.reported) {
            await resetRecoveryCount(this.deps.localArea, current.queueJobId);
            // Fokuskan tab agar pengguna bisa menyelesaikan Turnstile/CAPTCHA secara manual, lalu lepas antrean dengan badge tetap.
            await this.surfaceAttentionTab(current, CAPTCHA_BADGE_TEXT);
            await this.endRun(current, "keep", { clearBadge: false });
            await this.noteNotice("captcha", { id: current.queueJobId, approvalId: current.approvalId, url: current.applyUrl, tabId: current.tabId });
            return "done";
        }
        if (res.reported) {
            await resetRecoveryCount(this.deps.localArea, current.queueJobId);
            // Berhenti karena ada kolom wajib kosong atau pertanyaan wajib yang hanya bisa dijawab pengguna: laporan
            // `incomplete` (`partly_filled`, beserta pertanyaannya) sudah sampai ke backend, sekarang pengguna diarahkan
            // ke tab dan panel. Tab tidak pernah dikirimkan formulirnya dari sini.
            const needs = fillNeedsInput(res);
            if (needs.stuck) {
                await this.handOffToUser(current, needs.questions);
                return "done";
            }
            // Mode tampil: berhenti sebelum kirim berarti pengguna memeriksa dan mengirim sendiri di tab ini. Tab tetap ada
            // (dan dibawa ke depan satu kali bila pengguna sudah berpindah).
            if (current.visible)
                await this.surfaceTabOnce(current);
            await this.endRun(current, "keep");
            // Berhenti tanpa pengguna bisa menjawab apa pun (formulir tidak ada, halaman diblokir): jelaskan di panel.
            const stoppedKind = res.formNotFound ? "form_not_found" : res.blocked ? "blocked" : null;
            if (stoppedKind) {
                await this.noteNotice(stoppedKind, { id: current.queueJobId, approvalId: current.approvalId, url: current.applyUrl, tabId: current.tabId });
            }
            return "done";
        }
        await this.safeRelease(current.queueJobId, {
            countRetry: true,
            delaySeconds: 30,
            error: res.error ?? res.code ?? "extension_fill_incomplete",
            ...(current.leaseId ? { leaseId: current.leaseId } : {}),
        });
        // Mode tampil membiarkan tab terbuka walau laporan gagal: lencana di halaman menjelaskan apa yang terjadi.
        await this.endRun(current, current.visible ? "keep" : "close");
        await this.noteNotice("failed", {
            id: current.queueJobId,
            approvalId: current.approvalId,
            url: current.applyUrl,
            ...(current.visible ? { tabId: current.tabId } : {}),
        });
        return "done";
    }
    /** Lepas tugas yang ditinggalkan tanpa kemajuan, dengan jatah pemulihan, lalu bersihkan dan tutup tab antrean. */
    async releaseAbandoned(run, base) {
        const slot = await claimRecoverySlot(this.deps.localArea, run.queueJobId, this.deps.now());
        await this.safeRelease(run.queueJobId, {
            countRetry: slot.countRetry,
            delaySeconds: base.delaySeconds,
            error: base.error,
            ...(run.leaseId ? { leaseId: run.leaseId } : {}),
        });
        await this.endRun(run, "close");
    }
    /** Browser lain mengambil tugas ini: berhenti segera, tutup tab antrean, hapus state, tanpa melapor. */
    async abandonLostLease(run) {
        await resetRecoveryCount(this.deps.localArea, run.queueJobId);
        await this.endRun(run, "close");
    }
    async safeRelease(queueJobId, opts) {
        try {
            await this.deps.client.releaseJob(queueJobId, opts);
        }
        catch {
            // Gagal rilis (jaringan, atau sewa sudah pindah): sewa kedaluwarsa sendiri di server.
        }
    }
    /**
     * Akhiri run lokal. State dan alarm dibersihkan LEBIH DULU supaya penutupan tab oleh antrean sendiri
     * (`tabs.onRemoved`) tidak dianggap pengguna menutup tab. `close`: tutup tab antrean dan sesinya;
     * `keep`: biarkan terbuka dan lepas dari catatan antrean (milik pengguna).
     */
    async endRun(run, mode, opts) {
        this.stopRequested.delete(run.queueJobId);
        // Pemberitahuan "menunggu login" dan sejenisnya berakhir bersama run-nya; yang masih perlu tampil dicatat lagi sesudahnya.
        await this.dropNotice(run.queueJobId);
        await this.cleanupActiveRunAndTimers(opts?.clearBadge ?? true);
        await this.dropQueueTab(run.tabId, mode);
    }
    async dropQueueTab(tabId, mode) {
        if (typeof tabId !== "number")
            return;
        if (mode === "keep") {
            await untrackQueueTab(this.deps.sessionArea, tabId).catch(() => undefined);
            return;
        }
        // Hanya tab yang tercatat dibuka antrean (id dicatat di storage.session; kosong sesudah browser dimulai ulang).
        if (!(await isQueueTab(this.deps.sessionArea, tabId).catch(() => false)))
            return;
        await untrackQueueTab(this.deps.sessionArea, tabId).catch(() => undefined);
        await clearQueueFillSession(this.deps.sessionArea, tabId).catch(() => undefined);
        try {
            await this.deps.closeTab?.(tabId);
        }
        catch {
            // Tab sudah tidak ada.
        }
    }
    /**
     * Teks kosong berarti "tidak ada tugas yang butuh perhatian": lencana kembali ke "!" bila masih ada situs yang
     * butuh izin, supaya lencana Login atau CAPTCHA yang selesai tidak menghapus petunjuk izin.
     */
    async setBadge(text) {
        if (text === "") {
            await this.showIdleBadge();
            return;
        }
        try {
            await this.deps.setBadge?.(text);
        }
        catch {
            // Badge hanya petunjuk visual.
        }
    }
    async showIdleBadge() {
        const entries = await loadPermissionNeeded(this.deps.localArea, this.deps.now()).catch(() => []);
        const needed = entries.length > 0;
        // Tab yang menunggu jawaban pengguna didahulukan dari "!" izin: itu satu-satunya petunjuk yang bisa dibuka dengan sekali klik.
        const waiting = (await this.listNeedsInput()).length > 0;
        const text = waiting ? NEEDS_INPUT_BADGE_TEXT : needed ? PERMISSION_BADGE_TEXT : "";
        try {
            await this.deps.setBadge?.(text);
        }
        catch {
            // Badge hanya petunjuk visual.
        }
        // Tooltip ikut disetel tiap kali (kosong = judul bawaan): judul yang tersisa dari service worker sebelumnya tidak boleh basi.
        try {
            await this.deps.setBadgeTitle?.(waiting ? NEEDS_INPUT_BADGE_TITLE : needed ? PERMISSION_BADGE_TITLE : "");
        }
        catch {
            // Tooltip hanya petunjuk visual.
        }
    }
    // ---------- pemberitahuan antrean di panel ----------
    /**
     * Catat hasil antrean yang harus dilihat pengguna di panel (src/lib/queueNotice.ts). Hanya host dan URL tanpa query.
     * Gagal mencatat tidak boleh menghentikan antrean: ini penjelasan, bukan bagian alur.
     */
    async noteNotice(kind, info) {
        try {
            const { host, url } = noticeLocation(info.url);
            await recordQueueNotice(this.deps.sessionArea, {
                id: info.id,
                kind,
                host,
                url,
                tabId: typeof info.tabId === "number" ? info.tabId : null,
                approvalId: info.approvalId ?? null,
                atMs: this.deps.now(),
            }, this.deps.now());
            this.deps.queueNoticeChanged?.();
        }
        catch {
            // Penjelasan tambahan saja.
        }
    }
    async dropNotice(queueJobId) {
        try {
            if (await clearQueueNotice(this.deps.sessionArea, queueJobId, this.deps.now()))
                this.deps.queueNoticeChanged?.();
        }
        catch {
            // Penjelasan tambahan saja.
        }
    }
    // ---------- izin situs ----------
    withPermissionLock(fn) {
        const run = this.permissionLock.then(fn, fn);
        this.permissionLock = run.catch(() => undefined);
        return run;
    }
    async notePermissionNeeded(applyUrl) {
        const entry = await this.withPermissionLock(() => recordPermissionNeeded(this.deps.localArea, applyUrl, this.deps.now()));
        if (!entry)
            return;
        await this.refreshIdleBadgeUnlessRunning();
        this.deps.permissionNeededChanged?.();
    }
    /**
     * Alur pengisian menemukan formulir di iframe lintas-origin yang belum diizinkan (U2B-06): catat hostnya supaya
     * panel menampilkan tombol Izinkan. Host di luar daftar ATS dan portal login tidak dicatat (lihat `recordPermissionNeeded`).
     */
    async noteHostPermissionNeeded(url) {
        await this.notePermissionNeeded(url);
    }
    /** Lencana Login atau CAPTCHA milik run yang aktif tidak ditimpa. */
    async refreshIdleBadgeUnlessRunning() {
        const active = await loadActiveQueueRun(this.deps.localArea).catch(() => null);
        if (!active)
            await this.showIdleBadge();
    }
    /** Situs yang masih butuh izin (kedaluwarsa dan yang sudah diizinkan dibuang lebih dulu). */
    async listPermissionNeeded() {
        const { remaining } = await this.syncPermissionNeeded();
        return remaining;
    }
    /**
     * Cocokkan catatan dengan izin yang sungguh dimiliki ekstensi sekarang. Catatan yang sudah terpenuhi (diberikan
     * lewat tombol Izinkan, tombol lain di panel, atau pengaturan Chrome) dihapus dan lencana diperbarui.
     */
    async syncPermissionNeeded() {
        const result = await this.withPermissionLock(() => syncPermissionNeeded(this.deps.localArea, this.deps.now(), (host) => this.deps.hasOriginPermission(permissionUrlForHost(host))));
        if (result.changed) {
            await this.refreshIdleBadgeUnlessRunning();
            this.deps.permissionNeededChanged?.();
        }
        return { cleared: result.cleared, remaining: result.remaining };
    }
    /**
     * Izin situs baru saja berubah (tombol Izinkan, event `permissions.onAdded`). Bila ada catatan yang kini
     * terpenuhi, langsung poll satu kali tanpa menunggu alarm, lalu pasang alarm satu kali untuk tugas yang
     * belum jatuh tempo di server (jeda pelepasan pendek). Mengembalikan sisa situs yang masih butuh izin.
     */
    async handlePermissionChange() {
        const { cleared, remaining } = await this.syncPermissionNeeded();
        if (cleared.length > 0)
            void this.pollAfterPermissionGrant();
        return remaining;
    }
    async pollAfterPermissionGrant() {
        const res = await this.pollOnce().catch(() => ({ action: "error" }));
        if (res.action === "idle" || res.action === "busy") {
            await this.deps
                .setAlarm(PERMISSION_RECHECK_ALARM, { delayInMinutes: PERMISSION_RECHECK_DELAY_MINUTES })
                .catch(() => undefined);
        }
    }
    async cleanupActiveRunAndTimers(clearBadge = true) {
        await Promise.all([
            clearActiveQueueRun(this.deps.localArea),
            this.deps.clearAlarm(QUEUE_HEARTBEAT_ALARM),
            this.deps.clearAlarm(AWAITING_LOGIN_ALARM),
        ]);
        if (clearBadge)
            await this.setBadge("");
    }
}

/**
 * Kirim pesan ke satu frame, dengan satu kali suntik ulang content script bila frame itu belum punya penerima.
 *
 * Uji live 26 November 2026: Side Panel menampilkan galat mentah Chrome "Could not establish connection. Receiving
 * end does not exist." Tab lowongan sudah terbuka sebelum ekstensi dimuat ulang, atau suntikan `allFrames` gagal dan
 * jatuh ke frame utama saja, sehingga frame yang dipilih tidak punya `content.js`. Galat itu kini memicu suntik ulang
 * ke frame tersebut lalu satu percobaan lagi; bila tetap gagal, pengguna mendapat langkah yang jelas.
 */
const NO_RECEIVER_RE = /Receiving end does not exist|Could not establish connection/i;
const RELOAD_TAB_MESSAGE = "Tab lowongan belum tersambung ke ekstensi. Muat ulang tab itu (F5), lalu klik Isi Formulir Sekarang lagi.";
const messageOf = (err) => typeof err?.message === "string" ? String(err.message) : String(err);
async function sendWithReinject(send, reinject) {
    try {
        return await send();
    }
    catch (err) {
        if (!NO_RECEIVER_RE.test(messageOf(err)))
            throw err;
    }
    await reinject().catch(() => undefined);
    try {
        return await send();
    }
    catch (err) {
        if (NO_RECEIVER_RE.test(messageOf(err)))
            throw new Error(RELOAD_TAB_MESSAGE);
        throw err;
    }
}

/**
 * Background Service Worker MV3 untuk Applify Form Copilot.
 *
 * Tidak menyimpan kunci AI, cookie situs pihak ketiga, atau kata sandi pengguna. Semua kecerdasan pengisian
 * tinggal di backend Applify (`/api/extension/*`) dengan token scoped `ext_tok_v1.*`.
 *
 * Sesi pengisian disimpan di `chrome.storage.session` (bukan memori service worker, yang dimatikan Chrome
 * setelah sekitar 30 detik menganggur). Catatan hasil yang belum terlapor ada di `chrome.storage.local`.
 *
 * URL backend tetap (`lib/config.ts`), bukan isian pengguna. Izin host wajib manifest: origin itu, ditambah semua
 * domain ATS, portal login, dan Google Forms (path /forms/) yang didukung, sehingga pengguna tidak pernah ditanya
 * izin per situs. Host lain: `activeTab` (klik ikon di tab itu). Kartu Izinkan di panel hanya pemulihan bila
 * pengguna mencabut akses situs lewat chrome://extensions (`lib/atsPermissions.ts`). Izin tambahan yang tersisa dari
 * versi lama dicabut saat Putus. Berkas lamaran hanya lewat di memori (tidak ke storage).
 */
const STORAGE_KEY = "applify_ext_config";
const MAX_RESUME_BYTES = 5_000_000;
/** Konfigurasi aktif. `serverUrl` selalu URL tetap build ini; yang tersimpan hanya token. */
async function getConfig() {
    const res = await chrome.storage.local.get(STORAGE_KEY);
    const resolved = resolveStoredConfig(res?.[STORAGE_KEY]);
    if (!resolved)
        return null;
    if (resolved.legacy) {
        // Konfigurasi versi lama menyimpan URL buatan pengguna. Buang URL itu, token dipertahankan.
        await chrome.storage.local.set({ [STORAGE_KEY]: { token: resolved.config.token } }).catch(() => undefined);
    }
    return resolved.config;
}
/** Tab aktif di jendela panel (atau jendela terakhir aktif bila `windowId` tidak diberikan). */
async function queryActiveTab(windowId) {
    const tabs = await chrome.tabs.query(typeof windowId === "number" ? { active: true, windowId } : { active: true, currentWindow: true });
    return tabs?.[0] ?? null;
}
async function getActiveTab(windowId) {
    const tab = await queryActiveTab(windowId);
    // Tanpa `tab.url` ekstensi belum diberi akses (activeTab) ke tab ini. Gagal tertutup.
    if (!tab?.id || !tab.url)
        throw new TabAccessError();
    return tab;
}
async function ensureContentScript(tabId) {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["content.js"] }).catch(async () => {
        await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    });
}
/**
 * Pilih frame dengan kontrol formulir terbanyak. Hanya dipanggil SEKALI per pengisian (dari `runFill`);
 * hasilnya disimpan di `FillSession` dan dipakai ulang oleh semua langkah berikutnya.
 *
 * Model per frame dipertahankan: skrip konten berjalan di tiap frame (`allFrames`), jadi iframe satu-origin adalah
 * kandidat tersendiri dengan skornya sendiri. Tidak ada penelusuran `iframe.contentDocument` dari frame induk: ID
 * kontrol, label, dan sesi isi ulang terikat pada satu frame.
 */
async function pickBestFrameId(tabId) {
    try {
        const frames = await chrome.scripting.executeScript({
            target: { tabId, allFrames: true },
            func: () => {
                const host = location.hostname.toLowerCase().replace(/^www\./, "");
                if (host === "linkedin.com" || host.endsWith(".linkedin.com"))
                    return { count: -1 };
                // Skor dari skrip konten (frame ini sudah disuntik): kontrol terlihat, termasuk shadow root terbuka, widget
                // ARIA, dan contenteditable. Tanpa skrip konten, hitungan selektor kasar seperti dulu.
                const score = window.__applifyFrameScore;
                if (typeof score === "function") {
                    try {
                        const n = score();
                        if (Number.isFinite(n) && n >= 0)
                            return { count: n };
                    }
                    catch {
                        // Jatuh ke hitungan kasar.
                    }
                }
                const count = document.querySelectorAll('input:not([type="hidden"]), textarea, select, [role="combobox"]').length;
                return { count };
            },
        });
        return chooseBestFrame(Array.isArray(frames) ? frames : []);
    }
    catch {
        return 0;
    }
}
/** URL frame bernomor `frameId` saat ini, atau null bila frame itu sudah tidak ada (atau tidak terbaca). */
async function getFrameUrl(tabId, frameId) {
    try {
        const res = await chrome.scripting.executeScript({
            target: { tabId, frameIds: [frameId] },
            func: () => location.href,
        });
        const entry = Array.isArray(res) ? res.find((r) => r?.frameId === undefined || r.frameId === frameId) : undefined;
        return typeof entry?.result === "string" ? entry.result : null;
    }
    catch {
        return null;
    }
}
/**
 * Kirim pesan lapisan tampilan ke skrip konten FRAME TERATAS tab (frame 0). Belum ada penerima (skrip konten belum
 * disuntik, atau halaman baru berpindah): suntik lalu coba sekali lagi. Hanya hiasan; galat apa pun ditelan.
 */
async function sendOverlay(tabId, message) {
    try {
        await chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
        return;
    }
    catch {
        // Jatuh ke suntik ulang di bawah (kecuali pesan pelepas atau pengambilan gambar, yang tidak butuh overlay baru).
    }
    if (message.mode === "remove" || message.mode === "capture_hide" || message.mode === "capture_show")
        return;
    try {
        await ensureContentScript(tabId);
        await chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
    }
    catch {
        // Tab tidak bisa dijangkau.
    }
}
/** Tangkapan layar PNG dalam anggaran ukuran. Hanya untuk tab yang masih aktif dan diizinkan. */
async function captureEvidence(tabId, expectedApplyUrl) {
    try {
        const tab = await chrome.tabs.get(tabId);
        if (!tab.active || !tab.url || !isScreenshotTabAllowed(tab.url, expectedApplyUrl))
            return null;
        const raw = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
        return await fitScreenshotToBudget(raw, offscreenPngCodec);
    }
    catch {
        return null;
    }
}
async function fetchResumeBase64(signedUrl) {
    const u = parseHttpUrl(signedUrl);
    if (!u || (u.protocol !== "https:" && u.hostname !== "localhost" && u.hostname !== "127.0.0.1"))
        return null;
    try {
        const res = await fetch(signedUrl, { credentials: "omit" });
        if (!res.ok)
            return null;
        const buf = new Uint8Array(await res.arrayBuffer());
        if (buf.length === 0 || buf.length > MAX_RESUME_BYTES)
            return null;
        let bin = "";
        const chunk = 0x8000;
        for (let i = 0; i < buf.length; i += chunk)
            bin += String.fromCharCode(...buf.subarray(i, i + chunk));
        return btoa(bin);
    }
    catch {
        return null;
    }
}
function buildDeps(cfg, windowId) {
    return {
        client: new ExtensionApiClient(cfg.serverUrl, cfg.token),
        sessionArea: chrome.storage.session,
        localArea: chrome.storage.local,
        getActiveTab: () => getActiveTab(windowId),
        ensureContentScript,
        pickFrame: pickBestFrameId,
        getFrameUrl,
        // Selalu ke satu frame (termasuk frame 0). Tanpa `frameId` Chrome menyiarkan ke semua frame dan frame mana
        // pun yang menjawab lebih dulu menang. Tidak ada cadangan ke frame lain bila frame itu hilang.
        sendToTab: (tabId, message, frameId) => sendWithReinject(() => chrome.tabs.sendMessage(tabId, message, { frameId }), 
        // Frame yang dituju belum punya content script (tab dibuka sebelum ekstensi dimuat ulang): suntik ke frame itu saja.
        () => chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: ["content.js"] })),
        captureEvidence,
        overlay: sendOverlay,
        // Iframe formulir lintas-origin: `allFrames` melewatinya diam-diam tanpa izin host, jadi izinnya dicek dan hostnya dicatat.
        hasHostAccess: (origin) => hasOriginPermissionForUrl(permissionUrlForOrigin(origin)),
        noteHostNeedsPermission: (url) => queueRunner.noteHostPermissionNeeded(url),
        fetchResumeBase64,
        sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
        now: () => Date.now(),
        newRunId: () => crypto.randomUUID(),
    };
}
let retrying = null;
async function requireClient() {
    const cfg = await getConfig();
    if (!cfg)
        throw new Error("not_connected");
    return new ExtensionApiClient(cfg.serverUrl, cfg.token);
}
/**
 * Tunggu tab `complete`. `null` = gagal (tab hilang, atau batas waktu habis dan halaman belum selesai dimuat):
 * antrean memperlakukannya sebagai kegagalan, bukan berhasil.
 */
function waitForTabReady(tabId, timeoutMs = 20_000) {
    return waitForTabComplete((id) => chrome.tabs.get(id).catch(() => null), tabId, timeoutMs);
}
async function hasOriginPermissionForUrl(rawUrl) {
    // Google Forms (termasuk forms.gle yang berakhir di docs.google.com) diperiksa lewat pola path /forms/*, bukan origin penuh.
    const pattern = accessPatternForUrl(rawUrl);
    if (!pattern)
        return false;
    return chrome.permissions.contains({ origins: [pattern] }).catch(() => false);
}
const queueRunner = new ExtensionQueueRunner({
    localArea: chrome.storage.local,
    sessionArea: chrome.storage.session,
    now: () => Date.now(),
    sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
    client: {
        claimNextJob: async (claimer) => {
            const cfg = await getConfig();
            if (!cfg)
                return null;
            return new ExtensionApiClient(cfg.serverUrl, cfg.token).claimNextJob(claimer);
        },
        heartbeatJob: async (queueJobId, leaseId) => (await requireClient()).heartbeatJob(queueJobId, leaseId),
        releaseJob: async (queueJobId, opts) => (await requireClient()).releaseJob(queueJobId, opts),
        reportRun: async (payload) => (await requireClient()).reportRun(payload),
    },
    // Mode tampil (`active`): tab aktif di jendela biasa terakhir yang difokuskan pengguna, di grup "Applify". Mode latar:
    // tab tidak aktif seperti semula. Grup tab hanya hiasan (butuh izin `tabGroups`, bukan izin host).
    createTab: (url, active) => openRunTab({
        windowsGetLastFocused: chrome.windows?.getLastFocused ? (options) => chrome.windows.getLastFocused(options) : undefined,
        tabsCreate: (props) => chrome.tabs.create(props),
        tabsGroup: chrome.tabs?.group ? (options) => chrome.tabs.group(options) : undefined,
        tabGroupsQuery: chrome.tabGroups?.query ? (query) => chrome.tabGroups.query(query) : undefined,
        tabGroupsUpdate: chrome.tabGroups?.update ? (groupId, props) => chrome.tabGroups.update(groupId, props) : undefined,
    }, url, active),
    getTab: (tabId) => chrome.tabs.get(tabId).catch(() => null),
    waitForTabReady,
    hasOriginPermission: hasOriginPermissionForUrl,
    setAlarm: async (name, info) => {
        await Promise.resolve(chrome.alarms?.create?.(name, info)).catch(() => undefined);
    },
    clearAlarm: async (name) => {
        await Promise.resolve(chrome.alarms?.clear?.(name)).catch(() => undefined);
    },
    executeFillOnTab: async (approval, tab, opts) => {
        const cfg = await getConfig();
        if (!cfg)
            return { ok: false, reported: false, code: "not_connected", error: "Ekstensi belum terhubung." };
        const visibleTabId = opts.visible === true && typeof tab.id === "number" ? tab.id : null;
        let res;
        try {
            res = await runFillOnTab(buildDeps(cfg, tab.windowId), approval, tab, {
                queueJobId: opts.queueJobId,
                waitOnAuthRequired: true,
                awaitingUntilIso: opts.awaitingUntilIso,
                reportAwaitingLogin: opts.reportAwaitingLogin,
                leaseId: opts.leaseId,
                waitForForm: true,
                visible: opts.visible,
                shouldAbort: opts.shouldAbort,
            });
        }
        catch (err) {
            // Jangan tinggalkan cahaya "sedang mengisi" menyala di tab bila pengisian mati di tengah jalan.
            if (visibleTabId !== null) {
                const failed = finalOverlayFor({ ok: false, error: describeError(err).message });
                if (failed)
                    await sendOverlay(visibleTabId, failed);
            }
            throw err;
        }
        // Lencana akhir ("Selesai mengisi · periksa lalu kirim sendiri di sini", butuh login, dsb.). Hentikan dipasang antrean.
        if (visibleTabId !== null && !res.aborted) {
            const final = finalOverlayFor(res);
            if (final)
                await sendOverlay(visibleTabId, final);
        }
        return res;
    },
    // Hanya dipanggil untuk tab yang dibuka antrean sendiri (id-nya dicatat di storage.session). `tabs.remove` tanpa izin `tabs`.
    closeTab: async (tabId) => {
        await chrome.tabs.remove(tabId).catch(() => undefined);
    },
    // `tabs.update` + `windows.update` tidak butuh izin tambahan. Tidak ada notifikasi sistem.
    surfaceTab: (tabId) => surfaceManagedTab({
        tabsUpdate: (id, props) => chrome.tabs.update(id, props),
        windowsUpdate: chrome.windows?.update ? (id, props) => chrome.windows.update(id, props) : undefined,
    }, tabId),
    showOverlay: sendOverlay,
    // Tiap alarm poll: hasil kirim atau pelepasan klaim yang belum terlapor dicoba lagi (jeda minimal dijaga di retryUnreported).
    retryUnreported: () => retryUnreportedNow(false),
    setBadge: async (text) => {
        await Promise.resolve(chrome.action?.setBadgeText?.({ text })).catch(() => undefined);
    },
    // Tooltip ikon: kosong mengembalikan judul bawaan manifest. `action.setTitle` tidak butuh izin tambahan.
    setBadgeTitle: async (title) => {
        const fallback = chrome.runtime.getManifest().action?.default_title ?? "Applify Form Copilot";
        await Promise.resolve(chrome.action?.setTitle?.({ title: title || fallback })).catch(() => undefined);
    },
    // Panel yang terbuka menyegarkan kartu "butuh izin". Gagal bila panel tertutup: tidak apa-apa.
    permissionNeededChanged: () => {
        Promise.resolve(chrome.runtime.sendMessage({ type: "PERMISSION_NEEDED_CHANGED" })).catch(() => undefined);
    },
    // Tab antrean berhenti menunggu jawaban: panel yang sudah terbuka memuat ulang pertanyaan tab aktif. Gagal bila panel tertutup: tidak apa-apa.
    needsInputChanged: () => {
        Promise.resolve(chrome.runtime.sendMessage({ type: "NEEDS_INPUT_CHANGED" })).catch(() => undefined);
    },
    // Pemberitahuan antrean (situs belum didukung, menunggu login, dihentikan, gagal, dan seterusnya) berubah: panel yang terbuka memuat ulang kartunya.
    queueNoticeChanged: () => {
        Promise.resolve(chrome.runtime.sendMessage({ type: "QUEUE_NOTICE_CHANGED" })).catch(() => undefined);
    },
    // Saklar "Isi otomatis di latar": bawaan aktif; mati = alarm poll tidak mengklaim tugas.
    isBackgroundFillEnabled: () => loadBackgroundFill(chrome.storage.local),
    // Saklar "Tampilkan tab saat mengisi": bawaan aktif; mati = tab dibuka tidak aktif di latar. Dibaca sekali per tugas.
    isVisibleRunEnabled: () => loadVisibleRun(chrome.storage.local),
});
/**
 * Galat jalur antrean (alarm, event tab, startup) dicatat ke status kesehatan runner, bukan ditelan diam-diam.
 * 401 menghentikan poll sampai token baru tersimpan. Status ini dibaca panel lewat GET_CONFIG.
 */
function noteRunnerFailure(err) {
    void updateRunnerHealth(chrome.storage.session, (h) => recordRunnerError(h, err, Date.now()));
}
async function ensureQueueLifecycle(recoverAndPoll) {
    const cfg = await getConfig();
    if (!cfg)
        return;
    await queueRunner.ensurePollAlarm().catch(noteRunnerFailure);
    if (recoverAndPoll) {
        await queueRunner.recoverOnStartup().catch(noteRunnerFailure);
        await queueRunner.pollOnce().catch(noteRunnerFailure);
    }
}
/** Coba lapor ulang hasil kirim yang belum terlapor. Aman dipanggil berulang. */
async function retryUnreportedNow(force) {
    if (retrying) {
        await retrying;
        return;
    }
    retrying = (async () => {
        const cfg = await getConfig();
        if (!cfg)
            return;
        const client = new ExtensionApiClient(cfg.serverUrl, cfg.token);
        await retryUnreported(chrome.storage.local, client, Date.now(), { force });
    })()
        .catch(() => undefined)
        .finally(() => {
        retrying = null;
    });
    await retrying;
}
chrome.runtime.onStartup.addListener(() => {
    void retryUnreportedNow(false);
    void ensureQueueLifecycle(true);
});
chrome.runtime.onInstalled.addListener(() => {
    void retryUnreportedNow(false);
    void ensureQueueLifecycle(true);
});
chrome.alarms?.onAlarm?.addListener((alarm) => {
    void queueRunner.handleAlarm(alarm.name).catch(noteRunnerFailure);
});
chrome.tabs?.onUpdated?.addListener((tabId, changeInfo, tab) => {
    void queueRunner.onTabUpdated(tabId, changeInfo, tab).catch(noteRunnerFailure);
});
chrome.tabs?.onRemoved?.addListener((tabId) => {
    void queueRunner.onTabRemoved(tabId).catch(noteRunnerFailure);
});
// Izin situs baru (tombol Izinkan, Buka Situs Lowongan, Isi Formulir Sekarang, atau pengaturan Chrome): catatan
// "butuh izin" yang terpenuhi dihapus dan antrean langsung dipoll tanpa menunggu alarm.
chrome.permissions?.onAdded?.addListener(() => {
    void queueRunner.handlePermissionChange().catch(noteRunnerFailure);
});
// Side panel dibuka lewat `action.onClicked`, bukan `openPanelOnActionClick`: klik ikon (gestur yang memberi
// `activeTab` untuk tab ini) membuka panel bila tertutup dan membiarkannya terbuka bila sudah terbuka, tanpa
// menutupnya. Dengan begitu pengguna bisa memberi akses ke tab lowongan baru sambil panel tetap terbuka.
// `sidePanel.open` harus dipanggil sinkron di dalam gestur, jadi tidak ada `await` sebelumnya.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => undefined);
chrome.action.onClicked.addListener((tab) => {
    if (typeof tab?.windowId === "number")
        chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => undefined);
    // Beri tahu panel yang sudah terbuka agar memeriksa ulang akses ke tab aktif. Gagal bila panel tertutup: tidak apa-apa.
    chrome.runtime.sendMessage({ type: "TAB_ACCESS_CHANGED" }).catch(() => undefined);
});
let submitInFlight = false;
function windowIdOf(msg) {
    return Number.isInteger(msg?.windowId) ? msg.windowId : undefined;
}
/** Daftar host yang butuh izin untuk panel: hanya host (sudah divalidasi terhadap daftar ATS dan portal login). */
async function permissionNeededForPanel() {
    const entries = await queueRunner.listPermissionNeeded().catch(() => []);
    return entries.map((e) => ({ host: e.host }));
}
/** Pemberitahuan antrean untuk kartu di panel. Hanya jenis, host, URL tanpa query, id tab, dan id persetujuan. */
async function queueNoticesForPanel() {
    return loadQueueNotices(chrome.storage.session, Date.now()).catch(() => []);
}
/** Akses ke tab aktif plus ringkasan sesi pengisian (tanpa tangkapan layar atau data halaman). */
async function tabStatus(windowId) {
    const tab = await queryActiveTab(windowId).catch(() => null);
    const access = describeTabAccess(tab);
    // Sesi manual milik tab ini, atau sesi antrean latar tab ini. Sesi manual tab lain tidak ditimpa oleh antrean.
    const session = summarizeSession((await loadFillSessionForTab(chrome.storage.session, tab?.id ?? undefined))?.session ?? null, tab);
    // Panel sedang menampilkan sesi tab ini (tab aktif = tab yang tadi diisi): serah-terima "Applify butuh jawabanmu"
    // untuk tab ini selesai, lencana "Jawab" di ikon dicabut. Sesinya sendiri tidak dihapus.
    if (session?.targetOk && typeof tab?.id === "number")
        await queueRunner.acknowledgeNeedsInput(tab.id).catch(() => undefined);
    return {
        access: access.state,
        host: access.host,
        isLinkedIn: access.state === "linkedin",
        /** Id tab aktif, supaya panel bisa mengikat pesan dan pertanyaannya ke tab ini dan membuangnya saat tab berganti. Hanya angka. */
        tabId: typeof tab?.id === "number" ? tab.id : null,
        session,
    };
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        switch (msg?.type) {
            case "SAVE_CONFIG": {
                // URL backend tetap: pesan hanya membawa token; URL apa pun dari pesan diabaikan.
                if (!isValidExtensionTokenFormat(msg.token)) {
                    return { ok: false, error: "Format token tidak valid. Tempel token `ext_tok_v1...` dari Pengaturan Applify." };
                }
                const newToken = msg.token.trim();
                await chrome.storage.local.set({ [STORAGE_KEY]: { token: newToken } });
                // Token baru: hapus status "sambungan kedaluwarsa" dan galat lama, supaya poll berjalan lagi. Sidik jari token
                // baru dicatat: 401 dari permintaan yang masih berjalan dengan token LAMA tidak boleh menandai ulang kedaluwarsa.
                await updateRunnerHealth(chrome.storage.session, (h) => clearRunnerAuthExpired(h, tokenFingerprint(newToken)));
                void retryUnreportedNow(false);
                void ensureQueueLifecycle(true);
                return { ok: true };
            }
            case "GET_CONFIG": {
                const cfg = await getConfig();
                void retryUnreportedNow(false);
                if (cfg)
                    void ensureQueueLifecycle(false);
                const unreported = await listUnreported(chrome.storage.local);
                return {
                    ok: true,
                    connected: Boolean(cfg),
                    permissionNeeded: cfg ? await permissionNeededForPanel() : [],
                    queueNotices: cfg ? await queueNoticesForPanel() : [],
                    unreported: summarizeUnreported(unreported),
                    unreportedWarning: unreportedWarningFor(unreported),
                    backgroundFill: await loadBackgroundFill(chrome.storage.local),
                    visibleRun: await loadVisibleRun(chrome.storage.local),
                    // Status kesehatan runner untuk kartu peringatan di panel (galat berulang, sambungan kedaluwarsa).
                    runnerHealth: await loadRunnerHealth(chrome.storage.session),
                    ...(await tabStatus(windowIdOf(msg))),
                };
            }
            // Saklar "Isi otomatis di latar" (kill switch). Mati: alarm poll berhenti mengklaim tugas baru.
            case "SET_BG_FILL": {
                if (typeof msg.enabled !== "boolean")
                    return { ok: false, error: "Nilai saklar tidak valid." };
                await saveBackgroundFill(chrome.storage.local, msg.enabled);
                // Hidup lagi: cukup satu poll. Tanpa `recoverOnStartup`, supaya tugas yang sedang berjalan tidak dianggap terputus.
                if (msg.enabled && (await getConfig()))
                    void queueRunner.pollOnce().catch(() => undefined);
                return { ok: true, backgroundFill: msg.enabled };
            }
            // Saklar "Tampilkan tab saat mengisi": hanya mengatur CARA tab dibuka untuk tugas berikutnya (tugas yang berjalan tidak berubah).
            case "SET_VISIBLE_RUN": {
                if (typeof msg.enabled !== "boolean")
                    return { ok: false, error: "Nilai saklar tidak valid." };
                await saveVisibleRun(chrome.storage.local, msg.enabled);
                return { ok: true, visibleRun: msg.enabled };
            }
            // Tombol Hentikan di overlay halaman. Hanya dari skrip konten frame teratas di tab milik run antrean yang aktif.
            case "AGENT_STOP": {
                const fromTab = sender?.tab?.id;
                if (typeof fromTab !== "number" || (sender?.frameId !== undefined && sender.frameId !== 0))
                    return { ok: false };
                return await queueRunner.requestStop(fromTab);
            }
            // Kartu pemberitahuan antrean di panel (dimuat ulang saat `QUEUE_NOTICE_CHANGED`).
            case "GET_QUEUE_NOTICES": {
                return { ok: true, queueNotices: (await getConfig()) ? await queueNoticesForPanel() : [] };
            }
            // Tombol "Tutup pemberitahuan" di kartu antrean. Hanya menghapus catatan penjelasan, tidak menyentuh tugas atau persetujuan.
            case "DISMISS_QUEUE_NOTICE": {
                if (typeof msg.id !== "string" || msg.id === "")
                    return { ok: false, error: "Pemberitahuan tidak dikenal.", code: "invalid_notice" };
                await clearQueueNotice(chrome.storage.session, msg.id, Date.now()).catch(() => false);
                return { ok: true, queueNotices: (await getConfig()) ? await queueNoticesForPanel() : [] };
            }
            // Tombol "Coba antrean lagi" di banner galat berulang: poll sekarang tanpa menunggu alarm. Poll yang mengambil tugas
            // berjalan lama, jadi jawabannya tidak menunggu selesai; kesehatan runner sudah tercatat begitu klaim kembali.
            case "POLL_QUEUE": {
                if (!(await getConfig()))
                    return { ok: false, error: "Ekstensi belum terhubung.", code: "not_connected" };
                const polled = await Promise.race([
                    queueRunner.pollOnce().catch(() => ({ action: "error" })),
                    new Promise((resolve) => setTimeout(() => resolve({ action: "running" }), 8000)),
                ]);
                return { ok: true, action: polled.action, runnerHealth: await loadRunnerHealth(chrome.storage.session) };
            }
            // Situs yang butuh izin (kartu "Izinkan" di panel). Hanya nama host, tanpa URL lowongan.
            case "GET_PERMISSION_NEEDED": {
                return { ok: true, permissionNeeded: (await getConfig()) ? await permissionNeededForPanel() : [] };
            }
            // Panel baru saja meminta izin situs lewat klik pengguna: cocokkan catatan, lalu poll langsung bila ada yang terpenuhi.
            case "PERMISSION_CHANGED": {
                const remaining = await queueRunner.handlePermissionChange();
                return { ok: true, permissionNeeded: remaining.map((e) => ({ host: e.host })) };
            }
            // Status tab aktif untuk side panel: dipanggil ulang tiap tab berpindah atau berubah.
            case "GET_TAB_STATUS": {
                return { ok: true, ...(await tabStatus(windowIdOf(msg))) };
            }
            case "RETRY_UNREPORTED": {
                await retryUnreportedNow(true);
                const unreported = await listUnreported(chrome.storage.local);
                return {
                    ok: true,
                    unreported: summarizeUnreported(unreported),
                    unreportedWarning: unreportedWarningFor(unreported),
                };
            }
            case "CLEAR_CONFIG": {
                await queueRunner.stopAllAlarmsAndState().catch(() => undefined);
                await clearFillSession(chrome.storage.session);
                await chrome.storage.local.remove(STORAGE_KEY);
                await updateRunnerHealth(chrome.storage.session, () => ({ ...EMPTY_RUNNER_HEALTH }));
                // Putus mencabut semua izin host opsional (domain ATS yang pernah disetujui). Izin wajib (backend) tetap.
                const revoked = await revokeOptionalPermissions(chrome.permissions, chrome.runtime.getManifest().host_permissions);
                return { ok: true, revokedOrigins: revoked };
            }
            case "LOAD_APPROVALS": {
                const cfg = await getConfig();
                if (!cfg)
                    return { ok: false, error: "Hubungkan token ekstensi terlebih dahulu." };
                void retryUnreportedNow(false);
                const { items } = await new ExtensionApiClient(cfg.serverUrl, cfg.token).fetchPendingApprovals();
                return { ok: true, items };
            }
            case "RUN_FILL": {
                const cfg = await getConfig();
                if (!cfg)
                    return { ok: false, error: "Ekstensi belum terhubung." };
                // H-02: jangan mengisi ulang saat pengiriman yang sedang berjalan belum selesai.
                if (submitInFlight)
                    return { ok: false, error: "Pengiriman sedang diproses. Tunggu hasilnya.", code: "submit_in_flight" };
                return await runFill(buildDeps(cfg, windowIdOf(msg)), msg.approval);
            }
            // Simpan jawaban pertanyaan dari panel, lalu isi ulang di tab dan frame yang sama (frame terkunci di sesi).
            case "SAVE_ANSWERS_REFILL": {
                const cfg = await getConfig();
                if (!cfg)
                    return { ok: false, error: "Ekstensi belum terhubung." };
                if (submitInFlight)
                    return { ok: false, error: "Pengiriman sedang diproses. Tunggu hasilnya.", code: "submit_in_flight" };
                return await runSaveAnswersAndRefill(buildDeps(cfg, windowIdOf(msg)), msg.approval, msg.answers, {
                    useSavedAnswers: msg.useSavedAnswers === true,
                });
            }
            case "AUTHORIZED_SUBMIT": {
                const cfg = await getConfig();
                if (!cfg)
                    return { ok: false, error: "Ekstensi belum terhubung." };
                if (submitInFlight)
                    return { ok: false, error: "Pengiriman sedang diproses. Tunggu hasilnya.", code: "submit_in_flight" };
                submitInFlight = true;
                try {
                    return await runAuthorizedSubmit(buildDeps(cfg, windowIdOf(msg)));
                }
                finally {
                    submitInFlight = false;
                }
            }
            default:
                return { ok: false, error: "Perintah tidak dikenal" };
        }
    })()
        .then(sendResponse)
        .catch((err) => {
        const mapped = describeError(err);
        sendResponse({ ok: false, error: mapped.message, code: mapped.code, status: mapped.status, terminal: mapped.terminal });
    });
    return true;
});
