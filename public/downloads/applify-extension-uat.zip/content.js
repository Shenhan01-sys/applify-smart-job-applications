(function () {
    'use strict';

    /**
     * Pesan dan teks lapisan tampilan (overlay) di halaman lowongan saat antrean mengisi dalam mode tampil.
     * Murni data dan fungsi tanpa `chrome.*` atau DOM, dipakai bersama oleh service worker dan skrip konten.
     */
    /** Nama elemen dan atribut penanda host overlay. Penelusuran DOM (`deepDom.ts`) melewati elemen ini. */
    const OVERLAY_HOST_TAG = "applify-agent-overlay";
    const OVERLAY_HOST_ATTR = "data-applify-overlay";
    const OVERLAY_TITLE_WORKING = "Applify sedang mengisi formulir ini · berhenti sebelum kirim";
    const OVERLAY_TITLE_STOPPING = "Menghentikan…";

    /**
     * Penelusuran DOM yang menembus shadow root TERBUKA (`el.shadowRoot`). Shadow root tertutup tidak terjangkau dari
     * skrip konten dan dilewati begitu saja.
     *
     * Semua fungsi aman di lingkungan tes tanpa `getRootNode` atau `shadowRoot`: hasilnya sama dengan pencarian biasa.
     * Penelusuran dibatasi kedalaman dan jumlah elemen supaya halaman aneh (komponen bersarang tanpa batas) tidak
     * menggantung skrip konten.
     */
    const MAX_SHADOW_DEPTH = 8;
    const MAX_WALKED_ELEMENTS = 30_000;
    /** Batas naik ke leluhur untuk pemeriksaan tersembunyi dan wadah. */
    const MAX_ANCESTOR_WALK = 40;
    /** Host lapisan tampilan Applify (`agentOverlay.ts`). Bukan bagian halaman: tidak pernah dibaca atau diisi. */
    function isOverlayHost(el) {
        try {
            return el.hasAttribute?.(OVERLAY_HOST_ATTR) === true;
        }
        catch {
            return false;
        }
    }
    /** Shadow root terbuka milik `el`, atau null. */
    function openShadowRootOf(el) {
        try {
            const root = el.shadowRoot;
            return root && typeof root.querySelectorAll === "function" ? root : null;
        }
        catch {
            return null;
        }
    }
    /** Induk elemen. Di puncak shadow root, induknya adalah host shadow root itu. */
    function parentOrHost(el) {
        if (el.parentElement)
            return el.parentElement;
        try {
            const root = el.getRootNode?.();
            if (root && root !== el && root.host)
                return root.host;
        }
        catch {
            // Lingkungan tanpa getRootNode.
        }
        return null;
    }
    /**
     * Akar (Document atau ShadowRoot) tempat `el` berada. Atribut `for`, `aria-labelledby`, dan `aria-controls`
     * hanya berlaku di akar yang sama, jadi pencarian label harus memakai akar ini, bukan dokumen.
     */
    function scopeOf(el, doc) {
        try {
            const root = el.getRootNode?.();
            if (root && typeof root.querySelector === "function" && typeof root.getElementById === "function")
                return root;
        }
        catch {
            // Lingkungan tanpa getRootNode.
        }
        return doc;
    }
    /** Elemen dengan id ini di akar `el` (atau dokumen sebagai cadangan). */
    function elementByIdNear(el, doc, id) {
        try {
            const scope = scopeOf(el, doc);
            const found = scope.getElementById(id);
            return found || scope === doc ? found : doc.getElementById(id);
        }
        catch {
            return null;
        }
    }
    /**
     * Semua elemen yang cocok dengan `selector` di bawah `root`, termasuk di dalam shadow root terbuka, dalam urutan
     * dokumen (isi shadow root muncul tepat setelah hostnya). `limit` menghentikan penelusuran lebih awal.
     */
    function deepQueryAll(root, selector, limit = Number.POSITIVE_INFINITY) {
        const out = [];
        let walked = 0;
        const visit = (scope, depth) => {
            if (out.length >= limit || walked >= MAX_WALKED_ELEMENTS)
                return;
            let matches;
            let all;
            try {
                matches = new Set(Array.from(scope.querySelectorAll(selector)));
                all = Array.from(scope.querySelectorAll("*"));
            }
            catch {
                return;
            }
            walked += all.length;
            for (const el of all) {
                // Host overlay dilewati beserta isinya, walau shadow root-nya (di lingkungan aneh) terbuka.
                if (isOverlayHost(el))
                    continue;
                if (matches.has(el)) {
                    out.push(el);
                    if (out.length >= limit)
                        return;
                }
                if (depth < MAX_SHADOW_DEPTH) {
                    const shadow = openShadowRootOf(el);
                    if (shadow)
                        visit(shadow, depth + 1);
                    if (out.length >= limit)
                        return;
                }
            }
        };
        const own = root.tagName ? openShadowRootOf(root) : null;
        if (own)
            visit(own, 1);
        visit(root, 0);
        return out;
    }
    /** `el.matches(selector)` yang aman: selektor rusak atau lingkungan tanpa `matches` dianggap tidak cocok. */
    function elementMatches(el, selector) {
        try {
            return typeof el.matches === "function" && el.matches(selector);
        }
        catch {
            return false;
        }
    }
    /** Elemen pertama yang cocok (urutan dokumen), atau null. */
    function deepQuery(root, selector) {
        return deepQueryAll(root, selector, 1)[0] ?? null;
    }
    const escapeAttrValue = (value) => value.replace(/["\\]/g, "\\$&");
    /** Elemen dengan atribut `attr` bernilai `value`. Jalur cepat lebih dulu, lalu menelusuri shadow root. */
    function findByAttr(root, attr, value) {
        const selector = `[${attr}="${escapeAttrValue(value)}"]`;
        try {
            const direct = root.querySelector(selector);
            if (direct)
                return direct;
        }
        catch {
            return null;
        }
        return deepQuery(root, selector);
    }
    /** Semua elemen dengan atribut `attr` bernilai `value`, termasuk di dalam shadow root. */
    function findAllByAttr(root, attr, value) {
        return deepQueryAll(root, `[${attr}="${escapeAttrValue(value)}"]`);
    }
    /** Elemen kontrol buatan ekstensi (`data-applify-cid`), termasuk di dalam shadow root terbuka. */
    function findControlByCid(root, controlId) {
        return findByAttr(root, "data-applify-cid", controlId);
    }
    /** `contenteditable` yang menandakan kotak teks: "", "true", atau "plaintext-only". "false" dan tanpa atribut bukan. */
    function isEditableHost(el) {
        const tag = el.tagName.toLowerCase();
        if (tag === "input" || tag === "textarea" || tag === "select")
            return false;
        const attr = el.getAttribute("contenteditable");
        if (attr === null)
            return false;
        return attr.trim().toLowerCase() !== "false";
    }
    /** Alasan penyembunyian dari satu simpul: atribut `hidden`, `aria-hidden="true"`, `inert`, atau `display:none`. */
    function hidesSubtree(node) {
        if (node.hidden === true || node.hasAttribute?.("hidden"))
            return true;
        if (node.getAttribute?.("aria-hidden") === "true")
            return true;
        if (node.hasAttribute?.("inert"))
            return true;
        if (typeof getComputedStyle === "function") {
            try {
                if (getComputedStyle(node).display === "none")
                    return true;
            }
            catch {
                // Lingkungan tes non-browser mengabaikan getComputedStyle
            }
        }
        return false;
    }
    function computedVisibility(node) {
        if (typeof getComputedStyle !== "function")
            return "";
        try {
            return String(getComputedStyle(node).visibility ?? "");
        }
        catch {
            return "";
        }
    }
    /**
     * Elemen berada di dalam leluhur yang tersembunyi: `hidden`, `aria-hidden="true"`, `inert`, `display:none`, atau
     * `visibility:hidden` (kecuali elemen itu sendiri menimpanya dengan `visible`). Penelusuran naik menembus batas shadow
     * root dan dibatasi `MAX_ANCESTOR_WALK` tingkat.
     */
    function hiddenByAncestor(el) {
        const selfVisible = computedVisibility(el) === "visible";
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < MAX_ANCESTOR_WALK; depth++, node = parentOrHost(node)) {
            if (hidesSubtree(node))
                return true;
            if (!selfVisible && computedVisibility(node) === "hidden")
                return true;
        }
        return false;
    }

    /**
     * Lapisan tampilan (overlay) saat ekstensi mengisi formulir di tab pengguna, supaya jelas bahwa yang bekerja adalah
     * Applify: cahaya lembut di tepi layar dan lencana kecil di atas dengan tombol Hentikan.
     *
     * Dibangun di dalam shadow root TERTUTUP: CSS halaman tidak bisa merusaknya, dan isinya tidak terjangkau penelusuran
     * DOM milik ekstensi (`deepDom.ts` hanya menembus shadow root terbuka dan juga melewati host bertanda
     * `data-applify-overlay`). Host-nya tidak punya anak di DOM biasa dan tidak punya `pointer-events`: cahaya tidak
     * menangkap klik, hanya tombolnya yang bisa diklik. Pembaruan teks terjadi di dalam shadow root, jadi tidak memicu
     * mutasi DOM halaman (penunggu "DOM tenang" tidak terganggu). Tidak pernah menyentuh isian, tombol, atau formulir halaman.
     */
    const HOST_STYLE = [
        "all:initial",
        "position:fixed",
        "inset:0",
        "z-index:2147483647",
        "pointer-events:none",
        "display:block",
        "contain:layout style",
    ]
        .map((rule) => `${rule} !important`)
        .join(";");
    const OVERLAY_CSS = `
:host { all: initial; }
[hidden] { display: none !important; }
.wrap { position: fixed; inset: 0; pointer-events: none; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
.wrap[data-capture="hide"] { display: none !important; }
.glow {
  position: fixed; inset: 0; pointer-events: none;
  box-shadow: inset 0 0 0 3px rgba(37, 99, 235, 0.55), inset 0 0 44px 8px rgba(37, 99, 235, 0.28);
  animation: applify-glow 2.6s ease-in-out infinite;
}
.wrap[data-mode="done"] .glow, .wrap[data-mode="attention"] .glow, .wrap[data-mode="stopped"] .glow { display: none; }
.badge {
  position: fixed; top: 12px; left: 50%; transform: translateX(-50%);
  display: flex; align-items: center; gap: 10px; box-sizing: border-box;
  max-width: min(92vw, 680px); padding: 8px 8px 8px 14px;
  background: #0f172a; color: #f8fafc; border-radius: 14px;
  box-shadow: 0 8px 28px rgba(15, 23, 42, 0.35), 0 0 0 1px rgba(148, 163, 184, 0.25);
  font-size: 13px; line-height: 1.35; pointer-events: none;
}
.dot { flex: none; width: 9px; height: 9px; border-radius: 50%; background: #60a5fa; animation: applify-dot 1.3s ease-in-out infinite; }
.wrap[data-mode="done"] .dot { background: #4ade80; animation: none; }
.wrap[data-mode="attention"] .dot { background: #fbbf24; animation: none; }
.wrap[data-mode="stopped"] .dot { background: #f87171; animation: none; }
.text { min-width: 0; display: flex; flex-direction: column; }
.title { font-weight: 600; }
.detail { font-size: 12px; color: #cbd5e1; }
button {
  flex: none; pointer-events: auto; cursor: pointer; font: inherit; font-weight: 600; font-size: 12px;
  color: #0f172a; background: #f8fafc; border: 0; border-radius: 9px; padding: 6px 12px;
}
button:hover { background: #e2e8f0; }
button:disabled { opacity: 0.6; cursor: default; }
button:focus-visible { outline: 2px solid #93c5fd; outline-offset: 2px; }
@keyframes applify-glow { 0%, 100% { opacity: 0.55; } 50% { opacity: 1; } }
@keyframes applify-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.35; } }
@media (prefers-reduced-motion: reduce) { .glow, .dot { animation: none !important; } }
`;
    /** Paling banyak kolom yang berkedip per langkah, supaya formulir panjang tidak menjadi pesta lampu. */
    const MAX_HIGHLIGHTED_CONTROLS = 10;
    const HIGHLIGHT_STAGGER_MS = 110;
    const HIGHLIGHT_DURATION_MS = 1100;
    /** Batas tunggu penyembunyian sebelum tangkapan layar: dua frame gambar, atau paling lama ini bila tab tidak menggambar. */
    const CAPTURE_PAINT_TIMEOUT_MS = 120;
    class AgentOverlay {
        host = null;
        refs = null;
        currentState = null;
        hiddenForCapture = false;
        doc;
        onStop;
        /** `onStop` dipanggil saat pengguna menekan Hentikan (mengirim `AGENT_STOP` ke service worker). */
        constructor(doc, onStop) {
            this.doc = doc;
            this.onStop = onStop;
        }
        /** Keadaan yang sedang tampil, atau null bila overlay tidak ada. */
        get state() {
            return this.refs ? this.currentState : null;
        }
        get isHiddenForCapture() {
            return this.refs !== null && this.hiddenForCapture;
        }
        get titleText() {
            return this.refs?.title.textContent ?? "";
        }
        get detailText() {
            return this.refs?.detail.textContent ?? "";
        }
        /** Terpasang di dokumen. */
        get mounted() {
            return this.host !== null && this.refs !== null && this.host.isConnected !== false;
        }
        async apply(msg) {
            try {
                switch (msg.mode) {
                    case "remove":
                        this.unmount();
                        return { ok: true };
                    case "capture_hide":
                        return await this.setCaptureHidden(true);
                    case "capture_show":
                        return await this.setCaptureHidden(false);
                    case "highlight":
                        if (!this.ensureMounted())
                            return { ok: false, error: "no_document" };
                        if (typeof msg.detail === "string")
                            this.setText(undefined, msg.detail);
                        this.pulse(Array.isArray(msg.controlIds) ? msg.controlIds : []);
                        return { ok: true };
                    case "working":
                    case "done":
                    case "attention":
                    case "stopped": {
                        if (!this.ensureMounted())
                            return { ok: false, error: "no_document" };
                        const refs = this.refs;
                        this.currentState = msg.mode;
                        refs.wrap.setAttribute("data-mode", msg.mode);
                        this.setText(msg.title ?? (msg.mode === "working" ? OVERLAY_TITLE_WORKING : ""), msg.detail ?? "");
                        const working = msg.mode === "working";
                        refs.stop.hidden = !working;
                        refs.stop.disabled = false;
                        refs.close.hidden = working;
                        return { ok: true };
                    }
                    default:
                        return { ok: false, error: "unknown_mode" };
                }
            }
            catch (err) {
                return { ok: false, error: err instanceof Error ? err.message : String(err) };
            }
        }
        /** Lepas overlay dari halaman (idempoten). */
        unmount() {
            try {
                this.host?.remove?.();
            }
            catch {
                // Halaman sudah membuangnya.
            }
            this.host = null;
            this.refs = null;
            this.currentState = null;
            this.hiddenForCapture = false;
        }
        setText(title, detail) {
            const refs = this.refs;
            if (!refs)
                return;
            if (title !== undefined)
                refs.title.textContent = title;
            refs.detail.textContent = detail;
            refs.detail.hidden = detail === "";
        }
        ensureMounted() {
            if (this.mounted)
                return true;
            // Halaman membuang host kita (mis. mengganti isi dokumen): bangun lagi.
            this.host = null;
            this.refs = null;
            const parent = this.doc.documentElement ?? this.doc.body;
            if (!parent)
                return false;
            const host = this.doc.createElement(OVERLAY_HOST_TAG);
            host.setAttribute(OVERLAY_HOST_ATTR, "1");
            host.setAttribute("style", HOST_STYLE);
            const root = host.attachShadow({ mode: "closed" });
            const style = this.doc.createElement("style");
            style.textContent = OVERLAY_CSS;
            root.appendChild(style);
            const wrap = this.doc.createElement("div");
            wrap.className = "wrap";
            wrap.setAttribute("data-mode", "working");
            const glow = this.doc.createElement("div");
            glow.className = "glow";
            wrap.appendChild(glow);
            const badge = this.doc.createElement("div");
            badge.className = "badge";
            badge.setAttribute("role", "status");
            badge.setAttribute("aria-live", "polite");
            const dot = this.doc.createElement("span");
            dot.className = "dot";
            const text = this.doc.createElement("span");
            text.className = "text";
            const title = this.doc.createElement("span");
            title.className = "title";
            const detail = this.doc.createElement("span");
            detail.className = "detail";
            text.appendChild(title);
            text.appendChild(detail);
            const stop = this.doc.createElement("button");
            stop.setAttribute("type", "button");
            stop.textContent = "Hentikan";
            stop.addEventListener("click", () => this.handleStop());
            const close = this.doc.createElement("button");
            close.setAttribute("type", "button");
            close.textContent = "Tutup";
            close.hidden = true;
            close.addEventListener("click", () => this.unmount());
            badge.appendChild(dot);
            badge.appendChild(text);
            badge.appendChild(stop);
            badge.appendChild(close);
            wrap.appendChild(badge);
            root.appendChild(wrap);
            parent.appendChild(host);
            this.host = host;
            this.refs = { wrap, title, detail, stop, close };
            this.currentState = "working";
            this.hiddenForCapture = false;
            return true;
        }
        handleStop() {
            const refs = this.refs;
            if (!refs || refs.stop.disabled)
                return;
            refs.stop.disabled = true;
            this.setText(OVERLAY_TITLE_STOPPING, "");
            try {
                this.onStop();
            }
            catch {
                // Service worker tidak terjangkau: tombol tetap menunjukkan bahwa permintaan sudah dikirim.
            }
        }
        /**
         * Sembunyikan (atau tampilkan lagi) seluruh overlay untuk tangkapan layar bukti, supaya gambarnya menunjukkan
         * formulir, bukan lencana. Selesai sesudah halaman sempat menggambar ulang (atau batas tunggu singkat).
         */
        async setCaptureHidden(hidden) {
            const refs = this.refs;
            if (!refs)
                return { ok: true };
            this.hiddenForCapture = hidden;
            if (hidden)
                refs.wrap.setAttribute("data-capture", "hide");
            else
                refs.wrap.removeAttribute("data-capture");
            if (hidden)
                await this.waitForPaint();
            return { ok: true };
        }
        waitForPaint() {
            return new Promise((resolve) => {
                let done = false;
                const finish = () => {
                    if (done)
                        return;
                    done = true;
                    resolve();
                };
                setTimeout(finish, CAPTURE_PAINT_TIMEOUT_MS);
                const raf = globalThis.requestAnimationFrame;
                if (typeof raf === "function")
                    raf(() => raf(finish));
            });
        }
        /** Kedipkan garis tepi kolom yang baru terisi. Animasi Web Animations tidak mengubah atribut atau gaya inline halaman. */
        pulse(controlIds) {
            controlIds.slice(0, MAX_HIGHLIGHTED_CONTROLS).forEach((id, index) => {
                const run = () => {
                    try {
                        const el = findControlByCid(this.doc, String(id));
                        if (!el || typeof el.animate !== "function")
                            return;
                        el.animate([
                            { outline: "3px solid rgba(37, 99, 235, 0.9)", outlineOffset: "2px" },
                            { outline: "3px solid rgba(37, 99, 235, 0)", outlineOffset: "9px" },
                        ], { duration: HIGHLIGHT_DURATION_MS, easing: "ease-out" });
                    }
                    catch {
                        // Hiasan saja.
                    }
                };
                if (index === 0)
                    run();
                else
                    setTimeout(run, index * HIGHLIGHT_STAGGER_MS);
            });
        }
    }
    let singleton = null;
    /** Overlay milik skrip konten ini. Hanya frame teratas yang memakainya (lihat `content/index.ts`). */
    function getAgentOverlay() {
        if (!singleton) {
            singleton = new AgentOverlay(document, () => {
                Promise.resolve(chrome.runtime.sendMessage({ type: "AGENT_STOP" })).catch(() => undefined);
            });
        }
        return singleton;
    }

    /**
     * Bahan murni (tanpa DOM, tanpa chrome.*) untuk dua tambahan alur pengisian:
     *   1. mengintip pilihan dropdown kustom yang masih tertutup sebelum perencana bekerja, dan
     *   2. putaran kedua perencanaan untuk kontrol yang gagal menempel sesudah dibaca ulang.
     *
     * Tidak ada nilai isian di sini. Petunjuk putaran kedua hanya kode alasan dari daftar tertutup.
     */
    /** Paling banyak dropdown yang diintip per langkah formulir. */
    const PEEK_MAX_CONTROLS = 25;
    const PEEK_MAX_OPTIONS = 50;
    const PEEK_MAX_LABEL_CHARS = 120;

    /**
     * Membaca galat validasi yang ditampilkan halaman untuk satu kolom: HTML5 Constraint Validation, `aria-invalid`,
     * `aria-describedby` / `aria-errormessage`, dan elemen pesan galat di wadah kolom itu (MUI, AntD, Chakra, Bootstrap,
     * `role="alert"`). Dipisah dari `fillControls.ts` supaya `extractControls.ts` bisa memakainya tanpa impor melingkar.
     *
     * Aturan anti false positive:
     *   - Kolom wajib yang masih KOSONG (`valueMissing`) bukan galat: itu urusan `countMissingRequired`.
     *   - Teks petunjuk biasa (helper text, hint) tidak pernah dianggap galat: hanya elemen yang bertanda galat
     *     (`role="alert"`, kelas ber-token error/invalid, `data-invalid="true"`) yang dibaca, dan hanya yang terlihat.
     *   - Wadah dengan lebih dari satu kolom isian tidak dipindai (galat kolom tetangga tidak boleh terbawa).
     */
    const FIELD_ERROR_FALLBACK = "Kolom tidak valid";
    const MAX_ERROR_CHARS = 200;
    const MAX_SCAN_NODES = 400;
    const MAX_CONTAINER_DEPTH = 6;
    const clean$1 = (raw, max = MAX_ERROR_CHARS) => typeof raw === "string" ? raw.replace(/\s+/g, " ").trim().slice(0, max) : "";
    /** Token kelas yang menandai kolom/pesan dalam keadaan galat: "Mui-error", "is-invalid", "form-item-explain-error", "has-error". */
    const ERROR_TOKEN_RE = /(?:^|[-_])(?:error|errors|invalid)(?:$|[-_])|errormessage|errortext/i;
    const NEGATED_TOKEN_RE = /(?:^|[-_])(?:no|without|hide|hidden)[-_]?(?:error|errors|invalid)|error[-_]?free/i;
    /** Item formulir (AntD `ant-form-item`, MUI `MuiFormControl-root`, Bootstrap `form-group`, Chakra `chakra-form-control`) dan fieldset: wadah satu pertanyaan, boleh memuat beberapa kolom (prefiks + nomor). */
    const FORM_ITEM_CLASS_RE = /(?:^|\s)(?:[\w-]*form-item|[\w-]*FormControl-root|form-group|chakra-form-control)(?:\s|$)/;
    function classTokens(el) {
        const raw = el.getAttribute?.("class") ?? "";
        return typeof raw === "string" ? raw.split(/\s+/).filter(Boolean) : [];
    }
    function hasErrorClass(el) {
        return classTokens(el).some((t) => ERROR_TOKEN_RE.test(t) && !NEGATED_TOKEN_RE.test(t));
    }
    const isAlertRole = (el) => (el.getAttribute?.("role") ?? "").trim().toLowerCase() === "alert";
    const isDataInvalid = (el) => el.getAttribute?.("data-invalid") === "true";
    /** Elemen yang menandai dirinya sebagai pesan atau keadaan galat. */
    function isErrorMarker(el) {
        return isAlertRole(el) || isDataInvalid(el) || hasErrorClass(el);
    }
    const NON_MESSAGE_TAGS = new Set(["label", "legend", "input", "textarea", "select", "option", "button", "svg", "path", "script", "style"]);
    const FIELD_SELECTOR = "input, textarea, select";
    const typeOf = (el) => (el.getAttribute?.("type") ?? "").toLowerCase();
    const isAnswerField = (el) => {
        const tag = el.tagName.toLowerCase();
        if (tag === "textarea" || tag === "select")
            return true;
        if (tag !== "input")
            return false;
        return !["hidden", "submit", "button", "image", "reset", "search"].includes(typeOf(el));
    };
    function isVisibleNode(node) {
        if (node.hidden === true || node.hasAttribute?.("hidden"))
            return false;
        if (node.getAttribute?.("aria-hidden") === "true")
            return false;
        if (hiddenByAncestor(node))
            return false;
        if (typeof getComputedStyle === "function") {
            try {
                const style = getComputedStyle(node);
                if (style.display === "none" || style.visibility === "hidden")
                    return false;
            }
            catch {
                // Lingkungan tes non-browser.
            }
        }
        const box = node;
        if (typeof box.getBoundingClientRect === "function") {
            try {
                const rect = box.getBoundingClientRect();
                if (rect.width <= 0 && rect.height <= 0)
                    return false;
            }
            catch {
                // Tanpa tata letak: anggap terlihat.
            }
        }
        return true;
    }
    const messageOf = (node) => clean$1(node.textContent ?? node.innerText ?? "");
    function holdsField(node) {
        try {
            return node.querySelectorAll(FIELD_SELECTOR).length > 0;
        }
        catch {
            return false;
        }
    }
    const MIN_MESSAGE_ALNUM = 2;
    /** Pesan yang sungguhan memuat minimal dua huruf/angka: tanda bintang wajib ("*") atau tanda baca saja bukan pesan galat. */
    const hasMessageContent = (text) => (text.match(/[\p{L}\p{N}]/gu)?.length ?? 0) >= MIN_MESSAGE_ALNUM;
    /** Teks pesan dari simpul penanda: simpul itu sendiri, atau turunan bertanda yang punya teks. Null bila tidak terlihat atau kosong. */
    function markerText(node) {
        if (!isVisibleNode(node))
            return null;
        if (!NON_MESSAGE_TAGS.has(node.tagName.toLowerCase()) && !holdsField(node)) {
            const own = messageOf(node);
            if (own && hasMessageContent(own))
                return own;
        }
        return null;
    }
    function elementById(el, id) {
        try {
            return elementByIdNear(el, (el.ownerDocument ?? undefined), id);
        }
        catch {
            return null;
        }
    }
    const idsOf = (el, attr) => (el.getAttribute?.(attr) ?? "").split(/\s+/).filter(Boolean);
    /** Pesan dari `aria-describedby`: hanya simpul bertanda galat; sisanya teks petunjuk biasa dan diabaikan. `acceptAny`: kolom sudah bertanda tidak valid. */
    function describedByError(el, acceptAny) {
        for (const id of idsOf(el, "aria-describedby")) {
            const node = elementById(el, id);
            if (!node || !isVisibleNode(node))
                continue;
            if (isErrorMarker(node)) {
                const text = markerText(node);
                if (text)
                    return text;
            }
            const nested = Array.from(node.querySelectorAll?.("*") ?? []).slice(0, MAX_SCAN_NODES);
            for (const child of nested) {
                if (!isErrorMarker(child))
                    continue;
                const text = markerText(child);
                if (text)
                    return text;
            }
            if (acceptAny) {
                const text = markerText(node);
                if (text)
                    return text;
            }
        }
        return null;
    }
    function errorMessageAttr(el) {
        for (const id of idsOf(el, "aria-errormessage")) {
            const node = elementById(el, id);
            if (!node || !isVisibleNode(node))
                continue;
            const text = markerText(node);
            if (text)
                return text;
        }
        return null;
    }
    function countFieldsIn(node) {
        let count = 0;
        try {
            for (const f of Array.from(node.querySelectorAll(FIELD_SELECTOR)))
                if (isAnswerField(f))
                    count++;
        }
        catch {
            return 0;
        }
        return count;
    }
    /** `node` berada di dalam `<label>` atau `<legend>` yang tidak membungkus `field`: itu teks label (mis. tanda bintang wajib), bukan pesan galat. */
    function insideLabelOf(node, field) {
        for (let n = parentOrHost(node); n; n = parentOrHost(n)) {
            const tag = n.tagName.toLowerCase();
            if (tag === "label" || tag === "legend")
                return !n.contains?.(field);
        }
        return false;
    }
    /** Pesan galat pertama di bawah satu wadah, atau null. Kolom itu sendiri, pembungkusnya, dan teks label dilewati. */
    function scanContainerForError(container, el) {
        let candidates = [];
        try {
            candidates = deepQueryAll(container, "*").slice(0, MAX_SCAN_NODES);
        }
        catch {
            candidates = [];
        }
        for (const c of candidates) {
            if (c === el || c.contains?.(el) || !isErrorMarker(c) || insideLabelOf(c, el))
                continue;
            const text = markerText(c);
            if (text)
                return text;
        }
        return null;
    }
    /**
     * Pesan galat di wadah terdekat kolom ini. Pembungkus terdekat selalu dipindai. Pembungkus di atasnya dipindai hanya
     * bila pendakian sampai ke item formulir atau `fieldset` (batas wadah satu pertanyaan). Tanpa batas seperti itu
     * pendakian berhenti, supaya banner `role="alert"` milik halaman (mis. "Sesi Anda akan berakhir") tidak terbaca sebagai
     * galat kolom. Maksimal 6 tingkat; berhenti di `<form>`/`<body>` dan di wadah yang memuat lebih dari satu kolom isian.
     */
    function containerError(el) {
        const chain = [];
        let depth = 0;
        for (let node = parentOrHost(el); node && depth < MAX_CONTAINER_DEPTH; node = parentOrHost(node), depth++) {
            const tag = node.tagName.toLowerCase();
            if (tag === "body" || tag === "html" || tag === "form")
                break;
            const isItem = FORM_ITEM_CLASS_RE.test(node.getAttribute?.("class") ?? "") || tag === "fieldset";
            if (!isItem && countFieldsIn(node) > 1)
                break;
            chain.push({ node, isItem });
            if (isItem)
                break;
        }
        const reachedItem = chain.length > 0 && chain[chain.length - 1].isItem;
        for (const { node } of reachedItem ? chain : chain.slice(0, 1)) {
            const text = scanContainerForError(node, el);
            if (text)
                return text;
        }
        // Pesan tanpa penanda apa pun (kelas acak, tanpa role/aria). Uji live JobStreet 26 November 2026: "Silakan tambahkan
        // Nama perusahaan" hanya span di wadah kolom. Diterima hanya teks yang jelas menuntut isian, di wadah satu kolom.
        for (const { node } of chain) {
            const text = requiredPromptIn(node, el);
            if (text)
                return text;
        }
        return null;
    }
    /** Teks yang jelas menagih isian kolom. Lebih sempit dari deteksi wajib di ekstraksi: hanya kalimat perintah atau galat. */
    const REQUIRED_PROMPT_RE = /^(?:silakan (?:tambahkan|isi|pilih|masukkan|lengkapi)\b|[\p{L} ]{0,40}\b(?:wajib diisi|harus diisi|tidak boleh kosong|is required|can['’]?t be blank|cannot be (?:blank|empty))\b|please (?:add|enter|select|provide|fill in|choose)\b|this field is required)/iu;
    function requiredPromptIn(container, el) {
        let nodes = [];
        try {
            nodes = deepQueryAll(container, "*").slice(0, MAX_SCAN_NODES);
        }
        catch {
            nodes = [];
        }
        for (const n of nodes) {
            if (n === el || n.contains?.(el) || holdsField(n) || insideLabelOf(n, el))
                continue;
            if (NON_MESSAGE_TAGS.has(n.tagName.toLowerCase()))
                continue;
            if (Array.from(n.children ?? []).some((c) => (c.textContent ?? "").trim() !== "" && c.tagName.toLowerCase() !== "svg"))
                continue;
            const text = messageOf(n);
            if (!text || text.length > 120 || !REQUIRED_PROMPT_RE.test(text) || !isVisibleNode(n))
                continue;
            return text;
        }
        return null;
    }
    /** Kolom ini sendiri (atau pembungkus dekatnya) bertanda tidak valid oleh halaman. */
    function flaggedInvalid(el) {
        if (el.getAttribute?.("aria-invalid") === "true" || isDataInvalid(el) || hasErrorClass(el))
            return true;
        let n = parentOrHost(el);
        for (let depth = 0; n && depth < 3; depth++, n = parentOrHost(n)) {
            if (isDataInvalid(n) || (hasErrorClass(n) && !isAlertRole(n) && n.tagName.toLowerCase() !== "form"))
                return true;
        }
        return false;
    }
    /** Galat HTML5 Constraint Validation yang bukan sekadar "wajib diisi tetapi masih kosong". */
    function validityMessage(el) {
        const field = el;
        const v = field.validity;
        if (!v || v.valid !== false)
            return null;
        const real = v.typeMismatch || v.patternMismatch || v.tooShort || v.tooLong || v.rangeUnderflow || v.rangeOverflow || v.stepMismatch || v.badInput || v.customError;
        if (!real)
            return null;
        return clean$1(field.validationMessage) || FIELD_ERROR_FALLBACK;
    }
    /**
     * Pesan galat validasi yang sedang tampil untuk `el`, atau null bila kolom tampak baik. Urutan: (a) Constraint
     * Validation, (b) `aria-invalid`/`data-invalid`/kelas galat, (c) `aria-describedby`/`aria-errormessage`,
     * (d) elemen pesan galat di wadah kolom. Bila kolom bertanda tidak valid tetapi tidak ada teks pesan, "Kolom tidak valid".
     */
    function extractFieldErrorMessage(el) {
        const fromValidity = validityMessage(el);
        if (fromValidity)
            return fromValidity;
        const flagged = flaggedInvalid(el);
        const ariaInvalid = el.getAttribute?.("aria-invalid") === "true";
        const message = describedByError(el, ariaInvalid) ?? (ariaInvalid ? errorMessageAttr(el) : null) ?? containerError(el);
        if (message)
            return message;
        return flagged ? FIELD_ERROR_FALLBACK : null;
    }
    /** Pesan galat terlihat di bawah `root` (maksimal `limit`, unik): `role="alert"`, kelas galat, `data-invalid`. Untuk ringkasan snapshot. */
    function collectValidationErrors(root, limit = 8) {
        const out = [];
        let nodes = [];
        try {
            nodes = deepQueryAll(root, '[role="alert"], [class*="error"], [class*="Error"], [class*="invalid"], [data-invalid]');
        }
        catch {
            nodes = [];
        }
        for (const node of nodes.slice(0, MAX_SCAN_NODES)) {
            if (out.length >= limit)
                break;
            if (!isErrorMarker(node))
                continue;
            const text = markerText(node);
            if (text && !out.includes(text))
                out.push(text);
        }
        return out;
    }

    // AUTO-GENERATED from project/shared/domains.json via project/scripts/sync-domains.mjs. DO NOT EDIT BY HAND.
    const EXTERNAL_AUTH_PORTAL_MAP = {
        "jobstreet.com": [
            "login.seek.com",
            "auth.seek.com"
        ],
        "jobstreet.co.id": [
            "login.seek.com",
            "auth.seek.com"
        ]
    };

    /**
     * Penjaga keamanan & domain untuk Ekstensi Browser Chrome/Edge Applify.
     *
     * Aturan utama:
     *   - Lowongan/domain LinkedIn selalu ditolak (manual-only).
     *   - Hanya URL http(s) yang sah; remote API wajib HTTPS kecuali localhost/127.0.0.1.
     *   - Token wajib berawalan `ext_tok_v1.` (menolak JWT Supabase penuh agar pemisahan scope terjaga).
     *   - Tangkapan layar `captureVisibleTab` hanya diizinkan pada tab lowongan/ATS terkait.
     */
    function parseHttpUrl(raw) {
        if (typeof raw !== "string")
            return null;
        const trimmed = raw.trim();
        if (!trimmed)
            return null;
        try {
            const u = new URL(trimmed);
            if (u.protocol !== "http:" && u.protocol !== "https:")
                return null;
            return u;
        }
        catch {
            return null;
        }
    }
    function isLinkedInUrl(rawUrl) {
        const u = parseHttpUrl(rawUrl);
        if (!u)
            return false;
        const h = u.hostname.toLowerCase().replace(/^www\./, "");
        return h === "linkedin.com" || h.endsWith(".linkedin.com");
    }

    /**
     * Google Forms (lowongan di luar portal sering memakai tautan `forms.gle`). Bukan ATS dan bukan portal login, jadi
     * tidak masuk daftar domain bersama (`domains.json`): ini kasus tersendiri dengan izin yang dibatasi PATH.
     * `docs.google.com` juga rumah Docs, Sheets, dan Drive, jadi izinnya hanya `https://docs.google.com/forms/*`.
     * `forms.gle` hanya pengalih HTTP ke sana: tidak butuh izin sendiri (tab berakhir di docs.google.com).
     */
    const GOOGLE_FORMS_HOST = "docs.google.com";
    const GOOGLE_FORMS_SHORT_HOST = "forms.gle";
    /**
     * URL Google Forms yang dicakup izin di atas: `forms.gle/<kode>` (pengalih), atau `docs.google.com/forms/...`. Hanya
     * HTTPS. Path `/u/0/forms/` dan `/a/<domain>/forms/` (akun Workspace) tidak dicakup pola `/forms/*`, jadi bukan cocok.
     */
    function isGoogleFormsUrl(rawUrl) {
        const url = parseHttpUrl(rawUrl);
        if (!url || url.protocol !== "https:")
            return false;
        const host = url.hostname.toLowerCase().replace(/\.$/, "");
        if (host === GOOGLE_FORMS_SHORT_HOST)
            return url.pathname.length > 1;
        return host === GOOGLE_FORMS_HOST && (url.pathname === "/forms" || url.pathname.startsWith("/forms/"));
    }
    /** Daftar seluruh host autentikasi eksternal dikenal milik portal (mis. `login.seek.com` untuk JobStreet). */
    [
        ...new Set(Object.values(EXTERNAL_AUTH_PORTAL_MAP).flat()),
    ];

    /**
     * Bantuan membaca Google Forms (`docs.google.com/forms/.../viewform`). Markup-nya bukan `<label>` dan `<fieldset>`:
     *   - tiap pertanyaan adalah `div[role=listitem]` dengan judul `[role=heading]` (bintang "*" menandai wajib);
     *   - pilihan ganda `div[role=radio]` dalam `role=radiogroup`; kotak centang `div[role=checkbox]` dalam `role=group`;
     *   - dropdown `div[role=listbox]` berisi `role=option` (bukan `<select>` dan bukan combobox);
     *   - jawaban singkat dan paragraf adalah `<input>` dan `<textarea>` biasa (`required` dan `aria-required`);
     *   - tombol halaman `div[role=button]`: "Berikutnya" (langkah), "Kirim" (kirim akhir), "Kembali", "Hapus formulir".
     * Modul ini hanya membaca. Tidak ada klik, dan nilai isian tidak pernah dibaca atau dikirim ke tempat baru.
     */
    const clean = (raw, max) => (typeof raw === "string" ? raw.replace(/\s+/g, " ").trim().slice(0, max) : "");
    const explicitRoleOf$1 = (el) => (el.getAttribute("role") ?? "").trim().toLowerCase().split(/\s+/)[0] ?? "";
    /** Bintang wajib di ujung judul ("Nama *", "Nama*", "Nama ✱"). */
    const TRAILING_REQUIRED_MARK_RE = /\s*[*✱]+\s*$/;
    /** Penanda wajib yang hanya berupa `aria-label` ("Wajib diisi", "Required question"). */
    const REQUIRED_LABEL_RE = /wajib|required/i;
    const MAX_QUESTION_DEPTH = 14;
    const MAX_TITLE_CHARS = 300;
    const MAX_OPTION_CHARS = 120;
    const MAX_OPTIONS = 50;
    /** Halaman ini Google Forms? Dari URL frame ini (`pageUrl`, atau `location.href` dokumen), bukan dari isi DOM. */
    function isGoogleFormsPage(doc, pageUrl) {
        return isGoogleFormsUrl(pageUrl ?? doc.location?.href);
    }
    function readQuestion(container) {
        const headings = deepQueryAll(container, '[role="heading"]');
        const heading = headings.find((h) => clean(h.textContent, MAX_TITLE_CHARS) !== "");
        if (!heading)
            return null;
        let text = clean(heading.textContent, MAX_TITLE_CHARS);
        let required = TRAILING_REQUIRED_MARK_RE.test(text);
        for (const marker of deepQueryAll(heading, "[aria-label]")) {
            if (!REQUIRED_LABEL_RE.test(marker.getAttribute("aria-label") ?? ""))
                continue;
            required = true;
            // Teks penanda yang ikut di ujung judul ("Nama Wajib diisi") bukan bagian pertanyaan.
            const markerText = clean(marker.textContent, MAX_TITLE_CHARS);
            if (markerText && text.endsWith(markerText) && markerText.length < text.length)
                text = text.slice(0, -markerText.length).trim();
        }
        const title = text.replace(TRAILING_REQUIRED_MARK_RE, "").trim();
        return title ? { container, title, required } : null;
    }
    /** Pertanyaan Google Forms yang memuat `el` (listitem terdekat yang punya judul), atau null bila `el` bukan di dalam pertanyaan. */
    function googleQuestionOf(el) {
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < MAX_QUESTION_DEPTH; depth++, node = parentOrHost(node)) {
            if (explicitRoleOf$1(node) !== "listitem")
                continue;
            const question = readQuestion(node);
            if (question)
                return question;
        }
        return null;
    }
    const NON_ANSWER_TYPES = new Set(["hidden", "submit", "button", "image", "reset", "file"]);
    /** Jumlah kolom jawaban dan pilihan dalam satu pertanyaan (isian, area teks, dropdown, radio, kotak centang). */
    function answerCountIn(container) {
        return deepQueryAll(container, 'input, textarea, [role="listbox"], [role="radio"], [role="checkbox"]').filter((c) => !(c.tagName.toLowerCase() === "input" && NON_ANSWER_TYPES.has((c.getAttribute("type") ?? "text").toLowerCase()))).length;
    }
    /** Elemen ada di dalam kelompok pilihan (`radiogroup` atau `group`) di pertanyaannya, mis. kolom "Lainnya:" milik radio. */
    function insideChoiceGroup(el, question) {
        let node = parentOrHost(el);
        for (let depth = 0; node && node !== question.container && depth < MAX_QUESTION_DEPTH; depth++, node = parentOrHost(node)) {
            const role = explicitRoleOf$1(node);
            if (role === "radiogroup" || role === "group")
                return true;
        }
        return false;
    }
    /** Leluhur `el` di dalam pertanyaannya bertanda `aria-required="true"` (kelompok kotak centang atau radio yang wajib). */
    function ancestorRequired(el, question) {
        let node = parentOrHost(el);
        for (let depth = 0; node && node !== question.container && depth < MAX_QUESTION_DEPTH; depth++, node = parentOrHost(node)) {
            if (node.getAttribute("aria-required") === "true")
                return true;
        }
        return false;
    }
    /**
     * Label kontrol dalam pertanyaannya. Pertanyaan dengan satu kolom memakai judulnya; bila ada beberapa kolom atau
     * pilihan (kotak centang, kolom "Lainnya:", bagian tanggal), labelnya "judul: label kontrol" supaya perencana tahu
     * pilihan itu milik pertanyaan yang mana. `own` yang sama dengan judul (atau memuatnya) tidak digandakan.
     */
    function googleControlLabel(question, own, forceShared = false) {
        const part = clean(own, MAX_TITLE_CHARS).replace(TRAILING_REQUIRED_MARK_RE, "").trim();
        const title = question.title;
        if (!part || part.toLowerCase() === title.toLowerCase())
            return title;
        if (!forceShared && answerCountIn(question.container) <= 1)
            return title;
        if (part.toLowerCase().includes(title.toLowerCase()))
            return part;
        return clean(`${title}: ${part}`, MAX_TITLE_CHARS);
    }
    /** Penanda kosong di dropdown ("Pilih", "Choose") berciri `data-value=""`: bukan jawaban. */
    const isPlaceholderOption = (o) => o.getAttribute("data-value") === "";
    const optionText = (o) => clean(o.textContent, MAX_OPTION_CHARS) || clean(o.getAttribute("data-value"), MAX_OPTION_CHARS);
    /** Pilihan dan nilai terpilih sebuah `role=listbox` Google Forms. Pilihan boleh belum terlihat (daftar tertutup). */
    function googleDropdown(listbox) {
        const options = deepQueryAll(listbox, '[role="option"]').filter((o) => !isPlaceholderOption(o));
        const labels = [];
        for (const o of options) {
            const text = optionText(o);
            if (text && !labels.includes(text))
                labels.push(text);
            if (labels.length >= MAX_OPTIONS)
                break;
        }
        const chosen = options.find((o) => o.getAttribute("aria-selected") === "true");
        return { labels, selected: chosen ? optionText(chosen) : "" };
    }
    /** Dropdown wajib sudah terpilih? Hanya bila ada pilihan ber-`aria-selected` (tanpa itu keadaannya tidak diketahui, bukan "kosong"). */
    function listboxHasSelection(listbox) {
        const options = deepQueryAll(listbox, '[role="option"]');
        if (!options.some((o) => o.hasAttribute("aria-selected")))
            return null;
        return options.some((o) => o.getAttribute("aria-selected") === "true" && !isPlaceholderOption(o));
    }

    /**
     * Ekstraktor kontrol formulir DOM yang meminimalkan kebocoran data:
     *   - TIDAK pernah membaca cookie situs, `localStorage`, isi skrip, atau raw HTML halaman.
     *   - Kontrol `<input type="password">` TIDAK dikirim (hanya mengembalikan penanda `hasPasswordInput: true`).
     *   - Teks pemberitahuan halaman dibatasi <= 2500 karakter untuk deteksi CAPTCHA / login / larangan AI.
     */
    const MAX_EXTRACTED_CONTROLS = 300;
    const MAX_NOTICE_CHARS = 2500;
    const MAX_SECTION_HEADINGS = 12;
    const MAX_SECTION_HEADING_CHARS = 100;
    const MAX_VALIDATION_ERRORS = 8;
    const MAX_ERROR_TEXT_CHARS = 200;
    const cleanText = (raw, max) => typeof raw === "string" ? raw.replace(/\s+/g, " ").trim().slice(0, max) : "";
    const UI_STATUS_NOISE_RE = /(?:no\s+locations?\s+found.*|try\s+entering\s+a\s+different\s+location|no\s+options|loading\.{0,3}|searching\.{0,3})$/i;
    const cleanQuestionNoise = (raw, max) => {
        const collapsed = cleanText(raw, max * 2);
        if (!collapsed)
            return "";
        return collapsed.replace(UI_STATUS_NOISE_RE, "").replace(/\s+/g, " ").trim().slice(0, max);
    };
    /**
     * Terlihat: tidak `type=hidden`, `hidden`, `inert`, `display:none`, atau `visibility:hidden`, dan tidak berada di dalam
     * leluhur yang tersembunyi (`hidden`, `aria-hidden="true"`, `inert`, `display:none`). Naik menembus batas shadow root.
     */
    /** Apakah elemen tampak terlihat (memperhatikan `hidden`, `inert`, `aria-hidden`, dan `display`/`visibility`). */
    function isElementVisible(el) {
        const htmlEl = el;
        const typeAttr = (el.getAttribute?.("type") ?? "").toLowerCase();
        if (el.type === "hidden" ||
            (el.tagName?.toLowerCase() === "input" && typeAttr === "hidden") ||
            htmlEl.hidden ||
            el.hasAttribute?.("inert") ||
            el.getAttribute?.("aria-hidden") === "true") {
            return false;
        }
        if (typeof getComputedStyle === "function") {
            try {
                const style = getComputedStyle(el);
                if (style.display === "none" || style.visibility === "hidden")
                    return false;
            }
            catch {
                // Lingkungan tes non-browser mengabaikan getComputedStyle
            }
        }
        return !hiddenByAncestor(el);
    }
    /** Teks yang dirujuk `aria-labelledby` (id dicari di akar elemen, yaitu dokumen atau shadow root yang sama). */
    function labelledByText(doc, el) {
        const labelledBy = el.getAttribute("aria-labelledby");
        if (!labelledBy)
            return "";
        return labelledBy
            .split(/\s+/)
            .map((id) => cleanText(elementByIdNear(el, doc, id)?.textContent, 150))
            .filter(Boolean)
            .join(" ")
            .slice(0, 300);
    }
    function labelForElement(doc, el) {
        const ariaLabel = el.getAttribute("aria-label");
        if (ariaLabel)
            return cleanQuestionNoise(ariaLabel, 300);
        const labelledText = labelledByText(doc, el);
        if (labelledText)
            return cleanQuestionNoise(labelledText, 300);
        const id = el.getAttribute("id");
        const scope = scopeOf(el, doc);
        if (id && typeof CSS !== "undefined" && typeof CSS.escape === "function") {
            const explicit = scope.querySelector(`label[for="${CSS.escape(id)}"]`);
            if (explicit?.textContent)
                return cleanQuestionNoise(explicit.textContent, 300);
        }
        else if (id) {
            const labels = Array.from(scope.querySelectorAll("label"));
            const match = labels.find((l) => l.getAttribute("for") === id);
            if (match?.textContent)
                return cleanQuestionNoise(match.textContent, 300);
        }
        const wrappingLabel = el.closest?.("label");
        if (wrappingLabel?.textContent)
            return cleanQuestionNoise(wrappingLabel.textContent, 300);
        return "";
    }
    /** Elemen yang teksnya bisa menjadi judul pertanyaan bila situs tidak memakai `<label>` (mis. Lever `div.text`). */
    const QUESTION_CONTEXT_SELECTOR = "label, legend, h1, h2, h3, h4, h5, h6, p, span, strong, div";
    /** Pesan galat kolom yang menuntut isian ("Silakan tambahkan ...", "wajib diisi", "is required"). */
    const REQUIRED_ERROR_RE = /silakan (?:tambahkan|isi|pilih|masukkan|lengkapi)|wajib|harus diisi|tidak boleh kosong|\brequired\b|please (?:add|enter|select|provide|fill|choose)|can['’]?t be blank|cannot be (?:blank|empty)/i;
    /** Penanda wajib di akhir judul pertanyaan ("✱", "*", "(required)") tidak ikut menjadi teks pertanyaan. */
    const stripRequiredMark = (text) => text.replace(/\s*(?:[*✱]+|\((?:required|wajib)\))\s*$/i, "").trim();
    /** Judul yang pasti: label dan legend, termasuk wadah judul ant-design (`ant-form-item-label`). Dicoba lebih dulu di tiap tingkat. */
    const PREFERRED_LABEL_SELECTOR = "label, legend, [class*=form-item-label]";
    /**
     * Teks yang bukan pertanyaan: nilai terpilih dan placeholder widget pilihan (ant-select `selection-item`, react-select
     * `singleValue`). Tanpa ini nilai terpilih ("IDN") terbaca sebagai judul kolom.
     */
    const NON_QUESTION_SELECTOR = "[class*=selection-item], [class*=singleValue], [class*=single-value], [class*=placeholder], [class*=selection-placeholder], [role=alert], [role=status], [aria-live], [class*=loading], [class*=spinner], [class*=no-options]";
    /** Naik paling banyak 8 tingkat untuk label pasti (wadah form-item ant-design jauh di atas input), 5 tingkat untuk teks umum. */
    const MAX_PREFERRED_LABEL_DEPTH = 8;
    const MAX_GENERIC_LABEL_DEPTH = 5;
    /** Simpul yang berisi, berada di dalam, atau adalah teks nilai terpilih, status/loading, atau placeholder. */
    function isNonQuestionNode(node) {
        if (elementMatches(node, NON_QUESTION_SELECTOR))
            return true;
        try {
            if (node.closest?.(NON_QUESTION_SELECTOR))
                return true;
        }
        catch {
            // Selektor tidak didukung lingkungan tes minimal
        }
        return false;
    }
    /**
     * Judul pertanyaan dari teks wadah terdekat, untuk kolom tanpa `<label>` atau `aria-label`.
     * Mengutamakan kandidat terdekat sebelum kolom isian, sambil membuang simpul status/loading/nilai terpilih
     * dan menghentikan pencarian sebelum wadah yang memuat kolom isian lain.
     */
    function contextQuestionLabel(el, ignoreInside) {
        const placeholder = cleanText(el.getAttribute("placeholder"), 300).toLowerCase();
        const accept = (candidate) => {
            if (candidate === el || candidate.contains?.(el) || el.contains?.(candidate) || isNonQuestionNode(candidate))
                return "";
            if (candidate.querySelector?.("input, textarea, select, [role='combobox']"))
                return "";
            const text = stripRequiredMark(cleanQuestionNoise(candidate.textContent, 300));
            // Teks tanpa huruf (penghitung "0/500", tanda "*") bukan pertanyaan.
            if (text.length < 2 || !/\p{L}/u.test(text) || text.toLowerCase() === placeholder)
                return "";
            return text;
        };
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < MAX_PREFERRED_LABEL_DEPTH; depth++, node = parentOrHost(node)) {
            if (holdsOtherAnswerControl(node, el, ignoreInside))
                break;
            let bestPreferred = "";
            for (const candidate of Array.from(node.querySelectorAll(PREFERRED_LABEL_SELECTOR))) {
                const text = accept(candidate);
                if (text)
                    bestPreferred = text;
            }
            if (bestPreferred)
                return bestPreferred;
            if (depth >= MAX_GENERIC_LABEL_DEPTH)
                continue;
            let bestGeneric = "";
            for (const candidate of Array.from(node.querySelectorAll(QUESTION_CONTEXT_SELECTOR))) {
                const text = accept(candidate);
                if (text)
                    bestGeneric = text;
            }
            if (bestGeneric)
                return bestGeneric;
        }
        return "";
    }
    /**
     * Fallback kedekatan posisi visual (`getBoundingClientRect`): saat struktur grid/framework memisahkan `<input>` dari
     * teks pertanyaan di atas atau di kirinya, cari teks terdekat secara visual yang bukan `placeholder`.
     */
    function visualLabelFromBox(doc, el, placeholder) {
        try {
            const rect = el.getBoundingClientRect?.();
            if (!rect || (rect.width === 0 && rect.height === 0))
                return "";
            const ph = placeholder.trim().toLowerCase();
            const root = doc.body ?? doc.documentElement;
            if (!root)
                return "";
            let best = "";
            let bestScore = Infinity;
            for (const cand of deepQueryAll(root, "label, legend, p, span, strong, h1, h2, h3, h4, h5, h6, div")) {
                if (cand === el || cand.contains?.(el) || el.contains?.(cand) || isNonQuestionNode(cand))
                    continue;
                if (cand.querySelector?.("input, textarea, select, [role='combobox'], button"))
                    continue;
                if (!isElementVisible(cand))
                    continue;
                const cr = cand.getBoundingClientRect?.();
                if (!cr || cr.width === 0 || cr.height === 0)
                    continue;
                const text = stripRequiredMark(cleanQuestionNoise(cand.textContent, 200));
                if (text.length < 2 || !/\p{L}/u.test(text) || (ph && text.toLowerCase() === ph))
                    continue;
                const dy = rect.top - cr.bottom;
                const dx = rect.left - cr.left;
                const above = dy >= -12 && dy <= 110 && cr.left <= rect.right + 40 && cr.right >= rect.left - 80;
                const leftSide = cr.right <= rect.left + 8 && rect.left - cr.right <= 280 && Math.abs(cr.top - rect.top) <= 24;
                if (!above && !leftSide)
                    continue;
                const score = above ? dy + Math.abs(dx) * 0.25 : (rect.left - cr.right) + Math.abs(cr.top - rect.top) * 2 + 40;
                if (score < bestScore) {
                    bestScore = score;
                    best = text;
                }
            }
            return best;
        }
        catch {
            return "";
        }
    }
    /**
     * Label pertanyaan sebuah kolom: label resmi lebih dulu, lalu teks wadah, lalu kedekatan visual (`getBoundingClientRect`).
     * Label resmi yang sama dengan placeholder dianggap lemah, karena beberapa situs menyalin placeholder ke `aria-label`.
     */
    function questionLabelFor(doc, el) {
        const explicit = labelForElement(doc, el);
        const placeholder = cleanText(el.getAttribute("placeholder"), 300);
        // Label tanpa huruf ("*") juga lemah: `aria-labelledby` komponen web (SmartRecruiters, kotak persetujuan) bisa menunjuk
        // label yang isinya hanya penanda wajib, sedangkan teks persetujuannya ada di wadah di atas input.
        const weak = !explicit || !/\p{L}/u.test(explicit) || (placeholder !== "" && explicit.toLowerCase() === placeholder.toLowerCase());
        const own = weak ? contextQuestionLabel(el) || visualLabelFromBox(doc, el, placeholder) || explicit : explicit;
        return withGroupHeading(el, cleanQuestionNoise(own, 300) || own);
    }
    /**
     * Label bagian tanggal atau waktu yang berdiri sendiri ("Bulan", "Tahun", "Month") tidak bisa dijawab tanpa judul
     * grupnya. JobStreet (uji 25 November 2026): "Mulai" dan "Berakhir" masing-masing punya select Bulan dan Tahun, jadi
     * tanpa judul grup keduanya tampil sebagai satu pertanyaan Bulan dan satu Tahun.
     */
    const GENERIC_PART_LABEL_RE = /^(?:bulan|tahun|hari|tanggal|tgl|jam|menit|month|year|day|date|hour|minute|mm|dd|yy|yyyy|hh)$/i;
    function isGenericPartLabel(text) {
        const core = stripRequiredMark(text).replace(/\s*\((?:opsional|optional)\)\s*$/i, "").trim();
        return GENERIC_PART_LABEL_RE.test(core);
    }
    const GROUP_HEADING_SELECTOR = "legend, label, h1, h2, h3, h4, h5, h6, strong, p, span, div";
    const MAX_GROUP_HEADING_DEPTH = 6;
    /** Judul grup: teks terdekat sebelum kontrol, di wadah terdekat yang memuat lebih dari satu kolom isian. */
    function groupHeadingFor(el, own) {
        const ownLower = own.toLowerCase();
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < MAX_GROUP_HEADING_DEPTH; depth++, node = parentOrHost(node)) {
            if (!holdsOtherAnswerControl(node, el))
                continue;
            let best = "";
            // querySelectorAll mengikuti urutan dokumen: berhenti di kontrol itu, jadi hanya teks sebelum kontrol yang dipakai.
            for (const candidate of Array.from(node.querySelectorAll(`${GROUP_HEADING_SELECTOR}, input, select, textarea`))) {
                if (candidate === el)
                    break;
                if (/^(?:input|select|textarea)$/i.test(candidate.tagName))
                    continue;
                if (candidate.contains(el) || isNonQuestionNode(candidate))
                    continue;
                if (candidate.querySelector("input, select, textarea"))
                    continue;
                const text = stripRequiredMark(cleanText(candidate.textContent, 120));
                if (text.length < 2 || text.length > 80 || !/\p{L}/u.test(text))
                    continue;
                if (text.toLowerCase() === ownLower || isGenericPartLabel(text))
                    continue;
                best = text; // kandidat terakhir sebelum kontrol = yang paling dekat
            }
            if (best)
                return best;
        }
        return "";
    }
    function withGroupHeading(el, own) {
        if (!own || !isGenericPartLabel(own))
            return own;
        const heading = groupHeadingFor(el, own);
        return heading ? `${heading}: ${own}` : own;
    }
    function groupLabelForRadio(doc, checkEl, inputType = "radio") {
        const group = checkEl.closest?.('fieldset, [role="radiogroup"], [role="group"]');
        if (group) {
            const legend = group.querySelector("legend, [data-question-title], .question-label, h1, h2, h3, h4, p");
            if (legend?.textContent)
                return cleanText(legend.textContent, 300);
            const aria = group.getAttribute("aria-label");
            if (aria)
                return cleanText(aria, 300);
        }
        const byName = checkEl.getAttribute("name");
        return byName ? radioTitleFromAncestors(doc, checkEl, byName, inputType) : "";
    }
    /** Naik paling banyak segini tingkat dari radio (label opsi, wadah opsi, wadah pertanyaan, ...) mencari judul pertanyaan. */
    const MAX_RADIO_TITLE_CLIMB = 6;
    const RADIO_TITLE_SELECTOR = "label, legend, p, span, strong, h1, h2, h3, h4, h5, h6, [data-question-title], .question-label, .application-label";
    /**
     * Judul pertanyaan grup radio tanpa fieldset/radiogroup (Glints: `QuestionContainer > p` tiga tingkat di atas radio,
     * dengan wadah opsi di tengahnya; Lever: wadah `<ul>/<div>` dengan judul pertanyaan di leluhur). Naik tingkat demi
     * tingkat mulai dari wadah opsi dan berhenti sebelum wadah yang memuat kolom isian lain.
     */
    function radioTitleFromAncestors(doc, checkEl, name, inputType = "radio") {
        const groupRadios = Array.from(scopeOf(checkEl, doc).querySelectorAll(`input[type="${inputType}"]`)).filter((r) => r.getAttribute("name") === name);
        if (!groupRadios.includes(checkEl))
            groupRadios.push(checkEl);
        const optionTexts = new Set(groupRadios.map((r) => labelForElement(doc, r).toLowerCase()).filter(Boolean));
        const optionNodes = [];
        for (const r of groupRadios) {
            const node = r.closest?.("label") ?? r.parentElement;
            if (node)
                optionNodes.push(node);
        }
        const holdsOtherControl = (container) => Array.from(container.querySelectorAll("input, textarea, select")).some((c) => {
            if (groupRadios.includes(c))
                return false;
            return !(c.tagName.toLowerCase() === "input" && NON_ANSWER_INPUT_TYPES.has((c.getAttribute("type") ?? "text").toLowerCase()));
        });
        let ancestor = checkEl.parentElement?.parentElement ?? null;
        for (let level = 2; ancestor && level <= MAX_RADIO_TITLE_CLIMB; level++, ancestor = ancestor.parentElement) {
            if (holdsOtherControl(ancestor))
                break;
            for (const candidate of Array.from(ancestor.querySelectorAll(RADIO_TITLE_SELECTOR))) {
                if (optionNodes.some((n) => n.contains(candidate) || candidate.contains(n)))
                    continue;
                const text = cleanText(candidate.textContent, 300);
                if (!/\p{L}/u.test(text) || optionTexts.has(text.toLowerCase()))
                    continue;
                return text;
            }
        }
        return "";
    }
    /** Input file sering disembunyikan di balik tombol kustom (Lever, Greenhouse). Tetap diekstrak, terlihat atau tidak. */
    const isFileInput$1 = (el) => el.tagName.toLowerCase() === "input" && (el.getAttribute("type") ?? "").toLowerCase() === "file";
    /** Teks tombol bawaan yang tidak menjelaskan isi berkas ("Attach", "Upload"), jadi perlu teks sekitar. */
    const GENERIC_FILE_LABEL_RE = /^(attach|upload|choose|browse|select|add|drag|drop|pilih|unggah|lampirkan|tambah)\b/i;
    const NON_ANSWER_INPUT_TYPES = new Set(["hidden", "file", "submit", "button", "image", "reset"]);
    /** Wadah memuat kolom isian lain: teks di dalamnya bisa milik kolom lain, jadi bukan label input file ini. */
    function holdsOtherAnswerControl(container, fileEl, ignoreInside) {
        return Array.from(container.querySelectorAll("input, textarea, select")).some((c) => {
            if (c === fileEl || ignoreInside?.contains?.(c))
                return false;
            if (c.tagName.toLowerCase() === "input")
                return !NON_ANSWER_INPUT_TYPES.has((c.getAttribute("type") ?? "text").toLowerCase());
            return true;
        });
    }
    const FILE_CONTEXT_SELECTOR = "label, legend, button, a, span, p, strong, h1, h2, h3, h4, h5, h6";
    /**
     * Label input file dari teks terdekat: tombol, label, atau judul di wadah yang sama (naik paling banyak 3 tingkat,
     * berhenti sebelum wadah yang memuat kolom isian lain). Maksimal dua potong teks pertama, mis. "Attach Resume/CV".
     */
    function fileContextLabel(fileEl) {
        const texts = [];
        let node = parentOrHost(fileEl);
        for (let depth = 0; node && depth < 3 && texts.length < 2; depth++, node = parentOrHost(node)) {
            if (holdsOtherAnswerControl(node, fileEl))
                break;
            for (const candidate of Array.from(node.querySelectorAll(FILE_CONTEXT_SELECTOR))) {
                if (candidate === fileEl || candidate.contains?.(fileEl) || fileEl.contains?.(candidate))
                    continue;
                const text = cleanText(candidate.textContent, 80);
                if (text.length < 2 || texts.includes(text))
                    continue;
                texts.push(text);
                if (texts.length >= 2)
                    break;
            }
        }
        return cleanText(texts.join(" "), 160);
    }
    function labelForFileInput(doc, el) {
        const explicit = labelForElement(doc, el);
        if (explicit && !GENERIC_FILE_LABEL_RE.test(explicit))
            return explicit;
        return fileContextLabel(el) || explicit;
    }
    /**
     * Id ini sudah dipakai elemen lain di dokumen, termasuk di dalam shadow root terbuka. `document.querySelector` tidak
     * menembus shadow root, jadi di komponen web (SmartRecruiters) dua elemen bisa sama-sama bertanda `applify_c_10`:
     * aksi untuk "LinkedIn" mengenai "Institution", dan kolom baru tidak pernah ditanyakan (id-nya dianggap sudah ditangani).
     */
    function cidTaken(el, cid) {
        try {
            const doc = el.ownerDocument;
            if (!doc)
                return false;
            return deepQueryAll(doc, `[data-applify-cid="${cid}"]`, 2).some((other) => other !== el);
        }
        catch {
            return false;
        }
    }
    /**
     * `fresh` (bila ada) menampung elemen yang baru diberi tanda, supaya tandanya bisa dicabut bila kontrolnya terpangkas.
     * `claimed` (satu pembacaan): id yang sudah dipegang kontrol lain di pembacaan ini. Elemen dengan tanda lama yang ternyata
     * sudah dipegang elemen lain (sisa pembacaan lama yang bertabrakan) diberi id baru, jadi id selalu unik dalam satu pembacaan.
     */
    function ensureControlId(el, index, prefix, fresh, claimed) {
        const existing = el.getAttribute("data-applify-cid");
        if (existing && !claimed?.has(existing)) {
            claimed?.add(existing);
            return existing;
        }
        // Uji live JobStreet 26 November 2026: kontrol yang sudah bertanda dari pembacaan sebelumnya mempertahankan tandanya,
        // sedangkan kontrol baru (sakelar yang baru terbaca) diberi nomor dari indeks urutan. Keduanya bisa mendapat
        // `applify_c_0`, lalu aksi untuk "Posisi pekerjaan" mengenai sakelar. Nomor yang sudah dipakai di dokumen dilewati.
        let generated = `${prefix}_${index}`;
        for (let k = 1; (cidTaken(el, generated) || claimed?.has(generated)) && k < 1000; k++)
            generated = `${prefix}_${index}_${k}`;
        el.setAttribute("data-applify-cid", generated);
        claimed?.add(generated);
        fresh?.push(el);
        return generated;
    }
    /**
     * ID grup radio (`data-applify-rg`). Dulu selalu `rg_${candidates.length}` dan menimpa tanda lama di setiap pembacaan:
     * sesudah kolom bersyarat muncul di atas grup, grup yang sama berganti ID, dan ID lama bisa dipakai grup lain. Kini
     * tanda lama dipertahankan selama tidak dipakai elemen di luar grup ini (grup lain, atau sisa grup yang tersembunyi);
     * bila terpakai atau belum ada, nomor baru dicari yang masih bebas di dokumen. `index` hanya nomor awal.
     */
    function ensureGroupId(doc, members, index) {
        const inGroup = new Set(members);
        const taken = (rg) => {
            try {
                return findAllByAttr(doc, "data-applify-rg", rg).some((e) => !inGroup.has(e));
            }
            catch {
                return false;
            }
        };
        for (const m of members) {
            const existing = m.getAttribute("data-applify-rg");
            if (existing && !taken(existing))
                return existing;
        }
        let generated = `rg_${index}`;
        for (let k = 1; taken(generated) && k < 1000; k++)
            generated = `rg_${index}_${k}`;
        return generated;
    }
    /**
     * Teks tombol kirim di portal Indonesia: "Lamar", "Lamar Sekarang", "Lamaran Cepat" (JobStreet), "Kirim Lamaran".
     * `\blamar\b` tidak cocok dengan "lamaran" (huruf berikutnya bukan batas kata), jadi bentuk "lamaran cepat" ditulis tersendiri.
     */
    const INPUT_SUBMIT_RE = /\b(submit|apply|kirim|send|lodge|lamar sekarang|lamaran cepat|kirim lamaran|lamar)\b/;
    const BUTTON_SUBMIT_RE = /\b(submit application|submit|apply now|kirim|lamar sekarang|lamaran cepat|kirim lamaran|lamar)\b/;
    /** Tombol kirim akhir yang tegas; tidak pernah boleh diklik sebagai pembuka formulir atau tombol Lanjut. */
    const UNAMBIGUOUS_FINAL_SUBMIT_RE = /\b(submit application|submit|kirim lamaran|send application|lodge|complete application|confirm and apply|kirim)\b/i;
    /** Tombol pembuka formulir lamaran di halaman detail lowongan sebelum form terbuka. */
    const OPENING_CTA_RE = /\b(lamar sekarang|lamaran cepat|lamar|easy apply|apply now|apply)\b/i;
    /** Tombol langkah berikutnya di formulir multi-langkah. */
    const NEXT_STEP_RE = /^(?:lanjut|lanjutkan|berikutnya|selanjutnya|tahap berikutnya|next|next step|continue|save\s*(?:&|and)\s*continue|simpan\s*(?:&|dan)\s*lanjut(?:kan)?|step\s*\d+)$|\b(?:lanjutkan|lanjut|berikutnya|selanjutnya|next step|continue|save\s*(?:&|and)\s*continue|simpan\s*(?:&|dan)\s*lanjut)\b/i;
    /** CTA yang mengalihkan ke login SSO / app / aksi non-progres dan tidak boleh diklik. */
    const EXCLUDE_CTA_RE = /\b(continue with|lanjutkan dengan|sign in|log in|login|masuk|register|daftar|oauth|google|linkedin|apple|facebook|github|chat di aplikasi|di aplikasi|bagikan|share|bookmark|laporkan|report|batal|cancel|kembali|back|previous|sebelumnya|tutup|close|reset|hapus|cara melamar|lamaran saya)\b/i;
    const CAPTCHA_IFRAME_SELECTOR = 'iframe[src*="challenges.cloudflare.com"], iframe[src*="hcaptcha.com"], iframe[src*="recaptcha"], [class*="cf-turnstile"], [class*="h-captcha"], [class*="g-recaptcha"]:not(.g-recaptcha-response), [data-sitekey][class*="turnstile"], input[name="cf-turnstile-response"]';
    function isTurnstileCaptcha(el) {
        const src = (el.getAttribute("src") ?? "").toLowerCase();
        const title = (el.getAttribute("title") ?? "").toLowerCase();
        const cls = (el.getAttribute("class") ?? "").toLowerCase();
        const name = (el.getAttribute("name") ?? "").toLowerCase();
        return (src.includes("challenges.cloudflare.com") ||
            src.includes("turnstile") ||
            title.includes("turnstile") ||
            title.includes("cloudflare") ||
            cls.includes("cf-turnstile") ||
            name === "cf-turnstile-response");
    }
    /**
     * Hanya menganggap CAPTCHA sebagai penghalang aktif bila memang tantangan aktif (Turnstile) atau widget/popup
     * reCAPTCHA/hCaptcha yang benar-benar terlihat. Lencana `reCAPTCHA Enterprise size=invisible` (Ashby) dan kontainer
     * `h-captcha` yang tersembunyi sebelum challenge muncul (Lever) tidak memblokir pengisian formulir.
     */
    function isActiveCaptchaElement(el) {
        if (isTurnstileCaptcha(el))
            return true;
        const cls = (el.getAttribute("class") ?? "").toLowerCase();
        if (cls.split(/\s+/).includes("g-recaptcha-response"))
            return false;
        if (!isElementVisible(el))
            return false;
        const src = (el.getAttribute("src") ?? "").toLowerCase();
        if (src.includes("size=invisible") || (el.getAttribute("data-size") ?? "").toLowerCase() === "invisible")
            return false;
        if (typeof el.closest === "function" && el.closest(".grecaptcha-badge")) {
            return false;
        }
        const rect = typeof el.getBoundingClientRect === "function" ? el.getBoundingClientRect() : null;
        if (rect && (rect.width === 0 || rect.height === 0))
            return false;
        return true;
    }
    function isDisabledControl(el) {
        return el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true";
    }
    function actionableButtonText(el) {
        return cleanText(el.textContent || el.getAttribute("value") || el.getAttribute("aria-label"), 120).toLowerCase();
    }
    function isActionableButton(el) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") ?? "").toLowerCase();
        const role = (el.getAttribute("role") ?? "").toLowerCase();
        if (tag === "input")
            return type === "submit" || type === "button";
        if (tag === "button")
            return type !== "reset";
        if (tag === "a")
            return role === "button" || !insideSearchLandmark(el);
        return role === "button";
    }
    /** Tombol Lanjut/Next yang terlihat, tidak peduli sedang nonaktif. Tombol kirim akhir, SSO, dan Kembali tidak pernah lolos. */
    function looksLikeNextStepButton(el) {
        if (!isActionableButton(el) || !isElementVisible(el))
            return false;
        const text = actionableButtonText(el);
        if (!text || EXCLUDE_CTA_RE.test(text) || UNAMBIGUOUS_FINAL_SUBMIT_RE.test(text))
            return false;
        return NEXT_STEP_RE.test(text);
    }
    function isNextStepButton(el) {
        return looksLikeNextStepButton(el) && !isDisabledControl(el);
    }
    /**
     * Tombol yang mengirim sebuah <form> bila diklik: input submit/image, button type=submit, atau button tanpa type di
     * dalam <form> (bawaan HTML = submit). Di portal "lamar satu klik" tombol pembuka bisa sekaligus tombol kirim,
     * jadi tombol seperti ini tidak pernah diklik sebagai pembuka formulir. Pengguna tetap bisa mengkliknya sendiri.
     */
    function submitsAForm(el) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") ?? "").toLowerCase();
        if (tag === "input")
            return type === "submit" || type === "image";
        if (tag !== "button")
            return false;
        if (type === "submit")
            return true;
        return type === "" && Boolean(el.closest?.("form"));
    }
    /**
     * Alasan sebuah elemen TIDAK boleh diklik oleh `humanClick`, atau null bila aman. Lapisan pengaman kedua di
     * atas penyaring tiap jalur (`isOpeningApplyButton`, `isNextStepButton`): tombol kirim tidak pernah lolos.
     *
     * - `final_submit_text`: teks tombol cocok dengan kata kirim akhir ("Submit", "Kirim Lamaran", dst).
     * - `applify_submit_control`: kontrol yang ditandai ekstensi sebagai tombol kirim (`applify_sub_*`).
     * - `submits_form`: input submit/image atau tombol yang mengirim `<form>`. Pengecualian: tombol Lanjut/Next yang lolos
     *   `isNextStepButton`, karena formulir multi-langkah memang sering memakai `type=submit` untuk tombol Lanjut.
     */
    function clickGuardReason(el) {
        if (isActionableButton(el) && UNAMBIGUOUS_FINAL_SUBMIT_RE.test(actionableButtonText(el)))
            return "final_submit_text";
        // EXTRACT_FORM menandai tombol pembuka di halaman tanpa form ("Lamar Sekarang") sebagai applify_sub_*. Tanda itu
        // tidak menolak tombol yang lolos `isOpeningApplyButton`, yang sudah menolak teks kirim akhir, teks Lanjut, dan tombol
        // yang mengirim form. Tombol Lanjut bertanda tetap ditolak, sama dengan `clickNextStepButton`.
        if ((el.getAttribute("data-applify-cid") ?? "").startsWith("applify_sub_") && !isOpeningApplyButton(el)) {
            return "applify_submit_control";
        }
        if (submitsAForm(el) && !isNextStepButton(el))
            return "submits_form";
        return null;
    }
    function isOpeningApplyButton(el) {
        if (!isActionableButton(el) || !isElementVisible(el) || isDisabledControl(el))
            return false;
        if (insideSearchLandmark(el) || submitsAForm(el))
            return false;
        const text = actionableButtonText(el);
        if (!text || EXCLUDE_CTA_RE.test(text) || UNAMBIGUOUS_FINAL_SUBMIT_RE.test(text) || NEXT_STEP_RE.test(text)) {
            return false;
        }
        return OPENING_CTA_RE.test(text);
    }
    function findOpeningApplyButton(doc) {
        const candidates = deepQueryAll(doc, 'button, [role="button"], input[type="button"], input[type="submit"], a');
        for (const el of candidates) {
            if (isOpeningApplyButton(el))
                return el;
        }
        return null;
    }
    const NEXT_STEP_CANDIDATE_SELECTOR = 'button, [role="button"], input[type="button"], input[type="submit"], a[role="button"]';
    function findNextStepButton(doc) {
        for (const el of deepQueryAll(doc, NEXT_STEP_CANDIDATE_SELECTOR)) {
            if (isNextStepButton(el))
                return el;
        }
        return null;
    }
    /**
     * Tombol Lanjut yang ada tetapi masih nonaktif, mis. Glints menonaktifkan "Selanjutnya" selama CV diunggah. Bukan
     * tombol kirim: teks kirim akhir, SSO, dan Kembali tetap ditolak, sama dengan `isNextStepButton`.
     */
    function findDisabledNextStepButton(doc) {
        for (const el of deepQueryAll(doc, NEXT_STEP_CANDIDATE_SELECTOR)) {
            if (looksLikeNextStepButton(el) && isDisabledControl(el))
                return el;
        }
        return null;
    }
    function detectCaptchaIframe(doc) {
        try {
            if (deepQueryAll(doc, CAPTCHA_IFRAME_SELECTOR).some((el) => isActiveCaptchaElement(el)))
                return true;
        }
        catch {
            // Abaikan selektor invalid di lingkungan tes minimal
        }
        for (const iframe of deepQueryAll(doc, "iframe")) {
            const src = (iframe.getAttribute("src") ?? "").toLowerCase();
            const title = (iframe.getAttribute("title") ?? "").toLowerCase();
            if ((src.includes("challenges.cloudflare.com") ||
                src.includes("turnstile") ||
                title.includes("turnstile") ||
                title.includes("cloudflare") ||
                title.includes("recaptcha") ||
                title.includes("hcaptcha")) &&
                isActiveCaptchaElement(iframe)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Tombol simpan milik sub-formulir bagian ("Simpan jabatan" di editor Riwayat karier JobStreet): menyimpan satu entri
     * riwayat, bukan mengirim lamaran. Bila terpilih sebagai kontrol kirim, "Kirim Sekarang" hanya menyimpan entri dan
     * formulir dianggap lengkap padahal tombol akhirnya belum diklik.
     */
    const SUBFORM_SAVE_RE = /\b(?:simpan|save|perbarui|update|tambah|tambahkan|add)\s+(?:\S+\s+){0,2}?(?:jabatan|posisi|pekerjaan|pengalaman|pendidikan|riwayat|karier|karir|sertifikat|sertifikasi|lisensi|keahlian|bahasa|position|job|role|experience|education|history|career|certificate|certification|license|licence|skill|language)\b/i;
    /** Tombol batal di editor entri. */
    const CANCEL_TEXT_RE = /^(?:batal|batalkan|cancel|discard|buang)\b/i;
    /** Selector isian yang dihitung sebagai bagian formulir saat memeriksa sebuah wadah. */
    const CONTAINER_FILLABLE_SELECTOR = 'input, textarea, select, [role="combobox"], [aria-haspopup="listbox"], [role="checkbox"], [role="switch"], [role="radio"], [contenteditable]';
    function containsFillableField(container) {
        return deepQueryAll(container, CONTAINER_FILLABLE_SELECTOR).some((child) => {
            if (child.hasAttribute("contenteditable") && !isEditableHost(child))
                return false;
            const type = (child.getAttribute("type") ?? "").toLowerCase();
            return !["hidden", "submit", "button", "reset", "image", "password"].includes(type);
        });
    }
    /**
     * Teks tombol untuk dicocokkan dan ditampilkan: `innerText` lebih dulu (menjaga spasi antarblok, "Simpan\njabatan"),
     * lalu `textContent`, `value`, `aria-label`. Spasi berurutan dirapikan jadi satu, huruf asli dipertahankan.
     */
    function buttonLabelText(el) {
        const inner = el.innerText;
        return cleanText((typeof inner === "string" && inner.trim() ? inner : "") || el.textContent || el.getAttribute("value") || el.getAttribute("aria-label"), 120);
    }
    const ENTRY_BUTTON_SELECTOR = 'button, [role="button"], input[type="button"], a[role="button"]';
    /**
     * Elemen berada di bagian situs, bukan isi formulir: `<nav>`, `<header>`/`<footer>` tingkat halaman, atau peran
     * banner/navigation/contentinfo/complementary. Tombol di sini (pemilih bahasa, menu, "Buka App") bukan tombol simpan.
     */
    function insideSiteChrome(el) {
        for (let node = parentOrHost(el), depth = 0; node && depth < MAX_ANCESTOR_WALK; node = parentOrHost(node), depth++) {
            const tag = node.tagName?.toLowerCase();
            const role = (node.getAttribute?.("role") ?? "").toLowerCase();
            if (tag === "nav" || tag === "aside" || ["banner", "navigation", "contentinfo", "complementary"].includes(role))
                return true;
            if (tag !== "header" && tag !== "footer")
                continue;
            // `<header>`/`<footer>` di dalam section, article, main, form, atau dialog hanya kepala/kaki bagian itu.
            let scoped = false;
            for (let up = parentOrHost(node), n = 0; up && n < MAX_ANCESTOR_WALK && !scoped; up = parentOrHost(up), n++) {
                scoped = ["section", "article", "main", "form", "dialog"].includes(up.tagName?.toLowerCase() ?? "");
            }
            if (!scoped)
                return true;
        }
        return false;
    }
    /**
     * Tombol Batal `cancel` milik editor yang memuat `el`, bukan editor lain. Di leluhur `p`, cabang yang memuat Batal
     * (anak langsung `p`) harus sama dengan cabang `elBranch` milik `el`, atau tidak punya isian sendiri. Batal di cabang
     * lain yang punya isian adalah Batal editor tetangga, jadi tidak membuat `el` ikut menjadi tombol simpan.
     */
    function cancelBelongsToEditorOf(cancel, p, elBranch) {
        let branch = cancel;
        for (let depth = 0; branch && depth < MAX_ANCESTOR_WALK; depth++) {
            const up = parentOrHost(branch);
            if (up === p)
                break;
            branch = up;
        }
        if (!branch || parentOrHost(branch) !== p)
            return false;
        return branch === elBranch || !containsFillableField(branch);
    }
    /**
     * Editor entri berulang di dalam formulir yang lebih besar: leluhur terdekat (bukan form, dialog, main, atau body)
     * yang memuat isian DAN tombol Batal/Cancel milik editor yang sama dengan `el` (lihat `cancelBelongsToEditorOf`).
     * Editor seperti ini punya tombol simpan sendiri, sedangkan tombol akhir halaman ada di luarnya. Tombol di header,
     * navigasi, atau bagian lain yang hanya kebetulan satu pembungkus besar dengan editor tidak termasuk.
     */
    function isInRepeatedEntryEditor(el) {
        if (insideSiteChrome(el))
            return false;
        let branch = el;
        let p = parentOrHost(el);
        for (let depth = 0; p && depth < MAX_ANCESTOR_WALK; branch = p, p = parentOrHost(p), depth++) {
            const tag = p.tagName?.toLowerCase();
            const role = (p.getAttribute?.("role") ?? "").toLowerCase();
            if (tag === "body" || tag === "html")
                return false;
            const scope = p;
            const elBranch = branch;
            const hasCancel = deepQueryAll(scope, ENTRY_BUTTON_SELECTOR).some((b) => b !== el && CANCEL_TEXT_RE.test(buttonLabelText(b)) && cancelBelongsToEditorOf(b, scope, elBranch));
            if (!hasCancel || !containsFillableField(p))
                continue;
            // Wadah terkecil dengan isian dan Batal adalah formulir itu sendiri (modal Batal/Simpan): bukan sub-formulir.
            return !(tag === "form" || tag === "dialog" || tag === "main" || role === "dialog" || role === "main");
        }
        return false;
    }
    /** Teks tombol memuat "Simpan/Save + kata benda riwayat" (Simpan jabatan, Save education), bukan tombol kirim tegas. */
    function isExplicitSubformSave(el) {
        if (!isActionableButton(el))
            return false;
        const text = buttonLabelText(el);
        return Boolean(text) && !UNAMBIGUOUS_FINAL_SUBMIT_RE.test(text) && SUBFORM_SAVE_RE.test(text);
    }
    /** Tombol apa pun (selain Batal, Lanjut, dan kirim tegas) di editor entri berulang yang punya tombol Batal/Cancel. */
    function isEditorEntrySave(el) {
        if (!isActionableButton(el))
            return false;
        const text = buttonLabelText(el);
        if (!text || UNAMBIGUOUS_FINAL_SUBMIT_RE.test(text) || CANCEL_TEXT_RE.test(text) || isNextStepButton(el))
            return false;
        return isInRepeatedEntryEditor(el);
    }
    /**
     * Tombol simpan sub-formulir bagian: teks "Simpan/Save + kata benda riwayat" (Simpan jabatan, Save education), atau
     * tombol apa pun di editor entri berulang yang punya tombol Batal/Cancel. Tombol kirim yang tegas ("Kirim Lamaran",
     * "Submit") tidak pernah dianggap tombol simpan sub-formulir.
     */
    function isSubformSaveButton(el) {
        return isExplicitSubformSave(el) || isEditorEntrySave(el);
    }
    /** Tombol menuju halaman peninjauan sebelum kirim ("Review dan kirim", "Tinjau dan kirim"): halaman berikutnya, bukan kirim akhir. */
    const REVIEW_STEP_RE = /^(?:review|tinjau|periksa|cek|lihat)\b.*\b(?:dan|and|&)\s+(?:kirim|submit|send|lamar)\b/i;
    const MAX_HINT_SCAN = 300;
    /** Teks tombol apa adanya (huruf asli, spasi dirapikan), untuk ditampilkan ke pengguna. */
    const buttonDisplayText = buttonLabelText;
    /**
     * Hanya baca: apa yang masih harus dilakukan pengguna di halaman ini sebelum bisa mengirim. Mengembalikan teks tombol
     * simpan sub-formulir yang tampil ("Simpan jabatan" di editor Riwayat karier) dan tombol ke halaman berikutnya
     * ("Lanjut", "Review dan kirim"). Tombol yang teksnya jelas tombol simpan didahulukan; tebakan "tombol di editor
     * ber-Batal" dipakai hanya bila tidak ada yang jelas. Tidak pernah mengklik, memfokuskan, atau mengubah elemen apa pun.
     */
    function detectNextStepHints(doc) {
        const candidates = deepQueryAll(doc, 'button, [role="button"], input[type="button"], input[type="submit"], a[role="button"]').slice(0, MAX_HINT_SCAN);
        let explicitSave = null;
        let nextPage = null;
        for (const el of candidates) {
            if (explicitSave && nextPage)
                break;
            if (!isActionableButton(el) || !isElementVisible(el))
                continue;
            const text = buttonDisplayText(el);
            if (!text)
                continue;
            if (!explicitSave && isExplicitSubformSave(el)) {
                explicitSave = text;
                continue;
            }
            if (!nextPage && (isNextStepButton(el) || REVIEW_STEP_RE.test(text)) && !isDisabledControl(el) && !isSubformSaveButton(el))
                nextPage = text;
        }
        let editorSave = null;
        if (!explicitSave) {
            for (const el of candidates) {
                if (!isActionableButton(el) || !isElementVisible(el) || !isEditorEntrySave(el))
                    continue;
                editorSave = buttonDisplayText(el);
                break;
            }
        }
        return { subformSave: explicitSave ?? editorSave, nextPage };
    }
    function isSubmitLike(el) {
        if (isNextStepButton(el))
            return false;
        if (isSubformSaveButton(el))
            return false;
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") ?? "").toLowerCase();
        const role = (el.getAttribute("role") ?? "").toLowerCase();
        if (tag === "input" && (type === "submit" || type === "button")) {
            const text = `${el.getAttribute("value") ?? ""} ${el.getAttribute("aria-label") ?? ""}`.toLowerCase();
            return INPUT_SUBMIT_RE.test(text);
        }
        if (tag === "button" || role === "button") {
            if (type === "reset")
                return false;
            const text = cleanText(el.textContent || el.getAttribute("aria-label"), 120).toLowerCase();
            return type === "submit" || BUTTON_SUBMIT_RE.test(text);
        }
        return false;
    }
    function isUnambiguousFinalSubmit(el) {
        return UNAMBIGUOUS_FINAL_SUBMIT_RE.test(actionableButtonText(el));
    }
    function hasFormContainerWithFillable(el) {
        let container = el.closest?.('form, [role="dialog"], dialog') ?? null;
        if (!container) {
            for (let p = parentOrHost(el), depth = 0; p && depth < 5; p = parentOrHost(p), depth++) {
                const t = p.tagName?.toLowerCase();
                const r = (p.getAttribute?.("role") ?? "").toLowerCase();
                if (t === "form" || t === "dialog" || r === "dialog") {
                    container = p;
                    break;
                }
            }
        }
        if (!container)
            return false;
        return containsFillableField(container);
    }
    /** Peran ARIA yang boleh dikirim ke backend sebagai `role`. Harus sama dengan `EXT_ROLES` di `extension-planner.ts`. */
    const EXT_ROLES = new Set([
        "checkbox",
        "switch",
        "radio",
        "radiogroup",
        "textbox",
        "searchbox",
        "combobox",
        "listbox",
        "spinbutton",
        "slider",
        "button",
        "group",
    ]);
    /** Peran eksplisit elemen (token pertama atribut `role`, huruf kecil), atau "". */
    const explicitRoleOf = (el) => (el.getAttribute("role") ?? "").trim().toLowerCase().split(/\s+/)[0] ?? "";
    const isNativeFormTag = (el) => ["input", "textarea", "select"].includes(el.tagName.toLowerCase());
    /** Teks isi kotak teks `contenteditable`, tanpa karakter lebar nol yang dipakai editor sebagai penanda kosong. */
    function editableText(el) {
        return String(el.textContent ?? "").replace(/[​‌‍﻿]/g, "");
    }
    /**
     * Kotak teks `contenteditable` yang berdiri sendiri: bukan `<body>`, bukan di dalam kotak `contenteditable` lain
     * (editor kaya memakai banyak simpul bersarang), dan bukan pembungkus yang memuat input lain.
     */
    function isStandaloneEditable(doc, el) {
        if (!isEditableHost(el))
            return false;
        if (el === doc.body || el === doc.documentElement)
            return false;
        let depth = 0;
        for (let n = parentOrHost(el); n && depth < 12; n = parentOrHost(n), depth++) {
            if (n === doc.body || n === doc.documentElement)
                break;
            if (isEditableHost(n))
                return false;
        }
        return !holdsOtherAnswerControl(el, el);
    }
    /** Label pilihan ARIA (radio atau tombol bergantian): `aria-label`, `aria-labelledby`, teks sendiri, lalu `data-value`. */
    function ariaOptionLabel(doc, el) {
        const aria = el.getAttribute("aria-label");
        if (aria)
            return cleanText(aria, 120);
        const labelled = labelledByText(doc, el);
        if (labelled)
            return labelled.slice(0, 120);
        return cleanText(el.textContent, 120) || cleanText(el.getAttribute("data-value") ?? el.getAttribute("value"), 120);
    }
    /** Label kotak centang ARIA: label resmi, lalu teks elemen itu sendiri, lalu teks wadah. */
    function ariaCheckLabel(doc, el) {
        return labelForElement(doc, el) || cleanText(el.textContent, 300) || contextQuestionLabel(el);
    }
    const ariaOn = (el, attr) => el.getAttribute(attr) === "true";
    /** Radio ARIA di dalam `container`: yang terlihat dan bukan `<input>` asli (itu jalur radio biasa). */
    function ariaRadioOptions(container) {
        return deepQueryAll(container, '[role="radio"]').filter((o) => !isNativeFormTag(o) && isElementVisible(o));
    }
    /**
     * Wadah grup untuk satu `role=radio`: `role=radiogroup` terdekat di leluhur. Tanpa itu, `role=group` atau `fieldset`
     * terdekat, dan bila tidak ada, induk langsungnya.
     */
    function ariaRadioContainer(el) {
        let fallback = null;
        let depth = 0;
        for (let n = parentOrHost(el); n && depth < 12; n = parentOrHost(n), depth++) {
            const r = explicitRoleOf(n);
            if (r === "radiogroup")
                return n;
            if (!fallback && (r === "group" || n.tagName.toLowerCase() === "fieldset"))
                fallback = n;
        }
        return fallback ?? el.parentElement ?? el;
    }
    /** Label sebuah grup ARIA: `aria-label`, `aria-labelledby`, `<legend>` fieldset, lalu teks wadah di atasnya. */
    /**
     * Judul kelompok kecil di atas kontrol: `legend` (juga di luar `fieldset`) atau `[role=group]` berlabel. Uji live
     * JobStreet 26 November 2026: pasangan "Bulan"/"Tahun" berada di bawah legend "Mulai" dan "Berakhir"; tanpa judul ini
     * perencana tidak bisa membedakan tanggal mulai dari tanggal berakhir. Hanya kelompok berisi paling banyak 4 kolom.
     */
    function legendGroupLabel(el) {
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < 8; depth++, node = parentOrHost(node)) {
            const tag = node.tagName.toLowerCase();
            if (tag === "form" || tag === "body")
                break;
            if (node.querySelectorAll("input, select, textarea").length > 4)
                break;
            const legend = Array.from(node.children).find((c) => c.tagName.toLowerCase() === "legend" && !c.contains(el));
            const text = cleanText(legend?.textContent ?? "", 120);
            if (text)
                return text;
        }
        return "";
    }
    function ariaGroupLabel(doc, group) {
        const aria = group.getAttribute("aria-label");
        if (aria)
            return cleanText(aria, 300);
        const labelled = labelledByText(doc, group);
        if (labelled)
            return labelled;
        const legend = group.tagName.toLowerCase() === "fieldset" ? group.querySelector("legend") : null;
        if (legend?.textContent)
            return cleanText(legend.textContent, 300);
        return contextQuestionLabel(group, group);
    }
    /** Teks pilihan radio tunggal yang berarti "pakai berkas" (mode unggah CV), bukan jawaban. */
    const FILE_MODE_RE = /file|upload|unggah|pdf|resume|cv/i;
    /** Teks persetujuan (syarat, privasi, setuju). Harus sama dengan `CONSENT_RE` di `extension-planner.ts`. */
    const CONSENT_TEXT_RE = /syarat|ketentuan|kebijakan privasi|terms|privacy|consent|setuju|agree|personal data|data pribadi|data processing|data controller|pemrosesan data|pengolahan data|gdpr/i;
    /** Pilihan yang berarti "pakai profil tersimpan": bukan mode unggah, walau teksnya memuat kata file/profile. */
    const PROFILE_SOURCE_RE = /profil|profile|tersimpan|saved/i;
    /** Teks dibandingkan tanpa huruf besar, aksen, dan tanda baca. */
    const normalizeText = (text) => text
        .normalize("NFKD")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
    /**
     * Radio dengan satu pilihan yang teksnya sama dengan labelnya (atau tanpa label sendiri) hanyalah sakelar mode, mis.
     * "File PDF" di samping unggahan CV di ant-design. Itu bukan pertanyaan: tandai `toggle`. Bila teksnya menyebut
     * file/upload/pdf/resume/cv (dan bukan profil tersimpan), tandai juga `cvSourceUpload` supaya sisi pengisi
     * mengkliknya sebelum memasang berkas. Radio satu pilihan bertuliskan file/upload juga sakelar walau label grupnya lain.
     */
    function radioToggleFlags(options, groupLabel) {
        if (options.length !== 1)
            return {};
        const option = options[0] ?? "";
        // Radio persetujuan tunggal ("Saya setuju") bukan sakelar: hanya pengguna yang boleh memilihnya, jadi tetap pertanyaan.
        if (CONSENT_TEXT_RE.test(option) || CONSENT_TEXT_RE.test(groupLabel))
            return {};
        const label = normalizeText(groupLabel);
        const fileMode = FILE_MODE_RE.test(option) && !PROFILE_SOURCE_RE.test(option);
        if (label !== "" && label !== normalizeText(option) && !fileMode)
            return {};
        return { toggle: true, ...(fileMode ? { cvSourceUpload: true } : {}) };
    }
    /**
     * Radio dan kotak centang asli yang disembunyikan (`display:none`, `hidden`) tetapi diwakili label yang terlihat: pola
     * umum situs lowongan (JobStreet, Dealls) yang menggambar tombol pilihan sendiri. Inputnya tetap jawaban formulir,
     * jadi ikut diekstrak bila labelnya (`label[for]` atau label pembungkus) terlihat. Input `type=hidden` tidak termasuk.
     */
    function visibleLabelForHiddenCheckable(el) {
        if (el.tagName?.toLowerCase() !== "input")
            return null;
        const type = (el.getAttribute("type") ?? "").toLowerCase();
        if (type !== "radio" && type !== "checkbox")
            return null;
        if (el.hasAttribute?.("disabled"))
            return null;
        const doc = el.ownerDocument;
        const id = el.getAttribute("id");
        const scope = el.getRootNode?.() ?? doc;
        let label = null;
        if (id && scope && typeof scope.querySelectorAll === "function") {
            label = Array.from(scope.querySelectorAll("label")).find((l) => l.getAttribute("for") === id) ?? null;
        }
        label = label ?? el.closest?.("label") ?? null;
        if (!label || !isElementVisible(label))
            return null;
        return cleanText(label.textContent, 300) ? label : null;
    }
    const isPresentControl = (el) => isElementVisible(el) || visibleLabelForHiddenCheckable(el) !== null;
    /** Kelompok radio asli yang dikenali dari markup: fieldset, `role=radiogroup`, atau `ant-radio-group`. */
    const NATIVE_RADIO_GROUP_SELECTOR = 'fieldset, [role="radiogroup"], [class*="radio-group"]';
    const visibleNativeRadios = (container) => deepQueryAll(container, 'input[type="radio"]').filter((r) => isPresentControl(r));
    /** Wadah memuat kolom isian selain radio (teks, area teks, select, kotak centang). */
    function holdsNonRadioControl(container) {
        return Array.from(container.querySelectorAll("input, textarea, select")).some((c) => {
            if (c.tagName.toLowerCase() !== "input")
                return true;
            const type = (c.getAttribute("type") ?? "text").toLowerCase();
            return type !== "radio" && !NON_ANSWER_INPUT_TYPES.has(type);
        });
    }
    /**
     * Wadah grup untuk radio asli: fieldset, `role=radiogroup`, atau `ant-radio-group` terdekat; tanpa itu, leluhur terendah
     * yang memuat paling sedikit dua radio dan tidak memuat kolom isian lain (naik paling banyak 8 tingkat, berhenti di
     * `<form>`). Radio tanpa `name` di situs ant-design menjadi satu grup per wadah ini, bukan satu grup per radio.
     */
    function nativeRadioContainer(el) {
        let lowest = null;
        let depth = 0;
        for (let n = parentOrHost(el); n && depth < 8; n = parentOrHost(n), depth++) {
            const tag = n.tagName?.toLowerCase();
            if (tag === "body" || tag === "html" || tag === "form")
                break;
            if (elementMatches(n, NATIVE_RADIO_GROUP_SELECTOR))
                return n;
            if (holdsNonRadioControl(n))
                break;
            if (!lowest && visibleNativeRadios(n).length >= 2)
                lowest = n;
        }
        return lowest;
    }
    const TOGGLE_FIELD_ENTRY_RE = /(?:^|[\s_-])field[-_]?entry|ashby-application-form-field-entry/i;
    /** Penanda wajib visual (tanda bintang di label/span/sup atau simpul atribut/kelas required) di dalam wadah field entry. */
    function hasRequiredFieldIndicator(container) {
        if (container.getAttribute("aria-required") === "true")
            return true;
        for (const node of Array.from(container.querySelectorAll("label, legend, span, sup, abbr, div, input, button"))) {
            if (node.hasAttribute?.("required") || node.getAttribute?.("aria-required") === "true")
                return true;
            const cls = node.getAttribute?.("class") ?? "";
            if (/\brequired\b|is-required|field-required|required-mark|required-star/i.test(cls))
                return true;
            const tag = node.tagName?.toLowerCase();
            if (tag === "label" || tag === "legend" || tag === "span" || tag === "sup" || tag === "abbr") {
                const txt = (node.textContent ?? "").trim();
                if (/[*✱]\s*$|\((?:required|wajib(?:\s+diisi)?)\)\s*$/i.test(txt))
                    return true;
            }
        }
        return false;
    }
    /**
     * Deteksi tanda wajib visual (`*` / `✱` / `(required)` / `(wajib)`) untuk kontrol tunggal apa pun (teks, select,
     * textarea, combobox, file), berhenti sebelum masuk wadah yang memuat kolom isian lain agar `*` tetangga tidak bocor.
     */
    function hasVisualRequiredForControl(el) {
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < 5; depth++, node = parentOrHost(node)) {
            const tag = node.tagName?.toLowerCase();
            if (tag === "form" || tag === "body" || tag === "html")
                break;
            if (holdsOtherAnswerControl(node, el))
                break;
            if (hasRequiredFieldIndicator(node))
                return true;
        }
        return false;
    }
    /** Cari helperText dari `aria-describedby` atau teks deskripsi pendek di wadah tunggal kontrol. */
    function helperTextForControl(doc, el, label, placeholder) {
        const describedBy = el.getAttribute("aria-describedby");
        if (describedBy) {
            const text = describedBy
                .split(/\s+/)
                .map((id) => cleanQuestionNoise(elementByIdNear(el, doc, id)?.textContent, 200))
                .filter((t) => t && t.toLowerCase() !== label.toLowerCase() && t.toLowerCase() !== placeholder.toLowerCase())
                .join(" ")
                .slice(0, 260);
            if (text)
                return text;
        }
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < 4; depth++, node = parentOrHost(node)) {
            if (holdsOtherAnswerControl(node, el))
                break;
            for (const cand of Array.from(node.querySelectorAll("[class*=help], [class*=hint], [class*=desc], small"))) {
                if (cand.contains(el) || isNonQuestionNode(cand))
                    continue;
                const t = cleanQuestionNoise(cand.textContent, 200);
                if (t.length >= 4 && t.toLowerCase() !== label.toLowerCase() && t.toLowerCase() !== placeholder.toLowerCase())
                    return t;
            }
        }
        return "";
    }
    /** Judul bagian terdekat di atas kontrol di dalam `root` (`h1..h4` atau `legend`). */
    function sectionHeadingForControl(el, root) {
        let best = "";
        try {
            for (const node of Array.from(root.querySelectorAll("h1, h2, h3, h4, legend, input, select, textarea, [role='combobox']"))) {
                if (node === el)
                    break;
                if (node.tagName && /^(?:input|select|textarea)$/i.test(node.tagName))
                    continue;
                if (node.getAttribute?.("role") === "combobox")
                    continue;
                if (node.contains?.(el) || isNonQuestionNode(node) || !isElementVisible(node))
                    continue;
                const t = stripRequiredMark(cleanQuestionNoise(node.textContent, 140));
                if (t.length >= 2)
                    best = t;
            }
        }
        catch {
            return "";
        }
        return best;
    }
    /** Apakah `container` hanya memuat tombol bergantian milik satu pertanyaan (plus paling banyak 1 checkbox pendamping tersembunyi). */
    function isSingleToggleFieldEntry(container) {
        const controls = Array.from(container.querySelectorAll("input, select, textarea, [role='combobox'], [contenteditable]")).filter((c) => {
            if (c.tagName.toLowerCase() !== "input")
                return true;
            const t = (c.getAttribute("type") ?? "text").toLowerCase();
            return t !== "hidden" && t !== "submit" && t !== "button" && t !== "reset" && t !== "image";
        });
        if (controls.length === 0)
            return true;
        return (controls.length === 1 &&
            controls[0].tagName.toLowerCase() === "input" &&
            (controls[0].getAttribute("type") ?? "").toLowerCase() === "checkbox");
    }
    /**
     * Wadah bertanda untuk tombol bergantian (`aria-pressed`) yang dipakai sebagai pilihan tunggal: `role=group`,
     * `role=radiogroup`, atau `fieldset` dalam 4 tingkat, DAN punya label. Situs modern (Ashby) juga membungkus
     * tombol `Yes`/`No` `aria-pressed` dalam `.ashby-application-form-field-entry` / `[class*=field-entry]` berlabel
     * tanpa `role=group`. Bilah alat (`role=toolbar`) dan tombol bergantian di luar grup berlabel bukan jawaban formulir.
     */
    function toggleGroupContainer(doc, el) {
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < 4; depth++, node = parentOrHost(node)) {
            const tag = node.tagName.toLowerCase();
            if (tag === "form" || tag === "body" || tag === "html")
                break;
            const r = explicitRoleOf(node);
            if (r === "toolbar")
                return null;
            if (r === "group" || r === "radiogroup" || tag === "fieldset") {
                const label = ariaGroupLabel(doc, node);
                return label ? { container: node, label, required: hasRequiredFieldIndicator(node) } : null;
            }
            const cls = node.getAttribute("class") ?? "";
            if (TOGGLE_FIELD_ENTRY_RE.test(cls) && isSingleToggleFieldEntry(node)) {
                const labelEl = node.querySelector("label, legend");
                const label = labelEl ? stripRequiredMark(cleanText(labelEl.textContent, 300)) : "";
                return label ? { container: node, label, required: hasRequiredFieldIndicator(node) } : null;
            }
        }
        return null;
    }
    /** Tombol bergantian yang terlihat di `container`, selain tombol kirim. */
    function toggleOptions(container) {
        return deepQueryAll(container, "[aria-pressed]").filter((o) => {
            const t = o.tagName.toLowerCase();
            const r = explicitRoleOf(o);
            return (t === "button" || r === "button") && isElementVisible(o) && !isSubmitLike(o);
        });
    }
    /**
     * Keadaan kontrol untuk backend. Hanya yang bermakna: `true`, atau `checked` untuk kotak centang.
     * Combobox (`role=combobox`, ant/rc-select): atribut `readonly` pada input pencarinya hanya berarti "klik untuk membuka
     * daftar", BUKAN kolom hanya-baca, jadi tidak ditandai `readOnly`. Hanya `aria-readonly="true"` yang dihitung.
     */
    function controlState(el, kind, role, isCombobox = false) {
        const state = {};
        if (EXT_ROLES.has(role))
            state.role = role;
        if (isDisabledControl(el) || el.disabled === true)
            state.disabled = true;
        const nativeReadOnly = el.readOnly === true || el.hasAttribute("readonly");
        if ((!isCombobox && nativeReadOnly) || el.getAttribute("aria-readonly") === "true")
            state.readOnly = true;
        const expanded = el.getAttribute("aria-expanded");
        if (expanded === "true" || expanded === "false")
            state.expanded = expanded === "true";
        if (kind === "checkbox")
            state.checked = el.checked === true || ariaOn(el, "aria-checked");
        return state;
    }
    /**
     * Combobox yang menerima ketikan untuk mencari pilihan: input yang bisa diedit dengan `aria-autocomplete=list` (react-select,
     * rc-select terbuka), atau input di dalam `ant-select-show-search`. Input ant-select pencarian yang sedang tertutup
     * berstatus `readonly` (klik untuk membuka), jadi dicari lewat kelas pembungkusnya.
     */
    function isSearchableCombobox$1(el) {
        if (isDisabledControl(el) || el.disabled === true)
            return false;
        const readonlyAttr = el.hasAttribute("readonly") || el.readOnly === true || el.getAttribute("aria-readonly") === "true";
        const autocomplete = (el.getAttribute("aria-autocomplete") ?? "").toLowerCase();
        if (isNativeFormTag(el) && !readonlyAttr && (autocomplete === "list" || autocomplete === "both"))
            return true;
        try {
            return Boolean(el.closest?.('[class*="select-show-search"]'));
        }
        catch {
            return false;
        }
    }
    /** Nilai terpilih yang tampil di combobox ant/react-select (input pencarinya kosong): `selection-item` atau `singleValue`. */
    const SELECTED_VALUE_SELECTOR = "[class*=selection-item], [class*=singleValue], [class*=single-value]";
    function comboboxDisplayValue(el) {
        let node = parentOrHost(el);
        for (let depth = 0; node && depth < 4; depth++, node = parentOrHost(node)) {
            if (holdsOtherAnswerControl(node, el))
                break;
            const hits = Array.from(node.querySelectorAll(SELECTED_VALUE_SELECTOR));
            if (hits.length === 0)
                continue;
            // Hanya yang terluar: `selection-item-content` dan tombol hapus berada di dalam `selection-item`.
            const outer = hits.filter((h) => !hits.some((o) => o !== h && o.contains?.(h)) && isElementVisible(h));
            const text = cleanText(outer
                .map((h) => cleanText(h.textContent, 150))
                .filter(Boolean)
                .join(", "), 300);
            if (text)
                return text;
        }
        return "";
    }
    const MAX_CONSTRAINT_LENGTH = 100_000;
    const MAX_PATTERN_CHARS = 200;
    const INPUT_MODES = new Set(["none", "text", "tel", "url", "email", "numeric", "decimal", "search"]);
    /** Bilangan bulat positif dari atribut panjang (`minlength`, `maxlength`), atau undefined. */
    function lengthAttr(el, name) {
        const raw = (el.getAttribute(name) ?? "").trim();
        if (!/^\d{1,6}$/.test(raw))
            return undefined;
        const n = Number(raw);
        return n > 0 && n <= MAX_CONSTRAINT_LENGTH ? n : undefined;
    }
    /** Batas panjang, pola, dan `inputmode` kolom teks, supaya jawaban perencana mengikutinya. Hanya yang ada yang dikirim. */
    function constraintsOf(el, kind, editable) {
        if ((kind !== "text" && kind !== "textarea") || editable)
            return {};
        const hints = {};
        const minLength = lengthAttr(el, "minlength");
        const maxLength = lengthAttr(el, "maxlength");
        if (minLength !== undefined)
            hints.minLength = minLength;
        if (maxLength !== undefined)
            hints.maxLength = maxLength;
        const pattern = cleanText(el.getAttribute("pattern"), MAX_PATTERN_CHARS);
        if (pattern)
            hints.pattern = pattern;
        const inputMode = (el.getAttribute("inputmode") ?? "").trim().toLowerCase();
        if (INPUT_MODES.has(inputMode))
            hints.inputMode = inputMode;
        return hints;
    }
    /** Batas kandidat sebelum dipangkas ke `MAX_EXTRACTED_CONTROLS`, supaya halaman raksasa tidak membuat ekstraksi lama. */
    const MAX_CANDIDATE_CONTROLS = MAX_EXTRACTED_CONTROLS * 4;
    const FORM_NODE_SELECTOR = 'input, textarea, select, button, [role="button"], [role="combobox"], [aria-haspopup="listbox"], [role="checkbox"], [role="switch"], [role="radio"], [contenteditable]';
    /** Google Forms: dropdown-nya `div[role=listbox]` yang berdiri sendiri (di situs lain `role=listbox` hanya menu milik combobox). */
    const GOOGLE_FORM_NODE_SELECTOR = `${FORM_NODE_SELECTOR}, [role="listbox"]`;
    /**
     * Prioritas saat kontrol melebihi batas: 0 wajib diisi, 1 berkas dan tombol kirim (CV dan tombol kirim tidak boleh
     * terbuang walau input berkasnya tersembunyi), 2 sisanya. Semua kontrol di sini sudah terlihat. Urutan dokumen
     * dipertahankan di dalam tiap tingkat.
     */
    const priorityOf = (c) => (c.required && c.kind !== "submit" ? 0 : c.kind === "file" || c.kind === "submit" ? 1 : 2);
    function ancestorChainForRepeater(el) {
        const chain = [];
        let depth = 0;
        for (let n = parentOrHost(el); n && depth < MAX_ANCESTOR_WALK; n = parentOrHost(n), depth++) {
            const tag = n.tagName?.toLowerCase() ?? "";
            if (tag === "html")
                break;
            chain.push(n);
            if (tag === "body")
                break;
        }
        return chain;
    }
    function assignRepeaterIndices(items) {
        const byKey = new Map();
        const blockRank = new Map();
        for (const item of items) {
            const c = item.control;
            if (c.kind === "submit" || c.kind === "file" || c.kind === "checkbox" || c.repeaterIndex !== undefined)
                continue;
            const rawLabel = c.label.trim().toLowerCase();
            if (!rawLabel || rawLabel === "kolom wajib")
                continue;
            const primaryEl = item.tagged[0];
            if (!primaryEl)
                continue;
            const normSection = (c.sectionHeading ?? "").trim().toLowerCase().replace(/[\s#-]*\d+$/, "").trim();
            const key = `${normSection}::${rawLabel}`;
            const list = byKey.get(key) ?? [];
            list.push({ candidate: item, el: primaryEl, chain: ancestorChainForRepeater(primaryEl) });
            byKey.set(key, list);
        }
        for (const group of byKey.values()) {
            if (group.length < 2)
                continue;
            let lca = null;
            for (const candidateAncestor of group[0].chain) {
                if (group.slice(1).every((g) => g.chain.includes(candidateAncestor))) {
                    lca = candidateAncestor;
                    break;
                }
            }
            if (!lca)
                continue;
            const blocks = [];
            let valid = true;
            for (const g of group) {
                const lcaIdx = g.chain.indexOf(lca);
                if (lcaIdx <= 0) {
                    valid = false;
                    break;
                }
                const block = g.chain[lcaIdx - 1];
                const tag = block.tagName?.toLowerCase() ?? "";
                if (block === g.el || tag === "body" || tag === "html" || tag === "form") {
                    valid = false;
                    break;
                }
                blocks.push(block);
            }
            if (!valid || new Set(blocks).size !== group.length)
                continue;
            blocks.forEach((block, idx) => {
                const rank = idx + 1;
                if (!blockRank.has(block))
                    blockRank.set(block, rank);
            });
        }
        if (blockRank.size === 0)
            return;
        for (const item of items) {
            const c = item.control;
            if (c.kind === "submit" || c.kind === "file" || c.repeaterIndex !== undefined)
                continue;
            const primaryEl = item.tagged[0];
            if (!primaryEl)
                continue;
            for (const anc of ancestorChainForRepeater(primaryEl)) {
                const rank = blockRank.get(anc);
                if (rank !== undefined) {
                    c.repeaterIndex = rank;
                    break;
                }
            }
        }
    }
    function capCandidates(candidates) {
        if (candidates.length <= MAX_EXTRACTED_CONTROLS) {
            assignRepeaterIndices(candidates);
            return candidates.map((c) => c.control);
        }
        const ranked = candidates
            .map((c, index) => ({ c, index, tier: priorityOf(c.control) }))
            .sort((a, b) => a.tier - b.tier || a.index - b.index);
        const kept = ranked.slice(0, MAX_EXTRACTED_CONTROLS);
        for (const dropped of ranked.slice(MAX_EXTRACTED_CONTROLS)) {
            for (const el of dropped.c.tagged) {
                el.removeAttribute("data-applify-cid");
                el.removeAttribute("data-applify-rg");
            }
        }
        const sortedKept = kept.sort((a, b) => a.index - b.index).map((k) => k.c);
        assignRepeaterIndices(sortedKept);
        return sortedKept.map((k) => k.control);
    }
    // ---------- Akar formulir ----------
    /** Id atau kelas yang menandai banner cookie, widget obrolan, dan sejenisnya: kontrolnya bukan bagian formulir lamaran. */
    const NOISE_ID_CLASS_RE = /cookie|onetrust|consent-banner|chat|intercom|crisp/i;
    const NOISE_LANDMARK_TAGS = new Set(["header", "footer", "aside"]);
    const NOISE_LANDMARK_ROLES = new Set(["banner", "contentinfo", "complementary"]);
    const NOISE_NAV_ROLES = new Set(["navigation", "search"]);
    /**
     * Simpul yang kontrol di bawahnya bukan formulir lamaran: navigasi dan pencarian, banner cookie, dan widget obrolan.
     * Dengan `landmarks`, header, footer, aside, dan peran banner, contentinfo, complementary ikut.
     */
    function isNoiseNode(node, landmarks) {
        const tag = node.tagName?.toLowerCase() ?? "";
        const role = (node.getAttribute?.("role") ?? "").trim().toLowerCase();
        if (tag === "nav" || NOISE_NAV_ROLES.has(role))
            return true;
        if (NOISE_ID_CLASS_RE.test(`${node.getAttribute?.("id") ?? ""} ${node.getAttribute?.("class") ?? ""}`))
            return true;
        return landmarks && (NOISE_LANDMARK_TAGS.has(tag) || NOISE_LANDMARK_ROLES.has(role));
    }
    /** Ada leluhur noise di atas `el` sampai body (body dan html tidak diperiksa)? */
    function hasNoiseAncestor(el, landmarks) {
        let depth = 0;
        for (let n = parentOrHost(el); n && depth < MAX_ANCESTOR_WALK; n = parentOrHost(n), depth++) {
            const tag = n.tagName?.toLowerCase();
            if (tag === "body" || tag === "html")
                break;
            if (isNoiseNode(n, landmarks))
                return true;
        }
        return false;
    }
    /**
     * Kontrol berada di bawah simpul noise (antara kontrol dan `root`, `root` sendiri tidak diperiksa)? Tombol kirim
     * (`exemptLandmarks`) boleh berada di `<footer>` atau `<header>` modal, jadi hanya navigasi, pencarian, cookie, dan obrolan
     * yang mengecualikannya.
     */
    function isExcludedControl(el, root, exemptLandmarks) {
        let depth = 0;
        for (let n = parentOrHost(el); n && n !== root && depth < MAX_ANCESTOR_WALK; n = parentOrHost(n), depth++) {
            const tag = n.tagName?.toLowerCase();
            if (tag === "body" || tag === "html")
                break;
            if (isNoiseNode(n, !exemptLandmarks))
                return true;
        }
        return false;
    }
    const OVERLAY_ROOT_SELECTOR = '[role="dialog"][aria-modal="true"], dialog[open], .ant-modal-wrap, .ant-drawer-open';
    const documentBody = (doc) => (doc.body ?? doc.documentElement);
    /**
     * Akar tempat kontrol formulir lamaran dicari, supaya kontrol header (pilihan bahasa "IDN"), navigasi, banner cookie, dan
     * widget obrolan tidak terbaca sebagai pertanyaan:
     *   1. dialog modal teratas yang terlihat (`[role=dialog][aria-modal=true]`, `dialog[open]`, `.ant-modal-wrap`,
     *      `.ant-drawer-open`) dan memuat kontrol isian (yang paling akhir di dokumen = paling atas);
     *   2. wadah modal tanpa penanda ARIA (`findModalLikeRoot`: Glints `[data-testid=modal-wrapper]`, kontainer overlay
     *      fixed satu layar) yang memuat kontrol isian;
     *   3. `<form>` dengan kontrol terbanyak (bukan `role=search`), asal memuat minimal separuh kontrol halaman;
     *   4. `<main>` yang memuat minimal separuh kontrol halaman;
     *   5. `<body>`.
     */
    function resolveFormRoot(doc) {
        const body = documentBody(doc);
        let overlay = null;
        for (const candidate of deepQueryAll(doc, OVERLAY_ROOT_SELECTOR)) {
            if (!isElementVisible(candidate) || isNoiseNode(candidate, true) || hasNoiseAncestor(candidate, true))
                continue;
            if (countFillableIn(doc, candidate, true) > 0)
                overlay = candidate;
        }
        if (overlay)
            return { root: overlay, found: true };
        const total = countFillableIn(doc, body, true);
        const modalLike = findModalLikeRoot(doc, total);
        if (modalLike)
            return { root: modalLike, found: true };
        let bestForm = null;
        let bestCount = 0;
        for (const form of deepQueryAll(doc, "form")) {
            if (!isElementVisible(form) || isNoiseNode(form, false) || hasNoiseAncestor(form, false))
                continue;
            const count = countFillableIn(doc, form, true);
            if (count > bestCount) {
                bestForm = form;
                bestCount = count;
            }
        }
        if (bestForm && bestCount * 2 >= total)
            return { root: widenForAdjacentToggles(doc, bestForm, bestCount), found: true };
        for (const main of deepQueryAll(doc, 'main, [role="main"]')) {
            if (!isElementVisible(main) || isNoiseNode(main, false))
                continue;
            const count = countFillableIn(doc, main, true);
            if (count > 0 && count * 2 >= total)
                return { root: main, found: true };
        }
        return { root: body, found: false };
    }
    /** Atribut yang namanya sering memuat kata modal: `data-testid="modal-wrapper"`, kelas CSS-in-JS `ModalStyle__StyledModalWrapper-sc-xx`. */
    const MODAL_MARKER_ATTRS = ["data-testid", "data-test", "data-test-id", "data-cy", "data-qa", "id", "class"];
    const MODAL_MARKER_RE = /modal|dialog|popup|lightbox|drawer|overlay/i;
    /** Kelas penanda keadaan halaman ("modal-open", "has-modal"), bukan wadah modalnya. */
    const MODAL_STATE_RE = /^(?:has|no|with|is)[-_]|modal[-_]?(?:open|opened|active|visible|lock|locked|scroll|backdrop|bg|mask)/i;
    /** Wadah overlay fixed hanya dicari paling banyak sekian tingkat di bawah body (portal modal biasanya anak langsung body). */
    const OVERLAY_TOP_LEVELS = 4;
    const OVERLAY_VIEWPORT_RATIO = 0.9;
    /** Sebuah elemen bertanda dialog tanpa `aria-modal`, atau penamaannya (testid, id, kelas) menyebut modal, dialog, popup, drawer, overlay. */
    function hasModalMarker(el) {
        const role = (el.getAttribute?.("role") ?? "").trim().toLowerCase();
        if (role === "dialog" || role === "alertdialog" || el.getAttribute?.("aria-modal") === "true")
            return true;
        if (el.tagName?.toLowerCase() === "dialog" && el.hasAttribute?.("open"))
            return true;
        return MODAL_MARKER_ATTRS.some((attr) => {
            const raw = el.getAttribute?.(attr) ?? "";
            if (!raw)
                return false;
            const names = attr === "class" ? raw.split(/\s+/) : [raw];
            return names.some((n) => MODAL_MARKER_RE.test(n) && !MODAL_STATE_RE.test(n));
        });
    }
    /** Kontainer `position: fixed` yang menutup hampir seluruh layar: overlay modal walau tanpa nama atau peran apa pun. */
    function coversViewportFixed(el) {
        try {
            if (typeof getComputedStyle !== "function" || getComputedStyle(el).position !== "fixed")
                return false;
            const rect = el.getBoundingClientRect?.();
            const view = globalThis;
            if (!rect || !view.innerWidth || !view.innerHeight)
                return false;
            return rect.width >= view.innerWidth * OVERLAY_VIEWPORT_RATIO && rect.height >= view.innerHeight * OVERLAY_VIEWPORT_RATIO;
        }
        catch {
            return false;
        }
    }
    /**
     * Wadah modal yang tidak memakai `role=dialog` + `aria-modal` dan tidak membungkus isinya dengan `<form>` (Glints:
     * `div[data-testid=modal-wrapper]` di dalam portal, langkah 1, 2, dan 4). Dicari dari kontrol isian ke atas: leluhur
     * yang bertanda modal (lihat `hasModalMarker`) atau berupa overlay fixed satu layar. Yang diambil adalah wadah
     * terluar (supaya footer dengan tombol Lanjut ikut) dari modal teratas (paling akhir di dokumen).
     *
     * Wadah harus terlihat, bukan noise, tidak membungkus `<main>` (itu halaman, bukan modal), dan memuat kontrol isian.
     * Wadah bertanda nama saja harus memuat minimal separuh kontrol halaman, supaya popup kecil (buletin) tidak menggeser
     * formulir utama; overlay fixed satu layar sudah pasti menutupi halaman, jadi tidak perlu syarat itu.
     */
    function findModalLikeRoot(doc, total) {
        const kindOf = new Map();
        const lastSeen = new Map();
        deepQueryAll(doc, PROBE_NODE_SELECTOR).forEach((control, index) => {
            const chain = [];
            for (let n = parentOrHost(control); n && chain.length < MAX_ANCESTOR_WALK; n = parentOrHost(n)) {
                const tag = n.tagName?.toLowerCase();
                if (tag === "body" || tag === "html")
                    break;
                chain.push(n);
            }
            chain.forEach((n, i) => {
                let kind = kindOf.get(n);
                if (kind === undefined) {
                    kind = hasModalMarker(n) ? "marker" : chain.length - i <= OVERLAY_TOP_LEVELS && coversViewportFixed(n) ? "overlay" : null;
                    kindOf.set(n, kind);
                }
                if (kind)
                    lastSeen.set(n, index);
            });
        });
        const qualified = [];
        for (const candidate of lastSeen.keys()) {
            if (!isElementVisible(candidate) || isNoiseNode(candidate, true) || hasNoiseAncestor(candidate, true))
                continue;
            if (candidate.querySelector?.('main, [role="main"]'))
                continue;
            const count = countFillableIn(doc, candidate, true);
            if (count > 0 && (kindOf.get(candidate) === "overlay" || count * 2 >= total))
                qualified.push(candidate);
        }
        const inner = new Set(qualified);
        let best = null;
        for (const candidate of qualified) {
            let nested = false;
            for (let a = parentOrHost(candidate), depth = 0; a && depth < MAX_ANCESTOR_WALK && !nested; a = parentOrHost(a), depth++)
                nested = inner.has(a);
            if (nested)
                continue;
            if (!best || (lastSeen.get(candidate) ?? -1) >= (lastSeen.get(best) ?? -1))
                best = candidate;
        }
        return best;
    }
    /**
     * Sakelar yang bertempat di luar `<form>` tetapi milik pertanyaan yang sama. Uji live JobStreet 26 November 2026:
     * "Saya baru masuk dunia kerja" berada di atas `<form>` riwayat karir, jadi tidak pernah terbaca. Akar dinaikkan paling
     * banyak 3 tingkat bila tambahannya hanya 1-2 kotak centang/sakelar dan wadah itu tidak memuat form lain.
     */
    const MAX_ADJACENT_TOGGLES = 2;
    function widenForAdjacentToggles(doc, form, formCount) {
        const body = documentBody(doc);
        let anc = parentOrHost(form);
        for (let depth = 0; anc && anc !== body && depth < 3; depth++, anc = parentOrHost(anc)) {
            if (anc.querySelectorAll("form").length > 1)
                break;
            const extra = countFillableIn(doc, anc, true) - formCount;
            if (extra <= 0)
                continue;
            if (extra > MAX_ADJACENT_TOGGLES)
                break;
            const toggles = Array.from(anc.querySelectorAll("input, [role=switch], [role=checkbox]")).filter((el) => {
                if (form.contains(el))
                    return false;
                const role = (el.getAttribute("role") ?? "").toLowerCase();
                return role === "switch" || role === "checkbox" || (el.getAttribute("type") ?? "").toLowerCase() === "checkbox";
            });
            return toggles.length >= extra ? anc : form;
        }
        return form;
    }
    /** Akar formulir halaman: dialog modal teratas, form terbesar, `main`, atau `body`. Dipakai ekstraksi, probe, dan skor frame. */
    function findFormRoot(doc) {
        return resolveFormRoot(doc).root;
    }
    /** Kata sandi yang terlihat di mana pun di halaman: penjaga login tidak boleh melemah karena akar formulir menyempit. */
    function documentHasVisiblePassword(doc) {
        return deepQueryAll(doc, "input").some((el) => (el.getAttribute("type") ?? "").toLowerCase() === "password" && isElementVisible(el));
    }
    /** Teks pemberitahuan: isi akar formulir lebih dulu, lalu cuplikan awal halaman untuk deteksi CAPTCHA, login, dan lowongan tutup. */
    const NOTICE_ROOT_CHARS = 1700;
    const NOTICE_BODY_CHARS = 800;
    function buildNoticeText(doc, root) {
        const body = documentBody(doc);
        const bodyText = (max) => cleanText(body?.innerText ?? body?.textContent ?? "", max);
        if (root === body)
            return bodyText(MAX_NOTICE_CHARS);
        const rootText = cleanText(root.innerText || root.textContent || "", NOTICE_ROOT_CHARS);
        return cleanText(`${rootText} ${bodyText(NOTICE_BODY_CHARS)}`, MAX_NOTICE_CHARS);
    }
    const MARKETING_CHECKBOX_RE = /newsletter|promo|marketing|info lowongan|job alert|communications/i;
    /**
     * Kelompokkan multi-checkbox di dalam `<fieldset>` / `[role="group"]` (Greenhouse) atau yang berbagi `name` yang sama
     * di cakupan formulir (Lever `cards[id][field0]`) menjadi satu kontrol pilihan beropsi agar tidak membanjiri antrean.
     * Kotak persetujuan, pemasaran, atau Google Forms tetap diekstrak sebagai checkbox terpisah.
     */
    function findCheckboxGroup(doc, el, googleForm) {
        if (googleForm)
            return null;
        let container = null;
        let depth = 0;
        for (let n = parentOrHost(el); n && depth < 6; n = parentOrHost(n), depth++) {
            const t = n.tagName?.toLowerCase();
            if (t === "body" || t === "html" || t === "form")
                break;
            if (elementMatches(n, 'fieldset, [role="group"]')) {
                container = n;
                break;
            }
        }
        const cbName = cleanText(el.getAttribute("name"), 160);
        if (!container && !cbName)
            return null;
        if (container) {
            const hasOtherControl = Array.from(container.querySelectorAll("input, textarea, select")).some((c) => {
                if (c.tagName.toLowerCase() !== "input")
                    return true;
                const t = (c.getAttribute("type") ?? "text").toLowerCase();
                return t !== "checkbox" && !NON_ANSWER_INPUT_TYPES.has(t);
            });
            if (hasOtherControl && !cbName)
                return null;
        }
        const searchRoot = container ?? scopeOf(el, doc);
        const boxes = deepQueryAll(searchRoot, 'input[type="checkbox"]').filter((b) => isPresentControl(b) && (!cbName || cleanText(b.getAttribute("name"), 160) === cbName));
        if (boxes.length < (cbName ? 2 : 3))
            return null;
        const groupLabel = cleanText(groupLabelForRadio(doc, el, "checkbox") || (container ? ariaGroupLabel(doc, container) : ""), 300);
        if (!groupLabel || CONSENT_TEXT_RE.test(groupLabel) || MARKETING_CHECKBOX_RE.test(groupLabel))
            return null;
        const options = boxes.map((b, bIdx) => labelForElement(doc, b) || cleanText(b.getAttribute("value"), 120) || `Option ${bIdx + 1}`);
        if (options.some((o) => CONSENT_TEXT_RE.test(o) || MARKETING_CHECKBOX_RE.test(o)))
            return null;
        return { container, boxes, name: cbName, groupLabel, options };
    }
    function extractFormSnapshot(doc, pageUrl) {
        const candidates = [];
        const { root, found: formRootFound } = resolveFormRoot(doc);
        let hasPasswordInput = documentHasVisiblePassword(doc);
        const hasCaptchaIframe = detectCaptchaIframe(doc);
        // Tombol Lanjut yang sedang nonaktif (menunggu unggahan atau isian) tetap menandai formulir multi-langkah.
        const hasNextStep = Boolean(findNextStepButton(doc) ?? findDisabledNextStepButton(doc));
        const seenRadioKeys = new Set();
        const seenAriaGroups = new Set();
        const editableIds = new Set();
        /** Id kontrol yang sudah dipegang di pembacaan ini (lihat `ensureControlId`). */
        const claimedIds = new Set();
        const scopeIds = new Map();
        const scopeIdOf = (scope) => {
            if (!scopeIds.has(scope))
                scopeIds.set(scope, scopeIds.size);
            return scopeIds.get(scope);
        };
        let idx = 0;
        // Google Forms memakai markup ARIA sendiri (listitem, radiogroup, listbox): dikenali dari URL frame ini.
        const googleForm = isGoogleFormsPage(doc, pageUrl);
        const formNodes = deepQueryAll(root, googleForm ? GOOGLE_FORM_NODE_SELECTOR : FORM_NODE_SELECTOR);
        const seenNodes = new Set();
        for (const el of formNodes) {
            if (candidates.length >= MAX_CANDIDATE_CONTROLS)
                break;
            if (seenNodes.has(el))
                continue;
            seenNodes.add(el);
            // Input file boleh tersembunyi: pengguna mengklik tombol kustom, sedangkan unggahan lewat DOM tidak butuh tampilan.
            // Radio atau centang tersembunyi yang diwakili label terlihat tetap jawaban formulir.
            if (!isFileInput$1(el) && !isPresentControl(el))
                continue;
            // Header, navigasi, banner cookie, dan obrolan bukan bagian formulir. Tombol kirim boleh di footer modal.
            if (isExcludedControl(el, root, isSubmitLike(el)))
                continue;
            const tag = el.tagName.toLowerCase();
            const role = explicitRoleOf(el);
            const isCombobox = role === "combobox" || el.getAttribute("aria-haspopup") === "listbox";
            const inputType = (el.getAttribute("type") ?? (tag === "textarea" ? "textarea" : tag === "select" ? "select" : "text")).toLowerCase();
            if (inputType === "password") {
                hasPasswordInput = true;
                continue;
            }
            if (isSubmitLike(el)) {
                // Pada formulir multi-langkah (ada tombol Lanjut), tombol pembuka ambigu di luar kontainer form ("Lamar Sekarang") jangan dikira submit final.
                if (hasNextStep && !isUnambiguousFinalSubmit(el) && !hasFormContainerWithFillable(el))
                    continue;
                const tagged = [];
                const submitId = ensureControlId(el, idx++, "applify_sub", tagged, claimedIds);
                candidates.push({
                    control: {
                        controlId: submitId,
                        kind: "submit",
                        label: cleanText(el.textContent || el.getAttribute("value") || el.getAttribute("aria-label") || "Submit", 120),
                        groupLabel: "",
                        name: cleanText(el.getAttribute("name"), 120),
                        placeholder: "",
                        inputType: "submit",
                        required: false,
                        options: [],
                        currentValue: "",
                        ...(isDisabledControl(el) ? { disabled: true } : {}),
                    },
                    tagged,
                });
                continue;
            }
            const isAriaWidgetRole = role === "checkbox" || role === "switch" || role === "radio";
            // Tombol bergantian (`aria-pressed`) di dalam grup berlabel: satu pertanyaan pilihan tunggal.
            if ((tag === "button" || role === "button") && !isCombobox && !isAriaWidgetRole && el.hasAttribute("aria-pressed")) {
                const group = toggleGroupContainer(doc, el);
                if (!group || seenAriaGroups.has(group.container))
                    continue;
                const options = toggleOptions(group.container);
                if (options.length < 2)
                    continue;
                seenAriaGroups.add(group.container);
                options.forEach((o) => seenNodes.add(o));
                for (const cb of deepQueryAll(group.container, 'input[type="checkbox"]'))
                    seenNodes.add(cb);
                const cid = ensureGroupId(doc, options, candidates.length);
                idx++;
                options.forEach((o) => o.setAttribute("data-applify-rg", cid));
                const labels = options.map((o, i) => ariaOptionLabel(doc, o) || `Option ${i + 1}`);
                const selected = options.findIndex((o) => ariaOn(o, "aria-pressed"));
                candidates.push({
                    control: {
                        controlId: cid,
                        kind: "radio",
                        label: group.label,
                        groupLabel: group.label,
                        name: "",
                        placeholder: "",
                        inputType: "radio",
                        required: group.required,
                        options: labels.slice(0, 50),
                        currentValue: selected >= 0 ? labels[selected] : "",
                        ...(options.every((o) => isDisabledControl(o)) ? { disabled: true } : {}),
                    },
                    tagged: options,
                });
                continue;
            }
            // Kotak centang pendamping di dalam wadah field entry yang memakai tombol Yes/No `aria-pressed`: dilewati agar tidak ganda.
            if (tag === "input" && inputType === "checkbox") {
                const companionGroup = toggleGroupContainer(doc, el);
                if (companionGroup && toggleOptions(companionGroup.container).length >= 2) {
                    seenNodes.add(el);
                    continue;
                }
            }
            // Dropdown Google Forms: `div[role=listbox]` berisi `role=option`, bukan `<select>` dan bukan combobox.
            if (googleForm && role === "listbox" && !isNativeFormTag(el)) {
                const dropdown = googleDropdown(el);
                if (dropdown.labels.length === 0)
                    continue;
                const question = googleQuestionOf(el);
                const tagged = [];
                const dropdownId = ensureControlId(el, idx++, "applify_c", tagged, claimedIds);
                candidates.push({
                    control: {
                        controlId: dropdownId,
                        kind: "select",
                        label: question?.title || questionLabelFor(doc, el),
                        groupLabel: "",
                        name: cleanText(el.getAttribute("name"), 160),
                        placeholder: "",
                        inputType: "select",
                        required: el.getAttribute("aria-required") === "true" || Boolean(question?.required),
                        options: dropdown.labels,
                        currentValue: dropdown.selected,
                        ...controlState(el, "select", role),
                    },
                    tagged,
                });
                continue;
            }
            // Tombol biasa dilewati. `<button role="switch|checkbox|radio">` justru kontrol ARIA, jadi lanjut ke bawah.
            if ((tag === "button" || role === "button") && !isCombobox && !isAriaWidgetRole)
                continue;
            // Judul pertanyaan Google Forms (listitem + heading): label dan penanda wajib yang pasti, tanpa menebak dari wadah.
            const googleQuestion = googleForm ? googleQuestionOf(el) : null;
            const required = el.hasAttribute("required") || el.getAttribute("aria-required") === "true";
            if (tag === "input" && inputType === "radio") {
                const radioName = cleanText(el.getAttribute("name"), 160);
                const scope = scopeOf(el, doc);
                const container = nativeRadioContainer(el);
                const groupKey = radioName ? `${scopeIdOf(scope)}:${radioName}` : "";
                if (groupKey && seenRadioKeys.has(groupKey))
                    continue;
                if (groupKey)
                    seenRadioKeys.add(groupKey);
                // Radio bernama: satu grup per `name`. Radio tanpa nama (ant-design): satu grup per wadah grup, bukan per radio.
                const groupRadios = radioName
                    ? Array.from(scope.querySelectorAll(`input[type="radio"]`)).filter((r) => r.getAttribute("name") === radioName)
                    : container
                        ? visibleNativeRadios(container).filter((r) => !r.getAttribute("name"))
                        : [el];
                if (!groupRadios.includes(el))
                    groupRadios.unshift(el);
                groupRadios.forEach((r) => seenNodes.add(r));
                const groupLabel = groupLabelForRadio(doc, el) || (container ? ariaGroupLabel(doc, container) : "") || labelForElement(doc, el) || radioName;
                const options = [];
                let anyCheckedVal = "";
                const cid = ensureGroupId(doc, groupRadios, candidates.length);
                groupRadios.forEach((r, rIdx) => {
                    const optLabel = labelForElement(doc, r) || cleanText(r.getAttribute("value"), 120) || `Option ${rIdx + 1}`;
                    options.push(optLabel);
                    r.setAttribute("data-applify-rg", cid);
                    if (r.checked)
                        anyCheckedVal = optLabel;
                });
                idx++;
                candidates.push({
                    control: {
                        controlId: cid,
                        kind: "radio",
                        label: groupLabel,
                        groupLabel,
                        name: radioName,
                        placeholder: "",
                        inputType: "radio",
                        required: groupRadios.some((r) => r.hasAttribute("required") || r.getAttribute("aria-required") === "true"),
                        options: options.slice(0, 50),
                        currentValue: anyCheckedVal,
                        ...(groupRadios.every((r) => isDisabledControl(r) || r.disabled === true) ? { disabled: true } : {}),
                        ...radioToggleFlags(options, groupLabel),
                    },
                    tagged: groupRadios,
                });
                continue;
            }
            if (tag === "input" && inputType === "checkbox") {
                const cbGroup = findCheckboxGroup(doc, el, googleForm);
                if (cbGroup) {
                    if (!cbGroup.boxes.includes(el))
                        cbGroup.boxes.unshift(el);
                    cbGroup.boxes.forEach((b) => seenNodes.add(b));
                    const cid = ensureGroupId(doc, cbGroup.boxes, candidates.length);
                    let firstCheckedVal = "";
                    cbGroup.boxes.forEach((b, bIdx) => {
                        b.setAttribute("data-applify-rg", cid);
                        if (!firstCheckedVal && b.checked)
                            firstCheckedVal = cbGroup.options[bIdx] ?? "";
                    });
                    idx++;
                    candidates.push({
                        control: {
                            controlId: cid,
                            kind: "radio",
                            label: cbGroup.groupLabel,
                            groupLabel: cbGroup.groupLabel,
                            name: cbGroup.name,
                            placeholder: "",
                            inputType: "checkbox",
                            required: cbGroup.container?.getAttribute("aria-required") === "true" ||
                                (cbGroup.container ? hasRequiredFieldIndicator(cbGroup.container) : false) ||
                                cbGroup.boxes.some((b) => b.hasAttribute("required") || b.getAttribute("aria-required") === "true"),
                            options: cbGroup.options.slice(0, 50),
                            currentValue: firstCheckedVal,
                            ...(cbGroup.boxes.every((b) => isDisabledControl(b) || b.disabled === true)
                                ? { disabled: true }
                                : {}),
                        },
                        tagged: cbGroup.boxes,
                    });
                    continue;
                }
            }
            // Grup radio ARIA: `role=radio` (di dalam `role=radiogroup` bila ada) menjadi satu pertanyaan pilihan tunggal.
            if (role === "radio" && tag !== "input") {
                const container = ariaRadioContainer(el);
                if (seenAriaGroups.has(container))
                    continue;
                const options = ariaRadioOptions(container);
                if (options.length === 0)
                    continue;
                seenAriaGroups.add(container);
                options.forEach((o) => seenNodes.add(o));
                const cid = ensureGroupId(doc, options, candidates.length);
                idx++;
                options.forEach((o) => o.setAttribute("data-applify-rg", cid));
                const labels = options.map((o, i) => ariaOptionLabel(doc, o) || `Option ${i + 1}`);
                const selected = options.findIndex((o) => ariaOn(o, "aria-checked"));
                // Google Forms: judul pertanyaan (kisi: "judul: baris"), bukan teks `aria-labelledby` yang memuat bintang wajib.
                const groupLabel = googleQuestion
                    ? googleControlLabel(googleQuestion, cleanText(container.getAttribute("aria-label"), 300) || labelledByText(doc, container), true)
                    : ariaGroupLabel(doc, container) || labels[0];
                candidates.push({
                    control: {
                        controlId: cid,
                        kind: "radio",
                        label: groupLabel,
                        groupLabel,
                        name: cleanText(container.getAttribute("name"), 160),
                        placeholder: "",
                        inputType: "radio",
                        required: container.getAttribute("aria-required") === "true" ||
                            options.some((o) => o.getAttribute("aria-required") === "true") ||
                            Boolean(googleQuestion?.required),
                        options: labels.slice(0, 50),
                        currentValue: selected >= 0 ? labels[selected] : "",
                        role: "radiogroup",
                        ...(options.every((o) => isDisabledControl(o)) || isDisabledControl(container) ? { disabled: true } : {}),
                        ...radioToggleFlags(labels, groupLabel),
                    },
                    tagged: options,
                });
                continue;
            }
            const isAriaCheck = !isNativeFormTag(el) && (role === "checkbox" || role === "switch");
            const editable = !isCombobox && !isAriaCheck && isStandaloneEditable(doc, el);
            // `contenteditable` yang bukan kotak teks mandiri (pembungkus, simpul editor bersarang) dilewati.
            if (!isNativeFormTag(el) && !isCombobox && !isAriaCheck && !editable)
                continue;
            const kind = tag === "textarea" || editable
                ? "textarea"
                : tag === "select" || isCombobox
                    ? "select"
                    : inputType === "checkbox" || isAriaCheck
                        ? "checkbox"
                        : inputType === "file"
                            ? "file"
                            : "text";
            const tagged = [];
            const cid = ensureControlId(el, idx++, "applify_c", tagged, claimedIds);
            const listboxId = el.getAttribute("aria-controls");
            const listboxEl = listboxId ? elementByIdNear(el, doc, listboxId) : null;
            const options = tag === "select"
                ? Array.from(el.options ?? [])
                    .map((o) => cleanText(o.textContent || o.value, 120))
                    .filter(Boolean)
                    .slice(0, 50)
                : listboxEl
                    ? Array.from(listboxEl.querySelectorAll('[role="option"], option, li'))
                        .map((o) => cleanText(o.textContent, 120))
                        .filter(Boolean)
                        .slice(0, 50)
                    : [];
            const currentValue = kind === "file"
                ? ""
                : kind === "checkbox"
                    ? el.checked === true || ariaOn(el, "aria-checked")
                        ? "true"
                        : ""
                    : editable
                        ? cleanText(editableText(el), 300)
                        : isCombobox && tag !== "select"
                            ? cleanText(el.value, 300) || comboboxDisplayValue(el)
                            : cleanText(el.value, 300);
            if (editable)
                editableIds.add(cid);
            const placeholder = cleanText(el.getAttribute("placeholder") ?? (editable ? (el.getAttribute("aria-placeholder") ?? el.getAttribute("data-placeholder")) : null), 160);
            const visualRequired = required || (!googleForm && hasVisualRequiredForControl(el));
            if (visualRequired)
                el.setAttribute("data-applify-req", "1");
            else
                el.removeAttribute("data-applify-req");
            const baseLabel = kind === "file" ? labelForFileInput(doc, el) : isAriaCheck ? ariaCheckLabel(doc, el) : questionLabelFor(doc, el);
            // Google Forms: judul pertanyaan memberi label dan penanda wajib. Kotak centang dan kolom "Lainnya:" milik radio
            // memakai "judul: pilihan" karena satu pertanyaan punya banyak kontrol; kelompok wajib berarti tiap pilihannya wajib.
            const inChoiceGroup = Boolean(googleQuestion && insideChoiceGroup(el, googleQuestion));
            const label = googleQuestion && kind !== "file"
                ? googleControlLabel(googleQuestion, isAriaCheck ? labelForElement(doc, el) || cleanText(el.textContent, 300) : baseLabel, isAriaCheck || inChoiceGroup)
                : baseLabel;
            const questionRequired = googleQuestion
                ? isAriaCheck
                    ? googleQuestion.required || ancestorRequired(el, googleQuestion)
                    : googleQuestion.required && !inChoiceGroup
                : false;
            const groupHeading = googleQuestion && isAriaCheck ? googleQuestion.title : kind === "select" || kind === "text" ? legendGroupLabel(el) : "";
            const sectionHeading = !googleForm ? sectionHeadingForControl(el, root) : "";
            const helperText = !googleForm && kind !== "file" ? helperTextForControl(doc, el, label, placeholder) : "";
            candidates.push({
                control: {
                    controlId: cid,
                    kind,
                    label,
                    groupLabel: groupHeading,
                    name: cleanText(el.getAttribute("name"), 160),
                    placeholder,
                    inputType: isAriaCheck ? "checkbox" : editable ? "textarea" : inputType,
                    required: visualRequired || questionRequired,
                    options,
                    currentValue,
                    ...(sectionHeading && sectionHeading.toLowerCase() !== label.toLowerCase() ? { sectionHeading } : {}),
                    ...(groupHeading && groupHeading.toLowerCase() !== label.toLowerCase() ? { groupHeading } : {}),
                    ...(helperText ? { helperText } : {}),
                    ...(kind === "file" ? { elementId: cleanText(el.getAttribute("id"), 160) } : {}),
                    ...controlState(el, kind, role || (editable ? "textbox" : ""), isCombobox),
                    ...(kind === "select" && isCombobox && isSearchableCombobox$1(el) ? { searchable: true } : {}),
                    ...constraintsOf(el, kind, editable),
                },
                tagged,
            });
        }
        const controls = capCandidates(candidates);
        // Galat validasi per kolom: hanya yang sungguh tampil di halaman (lihat `fieldErrors.ts`).
        const errorTexts = [];
        for (const c of controls) {
            if (c.kind === "submit" || c.kind === "file")
                continue;
            let el = null;
            try {
                el = findControlByCid(doc, c.controlId);
            }
            catch {
                el = null;
            }
            const message = el ? extractFieldErrorMessage(el) : null;
            if (message) {
                c.errorText = cleanText(message, MAX_ERROR_TEXT_CHARS);
                errorTexts.push(c.errorText);
                // Uji live JobStreet 26 November 2026: "Posisi pekerjaan" tidak bertanda required di DOM, tetapi halaman
                // menampilkan "Silakan tambahkan ...". Pesan galat yang menuntut isian berarti kolom itu wajib.
                if (REQUIRED_ERROR_RE.test(message))
                    c.required = true;
            }
        }
        const sectionHeadings = collectSectionHeadings(root);
        const validationErrors = uniqueLimited([...collectValidationErrors(root, MAX_VALIDATION_ERRORS), ...errorTexts], MAX_VALIDATION_ERRORS, MAX_ERROR_TEXT_CHARS);
        const noticeText = buildNoticeText(doc, root);
        // Kotak teks contenteditable (widget obrolan, editor) tidak menandakan formulir lamaran sudah terbuka.
        const hasNonSubmitControls = controls.some((c) => c.kind !== "submit" && !editableIds.has(c.controlId));
        const hasOpeningCta = !hasNonSubmitControls && !hasPasswordInput && !hasCaptchaIframe && Boolean(findOpeningApplyButton(doc));
        return {
            pageUrl,
            noticeText,
            hasPasswordInput,
            hasCaptchaIframe,
            ...(hasOpeningCta ? { hasOpeningCta: true } : {}),
            formRootFound,
            ...(sectionHeadings.length > 0 ? { sectionHeadings } : {}),
            ...(validationErrors.length > 0 ? { validationErrors } : {}),
            controls,
        };
    }
    function uniqueLimited(items, limit, maxChars) {
        const out = [];
        for (const raw of items) {
            const text = cleanText(raw, maxChars);
            if (text && !out.includes(text))
                out.push(text);
            if (out.length >= limit)
                break;
        }
        return out;
    }
    /** Judul bagian terlihat di akar formulir (h1, h2, h3, legend), tanpa banner cookie dan sejenisnya. */
    function collectSectionHeadings(root) {
        let nodes = [];
        try {
            nodes = deepQueryAll(root, "h1, h2, h3, legend");
        }
        catch {
            return [];
        }
        const texts = [];
        for (const node of nodes) {
            if (texts.length >= MAX_SECTION_HEADINGS * 3)
                break;
            if (!isElementVisible(node) || isNoiseNode(node, false) || hasNoiseAncestor(node, false))
                continue;
            texts.push(cleanText(node.textContent, MAX_SECTION_HEADING_CHARS));
        }
        return uniqueLimited(texts, MAX_SECTION_HEADINGS, MAX_SECTION_HEADING_CHARS);
    }
    /** Iframe pihak ketiga yang bukan formulir: pemutar video, peta, widget sosial, iklan, pelacak, dan obrolan. */
    const NON_FORM_IFRAME_HOST_RE = /(^|\.)(youtube(-nocookie)?\.com|youtu\.be|vimeo\.com|facebook\.com|instagram\.com|twitter\.com|x\.com|tiktok\.com|linkedin\.com|doubleclick\.net|googletagmanager\.com|googlesyndication\.com|google-analytics\.com|hotjar\.com|intercom\.io|intercomcdn\.com|drift\.com|zdassets\.com|zendesk\.com|tawk\.to|crisp\.chat|livechatinc\.com|hs-scripts\.com|hubspot\.com|calendly\.com|stripe\.com|paypal\.com)$/i;
    const MAX_FOREIGN_FRAMES = 3;
    /** Iframe lebih kecil dari ini (piksel) dianggap pelacak atau ikon, bukan formulir. Diabaikan bila tanpa `getBoundingClientRect` (lingkungan tes). */
    const MIN_FORM_IFRAME_WIDTH = 200;
    const MIN_FORM_IFRAME_HEIGHT = 150;
    /**
     * Origin iframe lintas-origin non-CAPTCHA yang terlihat dan cukup besar, paling banyak `MAX_FOREIGN_FRAMES`, tanpa
     * duplikat. Hanya http(s); `srcdoc`, `about:blank`, dan iframe satu-origin (sudah dijangkau `allFrames`) dilewati.
     */
    function foreignFrameOrigins(doc) {
        const own = doc;
        const ownOrigin = own.location?.origin ?? own.defaultView?.location?.origin ?? null;
        const out = [];
        let frames = [];
        try {
            frames = deepQueryAll(doc, "iframe");
        }
        catch {
            return out;
        }
        for (const frame of frames) {
            const src = (frame.getAttribute("src") ?? "").trim();
            if (!src || !isElementVisible(frame))
                continue;
            let url;
            try {
                url = new URL(src, ownOrigin ?? undefined);
            }
            catch {
                continue;
            }
            if (url.protocol !== "https:" && url.protocol !== "http:")
                continue;
            if (ownOrigin && url.origin === ownOrigin)
                continue;
            const host = url.hostname.toLowerCase();
            if (NON_FORM_IFRAME_HOST_RE.test(host) || /recaptcha|hcaptcha|turnstile|challenges\.cloudflare\.com/i.test(url.href))
                continue;
            const rect = typeof frame.getBoundingClientRect === "function" ? frame.getBoundingClientRect() : null;
            if (rect && (rect.width < MIN_FORM_IFRAME_WIDTH || rect.height < MIN_FORM_IFRAME_HEIGHT))
                continue;
            if (!out.includes(url.origin))
                out.push(url.origin);
            if (out.length >= MAX_FOREIGN_FRAMES)
                break;
        }
        return out;
    }
    /** Kotak centang dan radio tidak dihitung: banner cookie yang tergambar lebih dulu bukan tanda formulir lamaran sudah ada. */
    const PROBE_SKIP_TYPES = new Set(["hidden", "submit", "button", "image", "reset", "search", "password", "checkbox", "radio"]);
    /** Frasa kuat saja ("masuk untuk melamar"); kata "Masuk" tunggal di menu situs bukan tanda halaman login. */
    const PROBE_BLOCKER_TEXT_RE = /(sign in|log in|login|masuk)\s+(to|untuk)\s+(apply|melamar|lanjut|continue)|silakan\s+(login|masuk)|please\s+(log|sign)\s*in|verify you are human|are you a robot|checking your browser|just a moment|verifikasi bahwa anda manusia/i;
    function insideSearchLandmark(el) {
        for (let node = parentOrHost(el); node; node = parentOrHost(node)) {
            const role = (node.getAttribute?.("role") ?? "").toLowerCase();
            if (role === "search" || node.tagName?.toLowerCase() === "nav")
                return true;
        }
        return false;
    }
    const PROBE_NODE_SELECTOR = 'input, textarea, select, [role="combobox"], [aria-haspopup="listbox"], [role="checkbox"], [role="switch"], [role="radio"], [contenteditable]';
    /**
     * Hitung kontrol isian yang terlihat di bawah `root`, termasuk yang di dalam shadow root terbuka. `withChoices` ikut
     * menghitung kotak centang dan radio (asli maupun ARIA). Kolom cari, kontrol di dalam `<nav>`, banner cookie, widget
     * obrolan, header, footer, aside, dan kata sandi tidak dihitung.
     */
    function countFillableIn(doc, root, withChoices) {
        // `contenteditable` hanya dihitung bersama pilihan (skor frame). Probe tidak menghitungnya: widget obrolan dan editor
        // lain di halaman lowongan bukan tanda formulir lamaran sudah terbuka, dan bisa menghalangi klik tombol pembuka.
        const withEditable = withChoices;
        let fillable = 0;
        // Dropdown Google Forms (`role=listbox`) juga kolom isian: formulir yang isinya hanya dropdown tidak boleh tampak kosong.
        const probeSelector = isGoogleFormsPage(doc) ? `${PROBE_NODE_SELECTOR}, [role="listbox"]` : PROBE_NODE_SELECTOR;
        for (const el of deepQueryAll(root, probeSelector)) {
            const tag = el.tagName.toLowerCase();
            const role = explicitRoleOf(el);
            const native = isNativeFormTag(el);
            if (!native && (role === "checkbox" || role === "switch" || role === "radio") && !(el.getAttribute("aria-haspopup") === "listbox")) {
                if (withChoices && isElementVisible(el) && !insideSearchLandmark(el) && !isExcludedControl(el, root, false))
                    fillable++;
                continue;
            }
            if (!native && el.hasAttribute("contenteditable") && (!withEditable || !isStandaloneEditable(doc, el)))
                continue;
            const type = (el.getAttribute("type") ?? (tag === "textarea" || (!native && isEditableHost(el)) ? "textarea" : "text")).toLowerCase();
            if (type === "password")
                continue;
            // Input ant/rc-select bertipe `search` tetap kolom isian (combobox); kolom cari situs berada di landmark pencarian.
            const searchTypedCombobox = type === "search" && (role === "combobox" || el.getAttribute("aria-haspopup") === "listbox");
            if (PROBE_SKIP_TYPES.has(type) && !searchTypedCombobox && !(withChoices && (type === "checkbox" || type === "radio")))
                continue;
            // Radio atau centang tersembunyi yang diwakili label terlihat tetap jawaban formulir.
            if (!isFileInput$1(el) && !isPresentControl(el))
                continue;
            if (insideSearchLandmark(el) || isExcludedControl(el, root, false))
                continue;
            fillable++;
        }
        return fillable;
    }
    /**
     * Skor sebuah frame untuk `pickBestFrameId`: jumlah kontrol isian terlihat (kotak centang dan radio ikut), termasuk
     * shadow root terbuka, kotak teks `contenteditable`, dan widget ARIA. Sumber yang sama dengan pembacaan formulir.
     */
    function countFormControls(doc) {
        return countFillableIn(doc, findFormRoot(doc), true);
    }
    /**
     * Ringan dan tanpa efek samping (tidak memberi `data-applify-cid`). Dipakai antrean latar untuk menunggu SPA yang
     * `status: complete` tetapi formulirnya belum tergambar: baru lanjut membaca formulir bila sudah ada kolom isian
     * atau tanda login/CAPTCHA.
     */
    function probeForm(doc) {
        const fillable = countFillableIn(doc, findFormRoot(doc), false);
        const hasPassword = documentHasVisiblePassword(doc);
        let blocker = hasPassword || detectCaptchaIframe(doc);
        if (!blocker) {
            try {
                blocker = deepQueryAll(doc, '[data-sitekey]').some((el) => isActiveCaptchaElement(el));
            }
            catch {
                blocker = false;
            }
        }
        if (!blocker) {
            const text = cleanText(doc.body?.innerText ?? doc.body?.textContent ?? "", MAX_NOTICE_CHARS);
            blocker = PROBE_BLOCKER_TEXT_RE.test(text);
        }
        // Hanya bila frame ini kosong: iframe lintas-origin yang tidak terbaca ekstensi menjelaskan "formulir tidak muncul".
        const foreignFrames = fillable === 0 && !blocker ? foreignFrameOrigins(doc) : [];
        return { fillable, hasPassword, blocker, ...(foreignFrames.length > 0 ? { foreignFrames } : {}) };
    }

    /**
     * Berkas lamaran yang dipasang ke input file halaman: jenis, batas ukuran, dan pembersihan metadata dari respons backend.
     *
     * Berkas hanya hidup di memori service worker dan skrip konten selama satu pengisian. Tidak pernah ditulis ke
     * `chrome.storage` (session maupun local).
     */
    const FILE_KINDS = ["resume", "cover_letter", "transcript", "portfolio"];
    const emptyFilesAttached = () => ({ resume: false, cover_letter: false, transcript: false, portfolio: false });
    function isFileKind(value) {
        return typeof value === "string" && FILE_KINDS.includes(value);
    }

    /**
     * Catatan audit per aksi pengisian. Dibuat skrip konten (tiap kontrol) dan alur latar (klik Lanjut/pembuka), lalu
     * ikut dilaporkan ke backend sebagai `actionLog`.
     *
     * Aturan privasi: catatan TIDAK PERNAH memuat nilai isian, jawaban, atau teks halaman. Hanya ID kontrol buatan
     * ekstensi, jenis kontrol, jenis aksi, hasil, dan kode alasan dari daftar tertutup.
     */
    const MAX_ACTION_LOG = 200;

    /**
     * Interaksi dasar dengan halaman: gulir, klik seperti pengguna, dan penilaian "elemen benar-benar tampil". Dipisah dari
     * `fillControls.ts` supaya modul pengisi lain (unggah berkas, teks, dropdown) memakai satu implementasi yang sama.
     */
    /** Elemen terlihat: tidak `hidden`, dan tidak `display:none`/`visibility:hidden` pada dirinya atau leluhurnya (menembus shadow root). */
    function isShown(el) {
        for (let n = el; n; n = parentOrHost(n)) {
            if (n.hidden)
                return false;
            if (typeof getComputedStyle === "function") {
                try {
                    const style = getComputedStyle(n);
                    if (style.display === "none" || style.visibility === "hidden")
                        return false;
                }
                catch {
                    // Lingkungan tes non-browser mengabaikan getComputedStyle
                }
            }
        }
        return true;
    }
    /**
     * Elemen punya kotak tata letak yang nyata (lebar dan tinggi di atas nol). Tanpa `getBoundingClientRect` (lingkungan
     * tes) dianggap punya. Dipakai untuk mengabaikan simpul cermin 0-tinggi (daftar ARIA tersembunyi milik rc-select).
     */
    function hasLayout(el) {
        const target = el;
        if (typeof target.getBoundingClientRect !== "function")
            return true;
        try {
            const rect = target.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0;
        }
        catch {
            return true;
        }
    }
    /** Tampil di layar: lolos `isShown` dan punya kotak tata letak. */
    const isRendered = (el) => isShown(el) && hasLayout(el);
    const SCROLL_OVERFLOW_RE = /(auto|scroll|overlay)/;
    /**
     * Leluhur terdekat yang menggulir isinya sendiri (badan modal, panel samping). `null` bila tidak ada atau lingkungan
     * tanpa `getComputedStyle`. Body dan html tidak dihitung: gulir halaman diukur terhadap jendela.
     */
    function nearestScrollableAncestor(el) {
        if (typeof getComputedStyle !== "function")
            return null;
        for (let n = parentOrHost(el); n; n = parentOrHost(n)) {
            const tag = n.tagName.toLowerCase();
            if (tag === "body" || tag === "html")
                return null;
            try {
                const style = getComputedStyle(n);
                const box = n;
                if (SCROLL_OVERFLOW_RE.test(String(style.overflowY ?? "")) && box.scrollHeight > box.clientHeight + 1)
                    return n;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    /**
     * Gulir elemen ke tengah layar bila belum terlihat penuh, supaya aksi berikutnya (klik, ketik) terjadi pada elemen
     * yang benar-benar tampil seperti pada pengguna sungguhan. "Terlihat" diukur terhadap jendela DAN wadah gulir terdekat
     * (badan modal): elemen yang masih di dalam jendela tetapi terpotong badan modal tetap digulir. Aman di lingkungan
     * tanpa `scrollIntoView`.
     */
    function scrollIntoViewIfNeeded(el) {
        const target = el;
        if (typeof target.scrollIntoView !== "function")
            return false;
        try {
            const rect = typeof target.getBoundingClientRect === "function" ? target.getBoundingClientRect() : null;
            const viewportHeight = typeof window !== "undefined" ? window.innerHeight : 0;
            const scroller = nearestScrollableAncestor(el);
            if (rect && rect.height > 0 && (viewportHeight > 0 || scroller)) {
                let top = viewportHeight > 0 ? 0 : Number.NEGATIVE_INFINITY;
                let bottom = viewportHeight > 0 ? viewportHeight : Number.POSITIVE_INFINITY;
                if (scroller) {
                    const box = scroller.getBoundingClientRect();
                    top = Math.max(top, box.top);
                    bottom = Math.min(bottom, box.bottom);
                }
                if (rect.top >= top && rect.bottom <= bottom)
                    return false;
            }
            target.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
            return true;
        }
        catch {
            return false;
        }
    }
    /** Urutan pointer dan mouse seperti klik pengguna. `click` sendiri dikirim lewat `el.click()` sesudahnya. */
    const POINTER_SEQUENCE = [
        { type: "pointerdown", pointer: true },
        { type: "mousedown", pointer: false },
        { type: "pointerup", pointer: true },
        { type: "mouseup", pointer: false },
    ];
    function makePointerLikeEvent(type, pointer, x, y) {
        const init = {
            bubbles: true,
            cancelable: true,
            composed: true,
            button: 0,
            buttons: type.endsWith("down") ? 1 : 0,
            clientX: x,
            clientY: y,
            pointerType: "mouse",
            isPrimary: true,
        };
        if (pointer && typeof PointerEvent === "function")
            return new PointerEvent(type, init);
        if (!pointer && typeof MouseEvent === "function")
            return new MouseEvent(type, init);
        return new Event(type, { bubbles: true, cancelable: true });
    }
    /**
     * Klik seperti pengguna: gulir ke tengah layar, kirim pointerdown, mousedown, pointerup, mouseup, lalu click.
     *
     * Menolak (false, tanpa event apa pun) elemen yang mengirim formulir atau berlabel kirim akhir (`clickGuardReason`).
     * Tombol Kirim yang diotorisasi memakai `clickSubmitControl`, bukan fungsi ini.
     */
    function humanClick(el) {
        if (clickGuardReason(el))
            return false;
        scrollIntoViewIfNeeded(el);
        const target = el;
        let x = 0;
        let y = 0;
        try {
            const rect = target.getBoundingClientRect?.();
            if (rect) {
                x = Math.round(rect.left + rect.width / 2);
                y = Math.round(rect.top + rect.height / 2);
            }
        }
        catch {
            // Lingkungan tanpa tata letak: koordinat 0,0.
        }
        for (const step of POINTER_SEQUENCE) {
            try {
                target.dispatchEvent(makePointerLikeEvent(step.type, step.pointer, x, y));
            }
            catch {
                // Event yang gagal dibuat tidak boleh membatalkan klik.
            }
        }
        target.click?.();
        return true;
    }
    /** Alasan kontrol tidak disentuh: dinonaktifkan atau hanya-baca. Pengisi tidak memaksa menulis ke kontrol seperti itu. */
    function skipReason(el) {
        const flag = (prop, attr) => el[prop] === true || el.hasAttribute?.(attr) === true;
        if (flag("disabled", "disabled") || el.getAttribute?.("aria-disabled") === "true")
            return "disabled";
        if (flag("readOnly", "readonly") || el.getAttribute?.("aria-readonly") === "true")
            return "readonly";
        return null;
    }

    /**
     * Normalisasi nomor telepon sebelum ditulis, supaya cocok dengan cara kolom itu menampilkan nomor: banyak form
     * (Dealls, intl-tel-input, react-phone-number-input) menaruh kode negara di samping kolom, lalu mengharapkan nomor
     * nasional saja. Menulis "08123..." ke kolom seperti itu menghasilkan "+62 08123..." yang ditolak validasi.
     */
    const PHONE_VALUE_RE = /^[\d\s+()\-./]+$/;
    const PHONE_HINT_RE = /phone|telp|telepon|handphone|whatsapp|\bwa\b|\bhp\b|mobile|ponsel|\bno\.?\s*(?:hp|wa|telp)/i;
    const DIAL_CODE_RE = /\+\s?(\d{1,4})/;
    const INDONESIA_RE = /\b(?:IDN|Indonesia)\b/i;
    const ADDON_SELECTOR = '[class*="input-group-addon"], [class*="iti__"], [class*="PhoneInput"], [class*="phone-input"], [class*="country"], [class*="dial"], [class*="select-selection-item"], select';
    const digitsOf$1 = (s) => s.replace(/\D/g, "");
    /** Teks petunjuk dari atribut kolom dan labelnya. */
    function hintText(el, doc) {
        const attrs = ["name", "id", "placeholder", "aria-label", "autocomplete", "data-testid"].map((a) => el.getAttribute(a) ?? "").join(" ");
        let label = "";
        try {
            label = doc ? questionLabelFor(doc, el) : "";
        }
        catch {
            label = "";
        }
        return `${attrs} ${label}`;
    }
    /** Kolom ini kolom telepon: type=tel, autocomplete/inputmode telepon, atau nama, id, placeholder, dan label yang menyebutnya. */
    function isPhoneField(el, doc) {
        const type = (el.getAttribute("type") ?? "").toLowerCase();
        if (type === "tel")
            return true;
        if (/^tel/.test((el.getAttribute("autocomplete") ?? "").toLowerCase().replace(/^.*\s/, "")))
            return true;
        if ((el.getAttribute("inputmode") ?? "").toLowerCase() === "tel")
            return true;
        return PHONE_HINT_RE.test(hintText(el, doc));
    }
    function selectedOptionText(node) {
        const sel = node;
        if (node.tagName.toLowerCase() !== "select")
            return "";
        const idx = typeof sel.selectedIndex === "number" ? sel.selectedIndex : -1;
        const opt = idx >= 0 ? sel.options?.[idx] : undefined;
        return (opt?.textContent ?? "").trim();
    }
    /**
     * Kode negara yang ditampilkan di samping kolom (dalam dua leluhur): addon `ant-input-group-addon`, `ant-select`
     * bertuliskan +62 atau IDN, `react-phone-number-input`, atau `iti__selected-flag`. `found` true bila ada penunjuk
     * semacam itu, `code` kode negaranya ("62" bila hanya tertulis IDN/Indonesia, null bila tidak terbaca).
     */
    function findCountryAddon(el) {
        let level = parentOrHost(el);
        for (let depth = 0; level && depth < 2; depth++, level = parentOrHost(level)) {
            let nodes = [];
            try {
                nodes = Array.from(level.querySelectorAll(ADDON_SELECTOR));
            }
            catch {
                nodes = [];
            }
            // Wadah yang memuat kolom teks lain terlalu lebar (baris form, form): addon di sana milik kolom lain.
            let others = [];
            try {
                others = Array.from(level.querySelectorAll("input, textarea")).filter((i) => i !== el && (i.getAttribute("type") ?? "").toLowerCase() !== "hidden" && (i.getAttribute("role") ?? "").toLowerCase() !== "combobox" && !nodes.some((n) => n.contains?.(i)));
            }
            catch {
                others = [];
            }
            if (others.length > 0)
                break;
            for (const node of nodes) {
                if (node === el || node.contains?.(el))
                    continue;
                const own = selectedOptionText(node) || (node.textContent ?? "").replace(/\s+/g, " ").trim();
                if (!own || own.length > 60)
                    continue;
                const dial = DIAL_CODE_RE.exec(own);
                if (dial)
                    return { found: true, code: dial[1] };
                if (INDONESIA_RE.test(own))
                    return { found: true, code: "62" };
            }
        }
        return { found: false, code: null };
    }
    /** Pecah nomor menjadi kode negara (bila tertulis) dan nomor nasional tanpa nol di depan. null bila bukan nomor Indonesia. */
    function parseNumber(raw) {
        let digits = digitsOf$1(raw);
        const plus = raw.trim().startsWith("+");
        if (digits.startsWith("00"))
            digits = digits.slice(2);
        else if (plus && !digits.startsWith("62"))
            return null;
        if (digits.startsWith("62") && digits.length >= 10)
            return { national: digits.slice(2).replace(/^0+/, "") };
        if (digits.startsWith("0"))
            return { national: digits.replace(/^0+/, "") };
        if (plus || digits.startsWith("00"))
            return null;
        return { national: digits };
    }
    /**
     * Bentuk nomor yang cocok dengan kolom `el`:
     *   1. ada kode negara di samping kolom (+62, IDN): nomor nasional tanpa nol di depan ("81234567890");
     *   2. placeholder diawali "+62": E.164 ("+6281234567890");
     *   3. placeholder diawali "08": bentuk lokal berawalan nol ("081234567890");
     *   4. selain itu nilai apa adanya.
     * `maxLength` dihormati: bentuk pilihan dipakai bila muat, kalau tidak bentuk lain yang muat.
     */
    function normalizePhone(value, el, doc) {
        const raw = value.trim();
        if (!raw || !PHONE_VALUE_RE.test(raw))
            return value;
        const count = digitsOf$1(raw).length;
        if (count < 7 || count > 15)
            return value;
        const addon = findCountryAddon(el);
        const placeholder = (el.getAttribute("placeholder") ?? "").trim();
        if (!addon.found && !isPhoneField(el, doc))
            return value;
        const parsed = parseNumber(raw);
        if (!parsed || parsed.national === "")
            return value;
        const national = parsed.national;
        const local = `0${national}`;
        let preferred;
        if (addon.found) {
            if (addon.code !== null && addon.code !== "62")
                return value;
            preferred = national;
        }
        else if (placeholder.startsWith("+62")) {
            preferred = `+62${national}`;
        }
        else if (placeholder.startsWith("08")) {
            preferred = local;
        }
        else {
            return value;
        }
        const max = Number(el.maxLength);
        if (!(max > 0))
            return preferred;
        return [preferred, local, national].find((candidate) => candidate.length <= max) ?? preferred;
    }
    /** Nomor nasional dari deretan angka yang terbaca: tanpa 62 di depan (bila cukup panjang) dan tanpa nol di depan. */
    function nationalOf(digits) {
        return digits.startsWith("62") && digits.length >= 10 ? digits.slice(2) : digits.replace(/^0+/, "");
    }
    /**
     * Pembacaan ulang kolom telepon cocok dengan niat: deretan angkanya sama, atau sama sesudah kode negara dan nol di
     * depan dibuang ("0812" terbaca "+62 812"). Tidak peduli spasi, strip, atau kurung buatan topeng.
     */
    function phoneMatches(read, intent) {
        const have = digitsOf$1(typeof read === "string" ? read : "");
        const want = digitsOf$1(intent);
        if (!have || !want)
            return false;
        if (have === want)
            return true;
        const wantNational = nationalOf(want);
        return wantNational.length >= 3 && (nationalOf(have) === wantNational || have.endsWith(wantNational));
    }

    /**
     * Tunggu DOM tenang: selesai bila tidak ada mutasi selama `quietMs`, atau paling lama `maxMs`. Menggantikan tidur
     * tetap sesudah klik Lanjut/Lamar, karena SPA menggambar langkah baru dengan waktu yang tidak pasti.
     */
    const DEFAULT_SETTLE_QUIET_MS = 300;
    const DEFAULT_SETTLE_MAX_MS = 4000;
    const MAX_QUIET_MS = 2000;
    const MAX_WAIT_MS = 10_000;
    const clampMs = (value, fallback, min, max) => {
        const n = typeof value === "number" && Number.isFinite(value) ? value : fallback;
        return Math.min(max, Math.max(min, n));
    };
    const nowMs$2 = () => (typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now());
    /** Tunggu tambahan sesudah DOM tenang: pembaruan form yang ditunda timer pendek (validasi, format ulang) baru terlihat sesudahnya. */
    const VERIFY_GRACE_MS = 150;
    /** DOM dianggap tenang untuk verifikasi isian: lebih rapat dari `WAIT_SETTLE` antar langkah, karena yang dicari cuma efek lanjutan isian. */
    const VERIFY_SETTLE_QUIET_MS = 150;
    const VERIFY_SETTLE_MAX_MS = 1500;
    const sleepMs = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    /**
     * Tunggu DOM tenang lalu `graceMs` lagi. Dipakai sebelum membaca ulang isian yang baru ditulis, supaya reset terlambat,
     * format ulang topeng, dan validasi asinkron sempat terjadi lebih dulu.
     */
    async function settleThenGrace(doc, opts = {}) {
        const result = await waitForDomSettle(doc, { quietMs: opts.quietMs ?? VERIFY_SETTLE_QUIET_MS, maxMs: opts.maxMs ?? VERIFY_SETTLE_MAX_MS });
        const grace = clampMs(opts.graceMs, VERIFY_GRACE_MS, 0, 2000);
        if (grace > 0)
            await sleepMs(grace);
        return { settled: result.settled, waitedMs: result.waitedMs + grace };
    }
    function waitForDomSettle(doc, opts = {}) {
        const quietMs = clampMs(opts.quietMs, DEFAULT_SETTLE_QUIET_MS, 0, MAX_QUIET_MS);
        const maxMs = clampMs(opts.maxMs, DEFAULT_SETTLE_MAX_MS, quietMs, MAX_WAIT_MS);
        const startedAt = nowMs$2();
        return new Promise((resolve) => {
            let finished = false;
            let observer = null;
            let quietTimer = null;
            let maxTimer = null;
            const finish = (settled) => {
                if (finished)
                    return;
                finished = true;
                if (observer)
                    observer.disconnect();
                if (quietTimer)
                    clearTimeout(quietTimer);
                if (maxTimer)
                    clearTimeout(maxTimer);
                observer = null;
                quietTimer = null;
                maxTimer = null;
                resolve({ settled, waitedMs: Math.max(0, Math.round(nowMs$2() - startedAt)) });
            };
            const armQuiet = () => {
                if (finished)
                    return;
                if (quietTimer)
                    clearTimeout(quietTimer);
                quietTimer = setTimeout(() => finish(true), quietMs);
            };
            // Timer tenang dibuat lebih dulu: bila `maxMs` sama dengan `quietMs`, DOM yang tenang menang atas batas waktu.
            armQuiet();
            maxTimer = setTimeout(() => finish(false), maxMs);
            if (typeof MutationObserver === "function") {
                try {
                    const root = (doc.body ?? doc.documentElement);
                    if (root) {
                        observer = new MutationObserver(() => armQuiet());
                        observer.observe(root, { childList: true, subtree: true, attributes: true, characterData: true });
                    }
                }
                catch {
                    observer = null;
                }
            }
        });
    }

    /**
     * Menulis teks ke kolom isian seperti pengguna mengetik, supaya framework (React, Vue) dan topeng input (mask) melihat
     * perubahan lewat jalur yang sama dengan ketikan sungguhan. Tidak ada pembacaan ulang di sini: pemanggil memverifikasi
     * SESUDAH halaman tenang (lihat `fillControls.ts`), karena reset terlambat dan format ulang baru terlihat belakangan.
     */
    /** Tulis `value` lewat setter asli prototipe, melewati pembungkus `value` milik React pada instance. */
    function assignNativeValue(el, value) {
        const proto = el.tagName === "TEXTAREA"
            ? typeof HTMLTextAreaElement !== "undefined"
                ? HTMLTextAreaElement.prototype
                : undefined
            : typeof HTMLInputElement !== "undefined"
                ? HTMLInputElement.prototype
                : undefined;
        const descriptor = proto ? Object.getOwnPropertyDescriptor(proto, "value") : undefined;
        if (descriptor?.set) {
            descriptor.set.call(el, value);
        }
        else {
            el.value = value;
        }
    }
    const readValue = (el) => String(el.value ?? "");
    const collapse = (s) => s.replace(/\s+/g, " ").trim();
    function docFor(el, opts) {
        return opts?.doc ?? el.ownerDocument ?? (typeof document !== "undefined" ? document : null);
    }
    function hasFocus(doc, el) {
        if (doc.activeElement === el)
            return true;
        try {
            const root = el.getRootNode?.();
            return root?.activeElement === el;
        }
        catch {
            return false;
        }
    }
    function selectAll(el) {
        try {
            el.select?.();
        }
        catch {
            // Beberapa jenis input tidak mendukung select().
        }
        try {
            if (typeof el.setSelectionRange === "function")
                el.setSelectionRange(0, readValue(el).length);
        }
        catch {
            // type=email dan number melempar InvalidStateError.
        }
    }
    function makeInput(type, inputType, data, cancelable) {
        if (typeof InputEvent === "function")
            return new InputEvent(type, { bubbles: true, cancelable, composed: true, inputType, data });
        const ev = new Event(type, { bubbles: true, cancelable });
        ev.inputType = inputType;
        ev.data = data;
        return ev;
    }
    function makeKey(type, ch) {
        const code = /^[0-9]$/.test(ch) ? `Digit${ch}` : /^[a-zA-Z]$/.test(ch) ? `Key${ch.toUpperCase()}` : ch === " " ? "Space" : "";
        const key = ch === "\n" ? "Enter" : ch;
        if (typeof KeyboardEvent === "function")
            return new KeyboardEvent(type, { key, code, bubbles: true, cancelable: true, composed: true });
        const ev = new Event(type, { bubbles: true, cancelable: true });
        ev.key = key;
        ev.code = code;
        return ev;
    }
    /**
     * Ketik `value` karakter demi karakter: keydown, beforeinput, penulisan lewat setter asli + `InputEvent` bertipe
     * `insertText`, lalu keyup. Event yang dibatalkan (`preventDefault`, cara topeng angka menyaring tombol) berarti
     * karakter itu tidak masuk, persis seperti di browser. `maxLength` dihormati karena browser hanya menegakkannya untuk
     * ketikan pengguna, bukan penulisan lewat skrip.
     */
    function typeCharacters(el, value) {
        if (readValue(el) !== "") {
            assignNativeValue(el, "");
            el.dispatchEvent(makeInput("input", "deleteContentBackward", null, false));
        }
        const max = typeof el.maxLength === "number" && el.maxLength > 0 ? el.maxLength : Number.POSITIVE_INFINITY;
        for (const ch of value) {
            if (readValue(el).length >= max)
                break;
            const keyAccepted = el.dispatchEvent(makeKey("keydown", ch));
            if (keyAccepted !== false && el.dispatchEvent(makeInput("beforeinput", "insertText", ch, true)) !== false) {
                assignNativeValue(el, readValue(el) + ch);
                el.dispatchEvent(makeInput("input", "insertText", ch, false));
            }
            el.dispatchEvent(makeKey("keyup", ch));
        }
    }
    /**
     * Tulis `value` seperti pengguna: fokus, pilih semua isi lama, lalu `document.execCommand('insertText')` (browser
     * sendiri mengirim `beforeinput` dan `input`). Bila nilai tidak menempel (tanpa `execCommand`, kolom tidak benar-benar
     * fokus, atau topeng menolak), jatuh ke ketikan per karakter. Sesudahnya `change` lalu blur, yang memicu validasi form.
     */
    function commitText(el, value, opts = {}) {
        const doc = docFor(el, opts);
        const accept = opts.accept ?? ((read) => collapse(read) === collapse(value));
        const host = el;
        try {
            host.focus?.({ preventScroll: true });
        }
        catch {
            host.focus?.();
        }
        selectAll(el);
        let via = "execCommand";
        let took = false;
        if (!opts.forcePerChar && value !== "" && doc && typeof doc.execCommand === "function" && hasFocus(doc, el)) {
            try {
                took = doc.execCommand("insertText", false, value) === true && accept(readValue(el));
            }
            catch {
                took = false;
            }
        }
        if (!took) {
            via = "perchar";
            typeCharacters(el, value);
        }
        if (!opts.keepFocus) {
            el.dispatchEvent(new Event("change", { bubbles: true }));
            host.blur?.();
        }
        return { via, immediate: accept(readValue(el)) };
    }

    /**
     * Unggah berkas ke halaman, dengan bukti dari antarmuka halaman, bukan hanya `input.files.length`.
     *
     * `files.length` hanya membuktikan skrip kita menulis ke input. Komponen unggah modern (ant-design, react-dropzone)
     * baru menganggap berkas diterima bila mereka sendiri memprosesnya: daftar berkas muncul, nama berkas tampil, tombol
     * hapus muncul, atau input diganti. Tanpa itu, laporan "terpasang" bisa salah (CV tidak pernah terunggah).
     */
    const SAFE_CONTROL_ID_RE$1 = /^[A-Za-z0-9_-]{1,64}$/;
    function base64ToBytes(base64) {
        try {
            const raw = atob(base64);
            const bytes = new Uint8Array(raw.length);
            for (let i = 0; i < raw.length; i++)
                bytes[i] = raw.charCodeAt(i);
            return bytes;
        }
        catch {
            return null;
        }
    }
    /**
     * Pasang berkas ke input file lewat `DataTransfer`, lalu kirim `input` dan `change`. `dispatched`: kedua event terkirim tanpa
     * galat. `readback`: `input.files` berisi setidaknya satu berkas sesudahnya. Komponen unggah yang langsung mengambil berkas lalu
     * mengosongkan atau mengganti inputnya (SmartRecruiters) menghasilkan `dispatched: true, readback: false`: berkasnya bisa saja
     * sudah diterima halaman, jadi pemanggil mencari bukti di halaman sebelum menyatakan gagal.
     */
    function assignInputFileDetailed(input, file) {
        try {
            const dt = new DataTransfer();
            dt.items.add(file);
            input.files = dt.files;
            input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
            input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
        }
        catch {
            return { dispatched: false, readback: false };
        }
        return { dispatched: true, readback: (input.files?.length ?? 0) > 0 };
    }
    const UPLOAD_RE = /file|upload|unggah|pdf|resume|\bcv\b/i;
    const NOT_UPLOAD_RE = /profil|profile|tersimpan|saved/i;
    const TOGGLE_SELECTOR = 'input[type="radio"], [role="radio"], [role="tab"], [class*="segmented-item"], [class*="radio-button-wrapper"], [class*="radio-wrapper"], [class*="tabs-tab"], button[aria-pressed]';
    const SELECTED_CLASS_RE = /(?:^|\s)[\w-]*-(?:checked|selected|active)(?:\s|$)/;
    const DROPZONE_SELECTOR = '[class*="upload-drag"], [class*="dropzone"], [class*="Dropzone"], [class*="drop-zone"], [class*="drag-area"], [ondrop]';
    const DROPZONE_TEXT_RE = /seret|drag|drop|tarik/i;
    const REMOVE_RE = /remove|delete|hapus|buang|trash/i;
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const nowMs$1 = () => (typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now());
    const norm = (s) => (s ?? "").replace(/\s+/g, " ").trim().toLowerCase();
    const isFileInput = (el) => !!el && el.tagName.toLowerCase() === "input" && (el.getAttribute("type") ?? "").toLowerCase() === "file";
    /** Input file tidak terlihat: `display:none`, atau tanpa kotak tata letak. */
    const inputHidden = (el) => !isShown(el) || !hasLayout(el);
    function ancestorAt(el, levels) {
        let cur = el;
        for (let i = 0; i < levels; i++) {
            const up = parentOrHost(cur);
            if (!up || up.tagName.toLowerCase() === "body" || up.tagName.toLowerCase() === "html")
                break;
            cur = up;
        }
        return cur;
    }
    function formRootOf(el) {
        try {
            return el.closest?.("form") ?? null;
        }
        catch {
            return null;
        }
    }
    // ---------- Sumber CV: radio atau tab "Unggah file" ----------
    function toggleLabel(doc, el) {
        if (el.tagName.toLowerCase() === "input") {
            const id = el.getAttribute("id");
            if (id) {
                try {
                    const fromFor = scopeOf(el, doc).querySelector(`label[for="${id}"]`)?.textContent;
                    if (fromFor)
                        return fromFor;
                }
                catch {
                    // Lanjut ke label pembungkus.
                }
            }
            return el.closest?.("label")?.textContent ?? el.value ?? "";
        }
        return (el.textContent ?? "") || el.getAttribute("aria-label") || "";
    }
    function toggleOn(el) {
        if (el.checked === true)
            return true;
        if (["aria-checked", "aria-selected", "aria-pressed"].some((a) => el.getAttribute(a) === "true"))
            return true;
        return SELECTED_CLASS_RE.test(el.getAttribute("class") ?? "");
    }
    /**
     * Pilihan "unggah file" untuk sumber CV di dekat input yang tersembunyi: radio, tab, atau segmen di formulir atau
     * wadah yang sama dengan labelnya cocok /file|upload|unggah|pdf|resume|cv/ dan bukan /profil|tersimpan/. `hintGroupId`
     * (grup radio yang ditandai pembaca formulir `cvSourceUpload`) dicari lebih dulu.
     */
    function findUploadToggle(doc, input, hintGroupId) {
        const matches = (cands) => cands.filter((c) => {
            const label = norm(toggleLabel(doc, c));
            return label !== "" && UPLOAD_RE.test(label) && !NOT_UPLOAD_RE.test(label);
        });
        if (hintGroupId && SAFE_CONTROL_ID_RE$1.test(hintGroupId)) {
            let group = [];
            try {
                group = findAllByAttr(doc, "data-applify-rg", hintGroupId);
            }
            catch {
                group = [];
            }
            const hit = matches(group)[0];
            if (hit)
                return { toggle: hit, scope: ancestorAt(input, 3), alreadyOn: toggleOn(hit) };
        }
        let level = parentOrHost(input);
        for (let depth = 0; level && depth < 6; depth++, level = parentOrHost(level)) {
            let cands = [];
            try {
                cands = deepQueryAll(level, TOGGLE_SELECTOR);
            }
            catch {
                cands = [];
            }
            // Pembungkus radio (`label`/`div`) yang memuat input radio diwakili inputnya sendiri.
            const direct = cands.filter((c) => c.tagName.toLowerCase() === "input" || !cands.some((o) => o !== c && o.tagName.toLowerCase() === "input" && c.contains?.(o)));
            const hits = matches(direct);
            if (hits.length === 0)
                continue;
            const on = hits.find(toggleOn);
            return { toggle: on ?? hits[0], scope: level, alreadyOn: Boolean(on) };
        }
        return null;
    }
    const filenameStem = (filename) => norm(filename.replace(/\.[A-Za-z0-9]{1,6}$/, ""));
    function snapshotUi(scope, stem) {
        const q = (selector) => {
            try {
                return deepQueryAll(scope, selector);
            }
            catch {
                return [];
            }
        };
        let stemHit = false;
        if (stem.length >= 3) {
            stemHit = norm(scope.textContent).includes(stem);
            if (!stemHit)
                stemHit = q("[title], [aria-label]").some((e) => norm(e.getAttribute("title")).includes(stem) || norm(e.getAttribute("aria-label")).includes(stem));
        }
        const filesAttr = q("[files]")
            .map((e) => norm(e.getAttribute("files")))
            .filter(Boolean)
            .join("|");
        const filesHit = stem.length >= 3 && filesAttr.includes(stem);
        if (filesHit)
            stemHit = true;
        const removes = q('button, [role="button"], a, [class*="remove"], [class*="delete"], [class*="trash"]').filter((e) => {
            const label = `${e.getAttribute("aria-label") ?? ""} ${e.getAttribute("title") ?? ""} ${e.getAttribute("class") ?? ""} ${e.textContent ?? ""}`;
            return REMOVE_RE.test(label) && isRendered(e);
        });
        return {
            stemHit,
            items: q('[class*="upload-list-item"], [class*="file-list-item"], [class*="uploaded-file"]').filter(isRendered).length,
            removes: removes.length,
            progress: q('progress, [role="progressbar"], [class*="progress"]').filter(isRendered).length,
            filesAttr,
            filesHit,
        };
    }
    const improved = (before, after) => (after.stemHit && !before.stemHit) ||
        after.items > before.items ||
        after.removes > before.removes ||
        after.progress > before.progress ||
        // Berkas bernama sama sudah ada dari putaran atau lamaran sebelumnya: unggahan baru tetap mengganti isi `files` (fileId baru).
        (after.filesHit && after.filesAttr !== before.filesAttr);
    /** Nama berkas tanpa ekstensi yang terlalu umum untuk dijadikan bukti ("resume", "cv"): cocok dengan label kolom, bukan dengan chip berkas. */
    const GENERIC_STEM_RE = /^(?:resume|cv|curriculum vitae|cover[ _-]?letter|transcript|portfolio|document|dokumen|file|berkas|lampiran|attachment|upload)$/;
    /** Nama berkas (tanpa ekstensi) yang cukup khas untuk dicari di halaman, atau "" bila kosong, terlalu pendek, atau generik. */
    function distinctiveStem(filename) {
        const stem = filenameStem(typeof filename === "string" ? filename : "");
        return stem.length >= 3 && !GENERIC_STEM_RE.test(stem) ? stem : "";
    }
    const isLive = (el) => !!el && el.isConnected !== false;
    /**
     * Halaman menampilkan nama berkas: chip nama berkas, atau elemen mana pun di `scopes` (tab, formulir, atau wadah input) yang
     * teksnya memuat nama itu. Wadah yang sudah lepas dari dokumen (diganti halaman) dilewati; tanpa wadah hidup, seluruh `body`.
     */
    function pageShowsFile(doc, scopes, stem) {
        if (stem.length < 3)
            return false;
        const roots = scopes.filter(isLive);
        const fallback = doc.body ?? null;
        const targets = roots.length > 0 ? roots : fallback ? [fallback] : [];
        return targets.some((root) => snapshotUi(root, stem).stemHit);
    }
    // ---------- Ingatan unggahan per dokumen ----------
    /**
     * Nama berkas yang berhasil kita pasang di dokumen ini. Dipakai putaran kedua (isi ulang, baca ulang) untuk TIDAK memasang ulang
     * berkas yang masih tampil di halaman. Nama yang kebetulan sudah tampil sebelum kita memasang apa pun (mis. CV profil yang
     * namanya sama) tidak termasuk: hanya yang pernah kita pasang sendiri.
     */
    const attachedEarlier = new WeakMap();
    function rememberAttachedFile(doc, filename) {
        const name = norm(typeof filename === "string" ? filename : "");
        if (!name)
            return;
        const set = attachedEarlier.get(doc) ?? new Set();
        set.add(name);
        attachedEarlier.set(doc, set);
    }
    const wasAttachedEarlier = (doc, filename) => attachedEarlier.get(doc)?.has(norm(typeof filename === "string" ? filename : "")) === true;
    /**
     * Putaran kedua: berkas ini sudah kita pasang sebelumnya dan namanya masih tampil di halaman (chip nama berkas atau elemen
     * saudara bernama itu), jadi tidak dipasang ulang dan dihitung terpasang. `input` null = input file sudah hilang dari halaman,
     * yang terjadi saat komponen unggah menggantinya dengan chip berkas; wadah yang dicari kemudian seluruh halaman.
     */
    function alreadyAttachedOnPage(doc, filename, input) {
        if (!wasAttachedEarlier(doc, filename))
            return false;
        const stem = distinctiveStem(filename);
        if (!stem)
            return false;
        return pageShowsFile(doc, input ? [ancestorAt(input, 3), formRootOf(input)] : [], stem);
    }
    /** Input file yang tadi diisi sudah tidak ada di halaman, atau halaman menggantinya dengan elemen lain (id kontrol bergeser). */
    function inputReplaced(doc, controlId, target) {
        try {
            return target.isConnected === false || findControlByCid(doc, controlId) !== target;
        }
        catch {
            return false;
        }
    }
    /** Catat keadaan halaman SEBELUM berkas dipasang, supaya sesudahnya hanya perubahan yang dihitung sebagai bukti. */
    function watchUpload(doc, controlId, target, filename) {
        const stem = filenameStem(String(filename || ""));
        const scope = ancestorAt(target, 3);
        const form = formRootOf(target);
        const before = snapshotUi(scope, stem);
        const beforeForm = form && form !== scope ? snapshotUi(form, stem) : null;
        return {
            hasEvidence: () => {
                if (inputReplaced(doc, controlId, target))
                    return true;
                if (improved(before, snapshotUi(scope, stem)))
                    return true;
                return beforeForm !== null && form !== null && improved(beforeForm, snapshotUi(form, stem));
            },
        };
    }
    /** Dropzone terdekat: wadah unggah seret, `react-dropzone`, atau elemen ber-`ondrop`/bertuliskan "seret". */
    function findDropzone(input) {
        let level = input;
        for (let depth = 0; level && depth < 7; depth++, level = parentOrHost(level)) {
            let matched = null;
            try {
                if (level.matches?.(DROPZONE_SELECTOR))
                    matched = level;
                matched = matched ?? deepQueryAll(level, DROPZONE_SELECTOR).find(isShown) ?? null;
            }
            catch {
                matched = null;
            }
            if (matched)
                return matched;
        }
        level = parentOrHost(input);
        for (let depth = 0; level && depth < 5; depth++, level = parentOrHost(level)) {
            let found = null;
            try {
                found =
                    deepQueryAll(level, '[class*="upload"], [class*="drop"], [role="button"]').find((e) => {
                        const text = (e.textContent ?? "").replace(/\s+/g, " ").trim();
                        return text.length > 0 && text.length <= 160 && DROPZONE_TEXT_RE.test(text) && isShown(e);
                    }) ?? null;
            }
            catch {
                found = null;
            }
            if (found)
                return found;
        }
        return null;
    }
    function dropFile(zone, file) {
        try {
            const dt = new DataTransfer();
            dt.items.add(file);
            for (const type of ["dragenter", "dragover", "drop"]) {
                const init = { bubbles: true, cancelable: true, composed: true, dataTransfer: dt };
                let ev;
                if (typeof DragEvent === "function") {
                    ev = new DragEvent(type, init);
                }
                else {
                    ev = new Event(type, { bubbles: true, cancelable: true, composed: true });
                    Object.defineProperty(ev, "dataTransfer", { value: dt });
                }
                zone.dispatchEvent(ev);
            }
            return true;
        }
        catch {
            return false;
        }
    }
    /** Tunggu sampai `check()` benar, paling lama `ms`. Dicek lebih dulu, lalu tiap `pollMs`. */
    async function waitFor(check, ms, pollMs) {
        const deadline = nowMs$1() + ms;
        for (;;) {
            if (check())
                return true;
            if (nowMs$1() >= deadline)
                return false;
            await sleep(pollMs);
        }
    }
    /**
     * Pasang berkas ke input file dengan bukti antarmuka. Per berkas:
     *   1. Input tersembunyi dan ada pilihan sumber CV ("Unggah file" lawan "CV profil"): pilihan itu diklik
     *      (`humanClick`, penjaga tombol kirim berlaku), halaman ditunggu tenang, input dicari ulang.
     *   2. Berkas dipasang (`input` dan `change`, bubbles + composed).
     *   3. Bukti dicari sampai `evidenceMs`: nama berkas, daftar unggahan, tombol hapus, bilah kemajuan, atau input yang
     *      diganti halaman. Tanpa bukti, berkas dijatuhkan ke dropzone terdekat (dragenter, dragover, drop), lalu dicari lagi.
     *   4. Tetap tanpa bukti: `unverified` alasan `no_ui_evidence` (dilaporkan sebagai berkas yang harus diunggah manual).
     */
    async function attachFilesAsync(doc, files, opts = {}) {
        const attached = emptyFilesAttached();
        const attachedControlIds = [];
        const failed = [];
        const log = [];
        if (!Array.isArray(files))
            return { attached, attachedControlIds, failed, log };
        const evidenceMs = Math.max(0, opts.evidenceMs ?? 4000);
        const pollMs = Math.max(10, opts.pollMs ?? 100);
        const push = (entry) => {
            if (log.length < MAX_ACTION_LOG)
                log.push(entry);
        };
        for (const file of files) {
            if (!isFileKind(file?.kind))
                continue;
            const kind = file.kind;
            const ref = typeof file.controlId === "string" && SAFE_CONTROL_ID_RE$1.test(file.controlId) ? file.controlId : "invalid";
            const fail = (result, reason) => {
                if (!failed.includes(kind))
                    failed.push(kind);
                push({ ref, kind: "file", action: "attach", result, reason });
            };
            // Berkas dianggap terpasang: dicatat sekali, dan namanya diingat supaya putaran berikutnya tidak memasangnya ulang.
            const markAttached = (result, reason) => {
                attached[kind] = true;
                attachedControlIds.push(file.controlId);
                rememberAttachedFile(doc, file.filename);
                push({ ref, kind: "file", action: "attach", result, ...(reason ? { reason } : {}) });
            };
            if (typeof DataTransfer === "undefined" || typeof File === "undefined") {
                fail("unverified", "no_datatransfer");
                continue;
            }
            if (ref === "invalid" || attachedControlIds.includes(file.controlId)) {
                fail("skipped", ref === "invalid" ? "bad_control_id" : "duplicate_input");
                continue;
            }
            let input = null;
            try {
                input = findControlByCid(doc, file.controlId);
            }
            catch {
                input = null;
            }
            if (!isFileInput(input)) {
                // Input file sudah hilang karena komponen unggah menggantinya dengan chip nama berkas, dan berkas ini kita pasang
                // di putaran sebelumnya: itu bukan kegagalan.
                if (!input && alreadyAttachedOnPage(doc, file.filename, null)) {
                    markAttached("verified", "already_shown");
                    continue;
                }
                fail("missing", input ? "not_file_input" : "element_missing");
                continue;
            }
            const bytes = typeof file.base64 === "string" ? base64ToBytes(file.base64) : null;
            if (!bytes || bytes.length === 0) {
                fail("unverified", "bad_payload");
                continue;
            }
            const skip = skipReason(input);
            if (skip) {
                fail("skipped", skip);
                continue;
            }
            // Putaran kedua: berkas yang kita pasang tadi masih tampil di halaman, jadi tidak dipasang ulang.
            if (alreadyAttachedOnPage(doc, file.filename, input)) {
                markAttached("verified", "already_shown");
                continue;
            }
            // 1. Input tersembunyi: pilih sumber "unggah file" bila halaman menawarkannya.
            if (inputHidden(input)) {
                const hint = typeof file.sourceControlId === "string" ? file.sourceControlId : null;
                const toggle = findUploadToggle(doc, input, hint);
                if (toggle && !toggle.alreadyOn) {
                    if (humanClick(toggle.toggle)) {
                        await settleThenGrace(doc, { quietMs: 120, maxMs: 1200, graceMs: 80 });
                        let again = null;
                        try {
                            again = findControlByCid(doc, file.controlId);
                        }
                        catch {
                            again = null;
                        }
                        if (!isFileInput(again)) {
                            // Halaman membuat input baru sesudah pilihan: ambil input file di wadah yang sama dan tandai dengan id lama.
                            again = deepQueryAll(toggle.scope, 'input[type="file"]')[0] ?? null;
                            if (isFileInput(again))
                                again.setAttribute("data-applify-cid", file.controlId);
                        }
                        if (!isFileInput(again)) {
                            fail("missing", "element_missing");
                            continue;
                        }
                        input = again;
                    }
                }
            }
            // 2. Pasang berkas.
            const target = input;
            const make = () => new File([bytes], String(file.filename || kind), { type: String(file.mimeType || "application/octet-stream") });
            const watch = watchUpload(doc, file.controlId, target, file.filename);
            // Satu jendela `ms` per percobaan, sudah termasuk menunggu DOM tenang.
            const provenWithin = async (ms) => {
                const started = nowMs$1();
                await settleThenGrace(doc, { quietMs: 100, maxMs: Math.max(100, Math.min(600, ms)), graceMs: 50 });
                return waitFor(() => watch.hasEvidence(), Math.max(0, ms - (nowMs$1() - started)), pollMs);
            };
            // Komponen unggah yang mengambil berkas lalu mengosongkan atau mengganti inputnya (SmartRecruiters) membuat bacaan ulang
            // `input.files` kosong walau berkasnya sudah diterima. Setelah event terkirim, bukti di halaman yang menentukan.
            const landedWithin = async () => {
                if (!(await provenWithin(Math.min(evidenceMs, 1500))))
                    return null;
                return inputReplaced(doc, file.controlId, target) ? "input_replaced" : "page_shows_file";
            };
            let result = "verified";
            const first = assignInputFileDetailed(target, make());
            if (!first.readback) {
                const landed = first.dispatched ? await landedWithin() : null;
                if (landed) {
                    markAttached("verified", landed);
                    continue;
                }
                result = "retried";
                const second = assignInputFileDetailed(target, make());
                if (!second.readback) {
                    const landedAgain = second.dispatched ? await landedWithin() : null;
                    if (landedAgain) {
                        markAttached("retried", landedAgain);
                        continue;
                    }
                    fail("unverified", "readback_mismatch");
                    continue;
                }
            }
            // 3. Bukti antarmuka.
            let proven = await provenWithin(evidenceMs);
            if (!proven) {
                const zone = findDropzone(target);
                if (zone && dropFile(zone, make())) {
                    result = "retried";
                    proven = await provenWithin(evidenceMs);
                }
            }
            if (!proven) {
                fail("unverified", "no_ui_evidence");
                continue;
            }
            markAttached(result);
        }
        return { attached, attachedControlIds, failed, log };
    }

    /**
     * Frasa konfirmasi. Dua yang terakhir bawaan Google Forms ("Your response has been recorded", "Jawaban Anda telah
     * direkam"); pemilik formulir boleh mengganti pesannya, jadi tanpa kecocokan hasilnya tetap `submit_unverified`.
     */
    const CONFIRM_RE = /\b(application\s+(?:has\s+been\s+)?(?:received|submitted)|thank\s+you\s+for\s+applying|thank\s+you\s+for\s+your\s+application|lamaran\s+(?:anda\s+)?(?:berhasil\s+)?(?:terkirim|diterima)|berhasil\s+terkirim|terima\s+kasih\s+telah\s+melamar|your\s+response\s+has\s+been\s+recorded|jawaban\s+anda\s+telah\s+direkam)\b/i;
    /** Kalimat yang meminta kode (kata Greenhouse: "A verification code was sent ... enter the 8-character code"). Huruf kecil. */
    const CODE_PROMPT_RES = [
        /\b(?:verification|security|confirmation) code (?:was|has been|is being|will be) sent\b/,
        /\benter the \d+[- ](?:character|digit|letter)s? (?:security |verification )?code\b/,
        /\bsecurity code\b/,
        /\bwe(?:'ve| have)? sent (?:you )?an? (?:verification |security |confirmation )?code\b/,
        /\bkode (?:verifikasi|keamanan|konfirmasi)\b/,
    ];
    const CODE_LABEL_RE = /\b(?:code|kode)\b/i;
    /** Kolom yang memuat kata "code" tetapi bukan kode keamanan. */
    const NOT_CODE_LABEL_RE = /\b(?:zip|postal|post|postcode|country|area|dial|dialing|phone|promo|promotion|promotional|referral|coupon|campaign|currency|pos|negara|telepon)\b/i;
    /** Kode yang dipecah jadi kotak satu karakter: paling sedikit dan paling banyak kotaknya. */
    const MIN_CODE_BOXES = 4;
    const MAX_CODE_BOXES = 12;
    /** Banner yang mengajak memperbaiki isian. Dipakai hanya untuk pesan baru dari penanda galat (bukan `role="alert"` polos). */
    const VALIDATION_BANNER_RE = /\b(?:correct|fix|invalid|required|errors?|incorrect|mistakes?|perbaiki|periksa|wajib|tidak valid|salah|gagal|harus diisi)\b/i;
    const MAX_FIELDS_SCANNED = 300;
    /** Keadaan sebelum klik kirim terakhir di dokumen ini. Hidup selama skrip konten hidup (satu per frame). */
    let baseline = null;
    const bodyTextOf = (doc) => (doc.body?.innerText ?? doc.body?.textContent ?? "").slice(0, 5000);
    const mentionsCodePrompt = (doc) => {
        const text = bodyTextOf(doc).toLowerCase().replace(/\s+/g, " ");
        return CODE_PROMPT_RES.some((re) => re.test(text));
    };
    function answerFields(doc) {
        try {
            return deepQueryAll(doc, "input, textarea, select")
                .filter((el) => {
                const type = (el.getAttribute("type") ?? "").toLowerCase();
                return !["hidden", "submit", "button", "image", "reset", "search"].includes(type) && isShown(el);
            })
                .slice(0, MAX_FIELDS_SCANNED);
        }
        catch {
            return [];
        }
    }
    /** Kolom terlihat yang kini bertanda galat. */
    function flaggedFields(doc) {
        return answerFields(doc).filter((el) => {
            try {
                return extractFieldErrorMessage(el) !== null;
            }
            catch {
                return false;
            }
        });
    }
    function safeValidationMessages(doc) {
        try {
            return collectValidationErrors(doc, 50);
        }
        catch {
            return [];
        }
    }
    /** Catat keadaan halaman sesaat SEBELUM tombol kirim yang diotorisasi diklik. Tidak pernah melempar galat. */
    function captureSubmitBaseline(doc) {
        try {
            baseline = { codePrompt: mentionsCodePrompt(doc), messages: new Set(safeValidationMessages(doc)), flagged: new Set(flaggedFields(doc)) };
        }
        catch {
            baseline = null;
        }
    }
    /** Kotak kode keamanan yang terlihat dan kosong: satu kolom berlabel kode, atau 4 sampai 12 kotak satu karakter. */
    function hasEmptyCodeInput(doc) {
        const fields = answerFields(doc).filter((el) => el.tagName.toLowerCase() === "input" && !String(el.value ?? "").trim());
        const labelsFor = new Map();
        try {
            for (const label of deepQueryAll(doc, "label")) {
                const target = label.getAttribute("for");
                if (target)
                    labelsFor.set(target, label.textContent ?? "");
            }
        }
        catch {
            // Tanpa label: pakai atribut kolom saja.
        }
        const named = fields.some((el) => {
            const id = el.getAttribute("id") ?? "";
            const text = [el.getAttribute("aria-label"), el.getAttribute("name"), id, el.getAttribute("placeholder"), el.getAttribute("autocomplete"), labelsFor.get(id)]
                .filter(Boolean)
                .join(" ");
            return CODE_LABEL_RE.test(text) && !NOT_CODE_LABEL_RE.test(text);
        });
        if (named)
            return true;
        const boxes = fields.filter((el) => Number(el.getAttribute("maxlength")) === 1);
        return boxes.length >= MIN_CODE_BOXES && boxes.length <= MAX_CODE_BOXES;
    }
    function inspectSubmission(doc, submitControlId) {
        const bodyText = bodyTextOf(doc);
        const controlPresent = submitControlId ? Boolean(findControlByCid(doc, submitControlId)) : false;
        const done = (outcome, validationMessages = 0) => ({ outcome, validationMessages, controlPresent });
        if (CONFIRM_RE.test(bodyText))
            return done("submitted");
        const locationPathAndQuery = `${doc.location?.pathname ?? ""}${doc.location?.search ?? ""}`;
        if (!controlPresent && /thank|confirm|submitted|terkirim|success/i.test(locationPathAndQuery))
            return done("submitted");
        const before = baseline;
        try {
            if (mentionsCodePrompt(doc) && !before?.codePrompt && hasEmptyCodeInput(doc))
                return done("needs_code");
            if (controlPresent) {
                const newFlagged = flaggedFields(doc).filter((el) => !before?.flagged.has(el));
                const newBanners = safeValidationMessages(doc).filter((m) => !before?.messages.has(m) && VALIDATION_BANNER_RE.test(m));
                const count = newFlagged.length + newBanners.length;
                if (count > 0)
                    return done("validation_error", count);
            }
        }
        catch {
            // Pembacaan yang gagal tidak boleh mengubah hasil: tetap tidak terverifikasi.
        }
        return done("submit_unverified");
    }

    function setNativeInputValue(el, value) {
        assignNativeValue(el, value);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    /**
     * Penulisan kedua yang lebih lengkap bila pembacaan ulang tidak cocok: fokus, setter asli, `InputEvent` bertipe
     * `insertText` (dibaca beberapa input bertopeng), `change`, lalu blur.
     */
    function setNativeInputValueFull(el, value) {
        el.focus?.();
        assignNativeValue(el, value);
        const input = typeof InputEvent === "function"
            ? new InputEvent("input", { bubbles: true, inputType: "insertText", data: value })
            : new Event("input", { bubbles: true });
        el.dispatchEvent(input);
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.blur?.();
    }
    const optionValueOf = (o) => (o.value || o.getAttribute?.("value") || "").trim();
    const optionDisabled = (o) => o.disabled === true || (o.getAttribute?.("disabled") ?? null) !== null;
    /**
     * Opsi `<select>` asli yang boleh dipilih untuk jawaban `target`, dengan aturan yang sama seperti dropdown kustom
     * (`pickOption`): persis (teks atau nilai), atau satu-satunya opsi yang diawali jawaban pada batas kata.
     */
    function findSelectOption(selectEl, target) {
        const options = Array.from(selectEl.options ?? []).filter((o) => !optionDisabled(o));
        const pick = pickOption(options.map((o) => o.textContent ?? ""), target, options.map(optionValueOf));
        return { option: pick.index >= 0 ? options[pick.index] : null, ambiguous: pick.ambiguous };
    }
    /** Pilih `matched`. `full` menambah fokus, event `input`, dan blur untuk percobaan kedua. */
    function writeSelectOption(selectEl, matched, full) {
        if (full)
            selectEl.focus?.();
        selectEl.value = optionValueOf(matched) || (matched.textContent ?? "").trim();
        matched.selected = true;
        if (full)
            selectEl.dispatchEvent(new Event("input", { bubbles: true }));
        selectEl.dispatchEvent(new Event("change", { bubbles: true }));
        if (full)
            selectEl.blur?.();
    }
    /** Baca ulang: opsi yang terpilih di halaman memang `matched`. */
    function isOptionSelected(selectEl, matched) {
        const idx = selectEl.selectedIndex;
        if (typeof idx === "number")
            return idx >= 0 && Array.from(selectEl.options ?? [])[idx] === matched;
        return matched.selected === true;
    }
    const OPTION_SELECTOR = '[role="option"], [data-option], [class*="select__option"], [class*="select-item-option"]';
    /** Item opsi ant/rc-select itu sendiri, bukan anaknya (`...-option-content`, `...-option-state`). */
    const SELECT_ITEM_OPTION_RE = /(?:^|\s)[\w-]*select-item-option(?:\s|$)/;
    const OPTION_DISABLED_CLASS_RE = /(?:^|\s)[\w-]*option-disabled(?:\s|$)/;
    const normalizeOptionText = (s) => (s ?? "").replace(/\s+/g, " ").trim().toLowerCase();
    /**
     * Indeks opsi yang boleh diklik untuk jawaban `target` (`index` -1 bila tidak ada yang aman), dan apakah penyebabnya
     * ambigu (lebih dari satu kandidat) dan bukan karena tidak ada yang cocok.
     *
     * Aturan (setelah spasi dan huruf besar-kecil dinormalkan):
     *   1. Kecocokan persis. Tepat satu opsi: dipilih. Lebih dari satu: ambigu, -1.
     *   2. Tanpa kecocokan persis: kecocokan unik, yaitu tepat satu opsi yang DIAWALI jawaban dan dilanjutkan batas
     *      kata (spasi, koma, kurung, dll), misalnya "United States" untuk "United States of America".
     *      Dua opsi atau lebih: -1.
     *   3. Selain itu -1. Tidak ada `includes()` bebas: "male" tidak boleh cocok dengan "Female", dan "no" tidak
     *      boleh cocok dengan "Yes, I have no restrictions".
     */
    function pickOption(optionTexts, target, optionValues) {
        const t = normalizeOptionText(target);
        if (!t)
            return { index: -1, ambiguous: false };
        const norm = optionTexts.map(normalizeOptionText);
        const exact = [];
        const prefixed = [];
        norm.forEach((text, i) => {
            // `optionValues` (nilai atribut `<option>`) hanya dihitung untuk kecocokan persis, bukan awalan.
            if (text === t || normalizeOptionText(optionValues?.[i]) === t)
                exact.push(i);
            else if (text.startsWith(t) && !/[\p{L}\p{N}]/u.test(text.charAt(t.length)))
                prefixed.push(i);
        });
        if (exact.length > 0)
            return exact.length === 1 ? { index: exact[0], ambiguous: false } : { index: -1, ambiguous: true };
        if (prefixed.length > 1)
            return { index: -1, ambiguous: true };
        return { index: prefixed.length === 1 ? prefixed[0] : -1, ambiguous: false };
    }
    /** Indeks opsi yang aman untuk `target`, atau -1. Lihat `pickOption`. */
    function pickUniqueOption(optionTexts, target, optionValues) {
        return pickOption(optionTexts, target, optionValues).index;
    }
    /**
     * Simpul cermin 0-ukuran: rc-select menaruh ~3 `[role=option]` di listbox setinggi dan selebar 0 hanya untuk pembaca
     * layar. Isinya sama dengan nilai terpilih, tetapi mengkliknya tidak memilih apa pun.
     */
    function inZeroSizeListbox(opt) {
        for (let n = parentOrHost(opt); n; n = parentOrHost(n)) {
            if ((n.getAttribute("role") ?? "").toLowerCase() !== "listbox")
                continue;
            return !hasLayout(n);
        }
        return false;
    }
    const isOptionNode = (el) => {
        const cls = el.getAttribute("class") ?? "";
        if (cls.includes("select-item-option") && !SELECT_ITEM_OPTION_RE.test(cls) && (el.getAttribute("role") ?? "") !== "option")
            return false;
        return true;
    };
    /** Opsi yang bisa diklik di bawah `root`: kotak nyata, bukan cermin 0-ukuran, dan bukan anak item opsi. */
    function queryOptionNodes(root) {
        return deepQueryAll(root, OPTION_SELECTOR).filter((o) => isOptionNode(o) && hasLayout(o) && !inZeroSizeListbox(o));
    }
    const shownOptions = (root) => queryOptionNodes(root).filter(isShown);
    const optionDisabledNode = (o) => o.getAttribute("aria-disabled") === "true" || OPTION_DISABLED_CLASS_RE.test(o.getAttribute("class") ?? "");
    const optionLabel = (o) => (o.textContent ?? "").replace(/\s+/g, " ").trim();
    /** Listbox (atau wadah menu) tempat opsi berada. */
    function optionContainer(opt) {
        for (let n = opt.parentElement; n; n = n.parentElement) {
            const role = (n.getAttribute("role") ?? "").toLowerCase();
            if (role === "listbox" || /select__menu|menu-list/.test(n.getAttribute("class") ?? ""))
                return n;
        }
        return opt.parentElement ?? opt;
    }
    function treeDistance(a, b) {
        const up = new Map();
        let steps = 0;
        for (let n = a; n; n = n.parentElement)
            up.set(n, steps++);
        steps = 0;
        for (let n = b; n; n = n.parentElement, steps++) {
            const hit = up.get(n);
            if (hit !== undefined)
                return hit + steps;
        }
        return Number.POSITIVE_INFINITY;
    }
    /** Listbox yang dirujuk kontrol ini lewat `aria-controls` atau `aria-owns` (pada kontrol atau input di dalamnya). */
    function referencedListbox(doc, hosts) {
        for (const host of hosts) {
            if (!host)
                continue;
            for (const attr of ["aria-controls", "aria-owns"]) {
                for (const id of (host.getAttribute(attr) ?? "").split(/\s+/).filter(Boolean)) {
                    const found = elementByIdNear(host, doc, id);
                    if (found)
                        return found;
                }
            }
        }
        return null;
    }
    /**
     * Tanpa `aria-controls`/`aria-owns`: satu-satunya menu yang BARU muncul sesudah klik (opsi yang tadinya belum
     * ada atau belum terlihat). Menu yang sudah terlihat sebelum klik milik pertanyaan lain dan tidak disentuh.
     * Bila beberapa menu baru muncul, yang paling dekat dengan kontrol di pohon DOM dipakai, asal tidak seri.
     */
    function newlyOpenedOptions(doc, control, shownBefore) {
        const fresh = shownOptions(doc).filter((o) => !shownBefore.has(o));
        if (fresh.length === 0)
            return null;
        const containers = new Set(fresh.map(optionContainer));
        let chosen = null;
        if (containers.size === 1) {
            chosen = [...containers][0];
        }
        else {
            let best = Number.POSITIVE_INFINITY;
            let tie = false;
            for (const c of containers) {
                const d = treeDistance(control, c);
                if (d < best) {
                    best = d;
                    chosen = c;
                    tie = false;
                }
                else if (d === best) {
                    tie = true;
                }
            }
            if (tie)
                return null;
        }
        return chosen ? shownOptions(chosen) : null;
    }
    const TITLE_SELECTOR = '[class*="modal-title"], [class*="modal-header"], [class*="dialog-title"], [class*="DialogTitle"], h1, h2, h3, [role="heading"]';
    /** Dialog (modal) yang memuat kontrol ini, atau null. `role=dialog`, `aria-modal`, atau elemen `<dialog>`. */
    function enclosingDialog(el) {
        for (let n = parentOrHost(el); n; n = parentOrHost(n)) {
            const role = (n.getAttribute("role") ?? "").toLowerCase();
            if (role === "dialog" || role === "alertdialog" || n.getAttribute("aria-modal") === "true" || n.tagName.toLowerCase() === "dialog")
                return n;
        }
        return null;
    }
    const RC_SELECT_WRAPPER = '[class*="ant-select"], [class*="rc-select"]';
    /** Input milik ant/rc-select: tandai `readonly` dan `unselectable` sebagai gaya, bukan status hanya-baca. */
    function isRcSelectInput(el) {
        if (el.getAttribute("unselectable") === "on")
            return true;
        try {
            return Boolean(el.closest?.(RC_SELECT_WRAPPER));
        }
        catch {
            return false;
        }
    }
    /**
     * Alasan dropdown kustom tidak disentuh. Sama dengan `skipReason`, kecuali input ant/rc-select: input pencarinya
     * `readonly` selama tertutup (dan selamanya bila tanpa `showSearch`) padahal dropdown-nya bisa dipilih. Hanya
     * `aria-readonly="true"`, `disabled`, dan kelas `ant-select-disabled` yang menolak.
     */
    function comboboxSkipReason(el) {
        const reason = skipReason(el);
        if (reason === "readonly" && el.getAttribute("aria-readonly") !== "true" && isRcSelectInput(el))
            return null;
        if (reason)
            return reason;
        try {
            if (el.closest?.('[class*="select-disabled"]'))
                return "disabled";
        }
        catch {
            // Lingkungan tanpa closest.
        }
        return null;
    }
    const isExpanded = (el, input) => [el, input].some((n) => n?.getAttribute?.("aria-expanded") === "true");
    /**
     * Klik di tempat netral dalam dialog (judul): menutup dropdown yang mendengarkan klik di luar, tanpa Escape yang akan
     * menutup dialognya. Tanpa gulir (judul biasanya di luar badan modal yang menggulir) dan tanpa menyentuh label,
     * karena label ber-`for` justru memfokuskan kolomnya lagi.
     */
    function dispatchSyntheticClick(target) {
        const win = target.ownerDocument?.defaultView ?? undefined;
        if (typeof PointerEvent === "function") {
            try {
                target.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true, composed: true, button: 0 }));
            }
            catch {
                // Abaikan bila PointerEvent ditolak lingkungan.
            }
        }
        for (const step of ["mousedown", "mouseup", "click"]) {
            try {
                const ev = typeof MouseEvent === "function"
                    ? new MouseEvent(step, { bubbles: true, cancelable: true, composed: true, button: 0, view: win })
                    : new Event(step, { bubbles: true, cancelable: true, composed: true });
                target.dispatchEvent(ev);
            }
            catch {
                // Event yang gagal dibuat tidak membatalkan penutupan.
            }
        }
    }
    function clickNeutralSpot(root, control) {
        if (!root)
            return false;
        let spots = [];
        try {
            spots = deepQueryAll(root, TITLE_SELECTOR);
        }
        catch {
            spots = [];
        }
        const spot = spots.find((s) => !s.contains?.(control) && !control.contains?.(s) && !s.querySelector?.("input, select, textarea") && !clickGuardReason(s));
        const target = spot ?? (root.tagName?.toLowerCase() === "body" && !clickGuardReason(root) ? root : null);
        if (!target)
            return false;
        dispatchSyntheticClick(target);
        return true;
    }
    /** Tutup dropdown membandel (mis. React-Select) dengan mengklik area netral halaman di luar kontrol. */
    function clickOutsideControl(doc, control) {
        const clickedSpot = clickNeutralSpot(doc.body ?? null, control);
        if (doc.body && (!clickedSpot || doc.body !== control)) {
            dispatchSyntheticClick(doc.body);
            return true;
        }
        return clickedSpot;
    }
    /**
     * Tutup dropdown dan kembalikan teks filter yang tadi diketik, supaya kolom tidak tampak terisi padahal tidak ada opsi
     * dipilih. Urutan: blur dulu (menutup kebanyakan dropdown). Bila masih terbuka di dalam dialog, klik tempat netral
     * (judul). Escape tidak dikirim ke dalam dialog, karena `rc-dialog` dan sejenisnya menutup modal pada Escape. Di luar
     * dialog Escape dikirim hanya ke kolom itu, dengan `stopPropagation` di fase target sehingga tidak naik ke leluhur.
     */
    /**
     * Melepas fokus dari kontrol dropdown sekaligus mengirim event `focusout`/`blur` sintetis agar React-Select di tab
     * yang tidak memegang fokus OS (mis. saat side panel aktif) tetap menjalankan `onBlur` dan menutup menunya.
     */
    function blurCombobox(el, input) {
        const seen = new Set();
        for (const node of [input, el]) {
            if (!node || seen.has(node))
                continue;
            seen.add(node);
            node.blur?.();
            const win = node.ownerDocument?.defaultView ?? undefined;
            try {
                const fo = typeof FocusEvent === "function"
                    ? new FocusEvent("focusout", { bubbles: true, cancelable: true, composed: true, view: win })
                    : new Event("focusout", { bubbles: true, cancelable: true });
                const bl = typeof FocusEvent === "function"
                    ? new FocusEvent("blur", { bubbles: false, cancelable: true, composed: true, view: win })
                    : new Event("blur", { bubbles: false, cancelable: true });
                node.dispatchEvent?.(fo);
                node.dispatchEvent?.(bl);
            }
            catch {
                // Abaikan bila event fokus sintetis ditolak.
            }
        }
    }
    function dismissCombobox(el, input, previousValue) {
        if (input && input.value !== previousValue)
            setNativeInputValue(input, previousValue);
        blurCombobox(el, input);
        const dialog = enclosingDialog(el);
        if (dialog) {
            if (isExpanded(el, input))
                clickNeutralSpot(dialog, el);
            return;
        }
        const host = (input ?? el);
        const contain = (ev) => ev.stopPropagation();
        try {
            const esc = typeof KeyboardEvent === "function"
                ? new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true, cancelable: true })
                : new Event("keydown", { bubbles: true });
            host.addEventListener?.("keydown", contain);
            try {
                host.dispatchEvent(esc);
            }
            finally {
                host.removeEventListener?.("keydown", contain);
            }
        }
        catch {
            // Abaikan: blur di atas tetap menutup sebagian besar dropdown.
        }
        // React-Select dan dropdown kustom yang mendengar mousedown di document tidak tertutup oleh Escape lokal yang dihentikan di host.
        if (isExpanded(el, input))
            clickNeutralSpot(el.ownerDocument?.body ?? null, el);
    }
    /** Wadah dropdown (portal) dari listbox cermin: tempat item opsi nyata berada. */
    function dropdownContainerOf(listbox) {
        let n = listbox.parentElement;
        for (let depth = 0; n && depth < 4; depth++, n = n.parentElement) {
            if (/dropdown|popup|popover|select-menu|menu-list/i.test(n.getAttribute("class") ?? ""))
                return n;
        }
        return listbox.parentElement ?? listbox;
    }
    /**
     * Pilih opsi pada custom combobox / React-Select / ARIA listbox:
     * buka dropdown, ketik filter bila ada `<input>`, lalu klik opsi di listbox milik kontrol INI.
     *
     * Listbox ditentukan dari `aria-controls`/`aria-owns`, atau dari menu yang baru muncul sesudah klik. Dokumen
     * tidak pernah dicari secara menyeluruh, supaya opsi di pertanyaan lain tidak ikut tercentang. Opsi dipilih
     * hanya bila cocok persis atau cocok unik (lihat `pickUniqueOption`). Selain itu dropdown ditutup, teks filter
     * dikembalikan, dan fungsi mengembalikan false: kolom dibiarkan untuk pengguna.
     *
     * ant/rc-select: listbox yang dirujuk hanya cermin ARIA 0-ukuran. Opsi yang bisa diklik (`.ant-select-item-option`)
     * ada di wadah dropdown di sebelahnya, jadi dicari di sana bila cermin tidak memberi opsi bernilai.
     */
    function readComboboxOptions(doc, el, innerInput, shownBefore) {
        const listbox = referencedListbox(doc, [el, innerInput === el ? null : innerInput]);
        let raw;
        if (listbox) {
            raw = queryOptionNodes(listbox);
            if (raw.length === 0)
                raw = queryOptionNodes(dropdownContainerOf(listbox));
        }
        else {
            raw = newlyOpenedOptions(doc, el, shownBefore);
        }
        return raw ? raw.filter((o) => !optionDisabledNode(o)) : null;
    }
    const COMBOBOX_FAIL = { ok: false, option: null, refused: false };
    const OBSERVED_MAX = 50;
    const OBSERVED_LABEL_MAX = 120;
    const readOnlyInput = (input) => input.readOnly === true || input.hasAttribute?.("readonly") === true || (input.getAttribute?.("inputmode") ?? "") === "none";
    const SELECTION_SELECTOR = '[class*="selection-item"], [class*="single-value"], [class*="selected-value"], [class*="multi-value__label"], [class*="selection-overflow-item"]';
    /**
     * Teks pilihan yang ditampilkan kontrol sesudah memilih (`.ant-select-selection-item`, `.select__single-value`),
     * dicari di tiga leluhur terdekat. null bila halaman tidak menampilkan elemen semacam itu (tidak bisa dinilai).
     */
    function displayedSelection(el) {
        let level = el;
        for (let depth = 0; level && depth < 4; depth++, level = parentOrHost(level)) {
            let found = [];
            try {
                found = deepQueryAll(level, SELECTION_SELECTOR).filter(isShown);
            }
            catch {
                found = [];
            }
            if (found.length > 0)
                return found.map(optionLabel).filter(Boolean);
        }
        return null;
    }
    async function selectCustomComboboxAsyncDetailed(doc, el, target, opts) {
        if (!normalizeOptionText(target))
            return COMBOBOX_FAIL;
        const timeoutMs = Math.max(0, opts?.timeoutMs ?? 3000);
        const pollMs = Math.max(10, opts?.pollMs ?? 40);
        const htmlEl = el;
        const innerInput = el.tagName.toLowerCase() === "input" ? el : (el.querySelector?.("input") ?? null);
        const previousValue = innerInput?.value ?? "";
        if (isExpanded(el, innerInput))
            dismissCombobox(el, innerInput, previousValue);
        const shownBefore = new Set(shownOptions(doc));
        htmlEl.focus?.();
        if (!humanClick(htmlEl))
            return { ok: false, option: null, refused: true };
        // rc-select dengan `showSearch` menjadikan inputnya bisa diketik hanya sesudah terbuka; beri React sejenak memperbarui.
        if (innerInput && readOnlyInput(innerInput) && (opts?.typeToSearch === true || el.closest?.('[class*="select-show-search"]'))) {
            await new Promise((resolve) => setTimeout(resolve, 80));
        }
        // Kolom pencarian yang tetap hanya-baca (ant Select tanpa `showSearch`) tidak diketik: tidak ada yang menyaring.
        if (innerInput && !readOnlyInput(innerInput))
            commitText(innerInput, target, { doc, keepFocus: true });
        let clicked = null;
        let clickedLabel = "";
        let refused = false;
        let lastSeen = [];
        const tryPick = () => {
            const options = readComboboxOptions(doc, el, innerInput, shownBefore);
            if (!options || options.length === 0)
                return false;
            const labels = options.map(optionLabel);
            lastSeen = labels;
            const idx = pickUniqueOption(labels, target);
            if (idx < 0)
                return false;
            // Label dibaca sebelum klik: opsi biasanya hilang dari DOM sesudahnya.
            clickedLabel = labels[idx];
            if (!humanClick(options[idx])) {
                refused = true;
                return true;
            }
            clicked = options[idx];
            return true;
        };
        const fail = async () => {
            // Filter yang diketik menghabiskan semua opsi: kosongkan dulu supaya daftar nyata halaman terlihat untuk perencanaan ulang.
            if (lastSeen.length === 0 && !refused && innerInput && !readOnlyInput(innerInput) && innerInput.value !== "") {
                commitText(innerInput, "", { doc, keepFocus: true });
                const deadline = Date.now() + Math.min(600, timeoutMs);
                for (;;) {
                    const options = readComboboxOptions(doc, el, innerInput, shownBefore);
                    if (options && options.length > 0) {
                        lastSeen = options.map(optionLabel);
                        break;
                    }
                    if (Date.now() >= deadline)
                        break;
                    await new Promise((resolve) => setTimeout(resolve, pollMs));
                }
            }
            dismissCombobox(el, innerInput, previousValue);
            const observed = lastSeen.map((l) => l.slice(0, OBSERVED_LABEL_MAX)).filter(Boolean).slice(0, OBSERVED_MAX);
            return { ...COMBOBOX_FAIL, refused, ...(observed.length > 0 ? { observed } : {}) };
        };
        const confirm = async () => {
            await settleThenGrace(doc, { quietMs: 80, maxMs: 800, graceMs: 60 });
            const shown = displayedSelection(el);
            const confirmed = shown === null ? null : shown.some((s) => normalizeOptionText(s) === normalizeOptionText(clickedLabel));
            return { ok: true, option: clicked, refused: false, label: clickedLabel, confirmed };
        };
        if (tryPick())
            return refused ? await fail() : await confirm();
        if (timeoutMs === 0)
            return await fail();
        const pickedInTime = await new Promise((resolve) => {
            let finished = false;
            let observer = null;
            let pollTimer = null;
            let deadlineTimer = null;
            const cleanup = () => {
                if (observer)
                    observer.disconnect();
                if (pollTimer)
                    clearInterval(pollTimer);
                if (deadlineTimer)
                    clearTimeout(deadlineTimer);
                observer = null;
                pollTimer = null;
                deadlineTimer = null;
            };
            const done = (ok) => {
                if (finished)
                    return;
                finished = true;
                cleanup();
                resolve(ok);
            };
            const check = () => {
                if (finished)
                    return;
                if (tryPick())
                    done(true);
            };
            if (typeof MutationObserver === "function") {
                try {
                    // Seluruh dokumen diamati: daftar ant ada di sebelah listbox cermin, bukan di dalamnya.
                    const targetNode = (doc.body ?? doc.documentElement);
                    if (targetNode) {
                        observer = new MutationObserver(() => check());
                        observer.observe(targetNode, { childList: true, subtree: true, attributes: true });
                    }
                }
                catch {
                    observer = null;
                }
            }
            pollTimer = setInterval(check, pollMs);
            deadlineTimer = setTimeout(() => done(tryPick()), timeoutMs);
        });
        if (!pickedInTime || refused)
            return await fail();
        return await confirm();
    }
    const isNativeInput = (el) => el.tagName.toLowerCase() === "input";
    function radioLabelText(doc, r) {
        if (!isNativeInput(r))
            return ariaOptionLabel(doc, r);
        const id = r.getAttribute("id");
        let fromFor = null;
        if (id) {
            try {
                fromFor = scopeOf(r, doc).querySelector(`label[for="${id}"]`)?.textContent;
            }
            catch {
                fromFor = null;
            }
        }
        const wrapText = r.closest?.("label")?.textContent;
        return (fromFor?.trim() ? fromFor : null) ?? (wrapText?.trim() ? wrapText : null) ?? (r.value || r.getAttribute("value") || "");
    }
    /**
     * Radio yang dipilih untuk jawaban `answer` di grup `controlId`: kecocokan persis (label atau nilai) lebih dulu, lalu
     * satu-satunya radio yang labelnya diawali jawaban pada batas kata. Lebih dari satu kandidat berarti ambigu: tidak
     * ada yang dipilih. `group` memuat radio pertama grup (untuk pelaporan) atau null bila grup tidak ada.
     * Pilihan bisa `<input type=radio>` asli, `role=radio`, atau tombol bergantian (`aria-pressed`) yang diberi
     * `data-applify-rg` oleh pembaca formulir, juga di dalam shadow root terbuka.
     */
    function findRadioToSelect(doc, controlId, answer) {
        let groupRadios = [];
        try {
            groupRadios = findAllByAttr(doc, "data-applify-rg", controlId);
        }
        catch {
            groupRadios = [];
        }
        if (groupRadios.length === 0)
            return { radio: null, group: null, reason: "group_missing" };
        const pick = pickOption(groupRadios.map((r) => radioLabelText(doc, r)), answer, groupRadios.map((r) => String(r.value || r.getAttribute("value") || r.getAttribute("data-value") || "")));
        if (pick.index >= 0)
            return { radio: groupRadios[pick.index], group: groupRadios[0], reason: null };
        return { radio: null, group: groupRadios[0], reason: pick.ambiguous ? "option_ambiguous" : "option_missing" };
    }
    function attachResumeBytes(doc, fileControlId, bytesBase64, filename = "resume.pdf") {
        if (!fileControlId || !bytesBase64 || typeof DataTransfer === "undefined")
            return false;
        const input = findControlByCid(doc, fileControlId);
        if (!input)
            return false;
        const raw = atob(bytesBase64);
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++)
            bytes[i] = raw.charCodeAt(i);
        const file = new File([bytes], filename, { type: "application/pdf" });
        const dt = new DataTransfer();
        dt.items.add(file);
        input.files = dt.files;
        input.dispatchEvent(new Event("change", { bubbles: true }));
        return (input.files?.length ?? 0) > 0;
    }
    /**
     * Pasang berkas ke input file lewat `DataTransfer`. Hanya ke elemen `<input type="file">` yang ditandai ekstensi
     * (`data-applify-cid`) di dokumen frame ini. Input yang tersembunyi tetap bisa diisi. Satu input hanya menerima satu
     * berkas (yang pertama), dan input yang sama tidak diisi dua kali. Hasilnya dibaca ulang lewat `files.length`; bila
     * kosong, halaman diperiksa dulu: input yang hilang atau diganti sesudah `change`, atau nama berkas yang baru tampil, berarti
     * halaman sudah mengambil berkasnya (SmartRecruiters). Tanpa itu, pemasangan diulang satu kali sebelum dinyatakan gagal. Berkas yang
     * kita pasang di putaran sebelumnya dan masih tampil di halaman tidak dipasang ulang.
     */
    function attachFiles(doc, files) {
        const attached = emptyFilesAttached();
        const attachedControlIds = [];
        const failed = [];
        const log = [];
        if (!Array.isArray(files))
            return { attached, attachedControlIds, failed, log };
        for (const file of files) {
            if (!isFileKind(file?.kind))
                continue;
            const kind = file.kind;
            const ref = typeof file.controlId === "string" && SAFE_CONTROL_ID_RE$1.test(file.controlId) ? file.controlId : "invalid";
            const fail = (result, reason) => {
                if (!failed.includes(kind))
                    failed.push(kind);
                pushAction(log, { ref, kind: "file", action: "attach", result, reason });
            };
            const markAttached = (result, reason) => {
                attached[kind] = true;
                attachedControlIds.push(file.controlId);
                rememberAttachedFile(doc, file.filename);
                pushAction(log, { ref, kind: "file", action: "attach", result, ...(reason ? { reason } : {}) });
            };
            if (typeof DataTransfer === "undefined" || typeof File === "undefined") {
                fail("unverified", "no_datatransfer");
                continue;
            }
            if (ref === "invalid" || attachedControlIds.includes(file.controlId)) {
                fail("skipped", ref === "invalid" ? "bad_control_id" : "duplicate_input");
                continue;
            }
            let input = null;
            try {
                input = findControlByCid(doc, file.controlId);
            }
            catch {
                input = null;
            }
            if (!input || input.tagName.toLowerCase() !== "input" || (input.getAttribute("type") ?? "").toLowerCase() !== "file") {
                // Input file diganti chip nama berkas oleh komponen unggah, dan berkas ini kita pasang di putaran sebelumnya.
                if (!input && alreadyAttachedOnPage(doc, file.filename, null)) {
                    markAttached("verified", "already_shown");
                    continue;
                }
                fail("missing", input ? "not_file_input" : "element_missing");
                continue;
            }
            const bytes = typeof file.base64 === "string" ? base64ToBytes(file.base64) : null;
            if (!bytes || bytes.length === 0) {
                fail("unverified", "bad_payload");
                continue;
            }
            const skip = skipReason(input);
            if (skip) {
                fail("skipped", skip);
                continue;
            }
            // Putaran kedua: berkas yang kita pasang tadi masih tampil di halaman, jadi tidak dipasang ulang.
            if (alreadyAttachedOnPage(doc, file.filename, input)) {
                markAttached("verified", "already_shown");
                continue;
            }
            const make = () => new File([bytes], String(file.filename || kind), { type: String(file.mimeType || "application/octet-stream") });
            const watch = watchUpload(doc, file.controlId, input, file.filename);
            let result = "verified";
            const first = assignInputFileDetailed(input, make());
            if (!first.readback) {
                // Event terkirim tetapi input kosong lagi: halaman bisa saja sudah mengambil berkasnya lalu menggantinya atau menampilkan namanya.
                if (first.dispatched && watch.hasEvidence()) {
                    markAttached("verified", inputReplaced(doc, file.controlId, input) ? "input_replaced" : "page_shows_file");
                    continue;
                }
                result = "retried";
                const second = assignInputFileDetailed(input, make());
                if (!second.readback) {
                    if (second.dispatched && watch.hasEvidence()) {
                        markAttached("retried", inputReplaced(doc, file.controlId, input) ? "input_replaced" : "page_shows_file");
                        continue;
                    }
                    fail("unverified", "readback_mismatch");
                    continue;
                }
            }
            markAttached(result);
        }
        return { attached, attachedControlIds, failed, log };
    }
    /** Nilai `contenteditable` yang terbaca: teks isi dan `innerText` (baris baru). Salah satu yang cocok sudah cukup. */
    function editableReadings(el) {
        const inner = el.innerText;
        return [editableText(el), typeof inner === "string" ? inner.replace(/[\u200b\u200c\u200d\ufeff]/g, "") : ""];
    }
    const hasEditableText = (el) => editableReadings(el).some((t) => t.trim() !== "");
    function countMissingRequired(doc) {
        const labels = [];
        const checkedGroups = new Set();
        const requiredNodes = deepQueryAll(doc, "[required], [aria-required='true'], [data-applify-req='1']");
        for (const el of requiredNodes) {
            const tag = el.tagName.toLowerCase();
            const type = (el.getAttribute("type") ?? "").toLowerCase();
            const role = (el.getAttribute("role") ?? "").trim().toLowerCase();
            if (type === "hidden" || type === "password" || el.getAttribute("aria-hidden") === "true") {
                el.removeAttribute("data-applify-missing");
                continue;
            }
            if (type !== "file" && type !== "radio" && type !== "checkbox" && !isElementVisible(el)) {
                el.removeAttribute("data-applify-missing");
                continue;
            }
            let missing = false;
            if (type === "radio") {
                const rg = el.getAttribute("data-applify-rg") || el.getAttribute("name") || el.getAttribute("id") || "";
                if (rg && checkedGroups.has(rg))
                    continue;
                if (rg)
                    checkedGroups.add(rg);
                const group = el.getAttribute("data-applify-rg") ? findAllByAttr(doc, "data-applify-rg", el.getAttribute("data-applify-rg")) : [el];
                missing = !group.some((r) => r.checked);
            }
            else if (type === "checkbox") {
                const rg = el.getAttribute("data-applify-rg") || "";
                if (rg) {
                    if (checkedGroups.has(rg))
                        continue;
                    checkedGroups.add(rg);
                    const group = findAllByAttr(doc, "data-applify-rg", rg);
                    missing = !group.some((c) => c.checked);
                }
                else {
                    missing = !el.checked;
                }
            }
            else if (type === "file") {
                missing = !(el.files && el.files.length > 0);
            }
            else if (tag === "select" || tag === "input" || tag === "textarea") {
                const raw = String(el.value ?? "").trim();
                const disp = role === "combobox" && tag !== "select" ? comboboxDisplayValue(el) : "";
                missing = !raw && !disp;
            }
            else if (role === "combobox") {
                missing = !comboboxDisplayValue(el);
            }
            else if (role === "checkbox" || role === "switch") {
                missing = !(el.getAttribute("aria-checked") === "true" || el.getAttribute("aria-pressed") === "true");
            }
            else if (role === "radiogroup" || role === "group") {
                const inner = deepQueryAll(el, 'input[type="radio"], input[type="checkbox"], [aria-checked], [aria-pressed]');
                missing = inner.length > 0 && !inner.some((c) => c.checked === true || isAriaOn(c));
            }
            else if (role === "listbox") {
                // Dropdown Google Forms yang wajib: kosong bila yang terpilih masih penanda "Pilih" (`data-value=""`). Tanpa
                // pilihan ber-`aria-selected` keadaannya tidak diketahui, jadi tidak dihitung kurang.
                missing = listboxHasSelection(el) === false;
            }
            else if (isEditableHost(el)) {
                missing = !hasEditableText(el);
            }
            if (missing) {
                el.setAttribute("data-applify-missing", "true");
                const label = (questionLabelFor(doc, el) || el.getAttribute("name") || "Kolom wajib").trim();
                labels.push(label);
            }
            else {
                el.removeAttribute("data-applify-missing");
            }
        }
        return { count: labels.length, labels: labels.slice(0, 200) };
    }
    function pushAction(log, entry) {
        if (log.length < MAX_ACTION_LOG)
            log.push(entry);
    }
    const collapseWs = (s) => s.replace(/\s+/g, " ").trim();
    const digitsOf = (s) => s.replace(/\D/g, "");
    const NUMERIC_INTENT_RE = /^[\d\s+()\-./,]+$/;
    /**
     * Buang nol sia-sia di pecahan desimal: "5000.00" -> "5000", "3.850" -> "3.85", "Rp 5.000,00" -> "Rp 5.000".
     * Pecahan nol tiga digit ("5.000") dibiarkan karena bisa pemisah ribuan, bukan desimal.
     */
    function trimFractionZeros(s) {
        const m = /^(\D*\d[\d.,\s]*?)([.,])(\d+)$/.exec(s.trim());
        if (!m)
            return s;
        const kept = m[3].replace(/0+$/, "");
        if (kept === "")
            return m[3].length <= 2 ? m[1] : s;
        return `${m[1]}${m[2]}${kept}`;
    }
    /**
     * Nilai yang terbaca ulang cocok dengan niat: sama setelah spasi dirapikan, atau (hanya untuk isian berupa angka,
     * misalnya telepon) nilai bertopeng yang memuat angka yang sama. Awalan nol boleh hilang ("0812" -> "+62 812").
     */
    function textMatchesIntent(read, intent) {
        const got = typeof read === "string" ? read : "";
        if (collapseWs(got) === collapseWs(intent))
            return true;
        if (!NUMERIC_INTENT_RE.test(intent.trim()))
            return false;
        const want = digitsOf(intent);
        const have = digitsOf(got);
        if (want === "" || have === "")
            return false;
        if (have === want)
            return true;
        // Angka pendek (gaji "5000", IPK "3.85") yang diformat ulang halaman ("5000.00", "3.850") tidak lolos aturan 6 digit di bawah (audit U2B-10).
        if (digitsOf(trimFractionZeros(got)) === digitsOf(trimFractionZeros(intent)))
            return true;
        return want.length >= 6 && [want, want.replace(/^0+/, "")].some((w) => w.length >= 6 && have.includes(w));
    }
    const verifiedOutcome = (action, retried) => ({ filled: true, action, result: retried ? "retried" : "verified" });
    const failedOutcome = (action, result, reason) => ({ filled: false, action, result, reason });
    /**
     * Tulis `checked` lewat setter prototipe, bukan properti instans. React memasang pelacak nilai pada properti instans;
     * menulis lewat instans ikut memperbarui pelacak itu, sehingga React mengira tidak ada perubahan dan `onChange` tidak
     * pernah jalan (keadaan form tetap kosong walau kotak tampak tercentang).
     */
    function setNativeChecked(input, next) {
        try {
            const proto = Object.getPrototypeOf(input);
            const desc = proto ? Object.getOwnPropertyDescriptor(proto, "checked") : undefined;
            if (desc?.set) {
                desc.set.call(input, next);
                return;
            }
        }
        catch {
            // Jatuh ke penulisan biasa.
        }
        input.checked = next;
    }
    /**
     * Centang atau radio. Urutan penting untuk form terkontrol (React, Vue): klik seperti pengguna lebih dulu, karena React
     * membaca perubahan radio dan kotak centang dari event `click`. Menulis `checked` lebih dulu membuat klik berikutnya
     * tidak mengubah apa pun, dan pembacaan ulang melaporkan terisi padahal keadaan form tetap kosong (kasus JobStreet).
     * Bila klik tidak menempel: setter prototipe lalu event `click` biasa (bukan MouseEvent, jadi tidak membalik lagi)
     * ditambah `input` dan `change`. `alwaysWrite` dipertahankan untuk pemanggil lama; radio yang sudah terpilih tidak
     * diklik ulang.
     */
    /** Label `for=id` atau label pembungkus sebuah radio atau kotak centang. */
    function labelForCheckable(input) {
        const id = input.getAttribute("id");
        const scope = input.getRootNode?.() ?? input.ownerDocument;
        if (id && scope && typeof scope.querySelectorAll === "function") {
            const byFor = Array.from(scope.querySelectorAll("label")).find((l) => l.getAttribute("for") === id);
            if (byFor)
                return byFor;
        }
        return input.closest?.("label") ?? null;
    }
    function applyCheckable(input, next, _alwaysWrite) {
        if (input.checked === next)
            return verifiedOutcome("check", false);
        const clicked = humanClick(input);
        if (input.checked === next)
            return verifiedOutcome("check", false);
        // Cadangan klik label: widget pilihan buatan situs sering mendengarkan klik pada label atau kotak gambarnya,
        // bukan pada input asli yang disembunyikan. Klik label yang terkait dengan input ini, lalu baca ulang.
        const label = clicked ? labelForCheckable(input) : null;
        if (label && humanClick(label) && input.checked === next)
            return verifiedOutcome("check", false);
        if (!clicked && input.checked !== next) {
            // Klik ditolak penjaga tombol kirim: jangan paksa lewat setter.
            return failedOutcome("check", "unverified", "click_refused");
        }
        setNativeChecked(input, next);
        for (const type of ["click", "input", "change"]) {
            try {
                input.dispatchEvent(new Event(type, { bubbles: true }));
            }
            catch {
                // Event yang gagal dibuat tidak boleh membatalkan aksi.
            }
        }
        if (input.checked === next)
            return verifiedOutcome("check", true);
        return failedOutcome("check", "unverified", "readback_mismatch");
    }
    /** Atribut keadaan widget ARIA: `aria-checked` (kotak centang, saklar, radio) atau `aria-pressed` (tombol bergantian). */
    function ariaStateAttr(el) {
        return !el.hasAttribute("aria-checked") && el.hasAttribute("aria-pressed") ? "aria-pressed" : "aria-checked";
    }
    const isAriaOn = (el) => el.getAttribute("aria-checked") === "true" || el.getAttribute("aria-pressed") === "true";
    /** Tombol Spasi seperti pengguna: cadangan bila klik tidak mengubah keadaan widget ARIA. */
    function pressSpace(el) {
        for (const type of ["keydown", "keyup"]) {
            try {
                const ev = typeof KeyboardEvent === "function"
                    ? new KeyboardEvent(type, { key: " ", code: "Space", bubbles: true, cancelable: true })
                    : new Event(type, { bubbles: true, cancelable: true });
                el.dispatchEvent(ev);
            }
            catch {
                // Event yang gagal dibuat tidak boleh membatalkan aksi.
            }
        }
    }
    /**
     * Kotak centang, saklar, radio, atau tombol bergantian ARIA: klik seperti pengguna (`humanClick`, termasuk penjaga
     * tombol kirim) lalu baca ulang `aria-checked`/`aria-pressed`. Sudah berkeadaan sama: tidak diklik, karena klik kedua
     * pada tombol bergantian justru membatalkannya. Bila klik tidak mengubah keadaan, satu percobaan lagi lewat tombol Spasi.
     */
    function applyAriaToggle(el, next) {
        const attr = ariaStateAttr(el);
        const isOn = () => el.getAttribute(attr) === "true";
        if (isOn() === next)
            return verifiedOutcome("check", false);
        if (!humanClick(el))
            return failedOutcome("check", "unverified", "click_refused");
        if (isOn() === next)
            return verifiedOutcome("check", false);
        el.focus?.();
        pressSpace(el);
        if (isOn() === next)
            return verifiedOutcome("check", true);
        return failedOutcome("check", "unverified", "readback_mismatch");
    }
    function selectEditableContents(doc, el) {
        try {
            // Di dalam shadow root, Chrome hanya menerima rentang lewat `ShadowRoot.getSelection()` (non-standar).
            const root = el.getRootNode?.();
            const selection = root?.getSelection?.() ?? doc.getSelection?.();
            const range = doc.createRange?.();
            if (selection && range) {
                range.selectNodeContents(el);
                selection.removeAllRanges();
                selection.addRange(range);
                return;
            }
        }
        catch {
            // Jatuh ke selectAll di bawah.
        }
        try {
            doc.execCommand?.("selectAll", false);
        }
        catch {
            // Tanpa pilihan, penyisipan tetap dicoba.
        }
    }
    /** Isi kotak teks `contenteditable`: dibaca ulang dari `textContent` (dan `innerText` untuk baris baru). */
    function editableMatches(el, value) {
        return editableReadings(el).some((t) => textMatchesIntent(t, value));
    }
    function inputEventFor(value) {
        return typeof InputEvent === "function"
            ? new InputEvent("input", { bubbles: true, cancelable: false, inputType: "insertText", data: value })
            : new Event("input", { bubbles: true });
    }
    /**
     * Kotak teks `contenteditable` (editor kaya, kolom jawaban kustom): fokus, pilih semua isi, lalu
     * `document.execCommand('insertText')` bila tersedia (browser sendiri mengirim `beforeinput` dan `input`). Tanpa itu,
     * `textContent` diisi lalu `InputEvent`. Dibaca ulang; bila tidak menempel, percobaan kedua lewat `textContent`,
     * `InputEvent`, dan blur.
     */
    function applyContentEditable(doc, el, value) {
        const host = el;
        host.focus?.();
        selectEditableContents(doc, el);
        let inserted = false;
        if (typeof doc.execCommand === "function") {
            try {
                inserted = doc.execCommand("insertText", false, value) === true;
            }
            catch {
                inserted = false;
            }
        }
        if (!inserted) {
            el.textContent = value;
            el.dispatchEvent(inputEventFor(value));
        }
        if (editableMatches(el, value))
            return verifiedOutcome("set", false);
        host.focus?.();
        el.textContent = value;
        el.dispatchEvent(inputEventFor(value));
        host.blur?.();
        if (editableMatches(el, value))
            return verifiedOutcome("set", true);
        return failedOutcome("set", "unverified", "readback_mismatch");
    }
    function applySelectElement(selectEl, target) {
        const { option, ambiguous } = findSelectOption(selectEl, target);
        if (!option)
            return failedOutcome("select", ambiguous ? "unverified" : "missing", ambiguous ? "option_ambiguous" : "option_missing");
        writeSelectOption(selectEl, option, false);
        if (isOptionSelected(selectEl, option))
            return verifiedOutcome("select", false);
        writeSelectOption(selectEl, option, true);
        if (isOptionSelected(selectEl, option))
            return verifiedOutcome("select", true);
        return failedOutcome("select", "unverified", "readback_mismatch");
    }
    function applyTextValue(input, value) {
        setNativeInputValue(input, value);
        if (textMatchesIntent(input.value, value))
            return verifiedOutcome("set", false);
        setNativeInputValueFull(input, value);
        if (textMatchesIntent(input.value, value))
            return verifiedOutcome("set", true);
        return failedOutcome("set", "unverified", "readback_mismatch");
    }
    /** Tulis satu aksi ke kontrol biasa (bukan dropdown kustom), baca ulang, dan ulangi satu kali bila tidak menempel. */
    function applyNonComboboxAction(doc, act, el) {
        if (act.kind === "checkbox") {
            return isNativeInput(el) ? applyCheckable(el, Boolean(act.value)) : applyAriaToggle(el, Boolean(act.value));
        }
        if (act.kind === "select")
            return applySelectElement(el, String(act.value));
        if (isEditableHost(el))
            return applyContentEditable(doc, el, String(act.value));
        return applyTextValue(el, String(act.value));
    }
    const newApplyState = () => ({ filledCount: 0, filledControlIds: [], unfilled: [], log: [], observed: [], fieldErrors: [] });
    function safeRef(id) {
        return String(id ?? "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 64) || "unknown";
    }
    const fpNorm = (raw) => String(raw ?? "").replace(/\s+/g, " ").trim().toLowerCase();
    function fingerprintOf(doc, el) {
        const editable = isEditableHost(el);
        let label = "";
        try {
            label = fpNorm(questionLabelFor(doc, el));
        }
        catch {
            label = "";
        }
        return {
            tag: el.tagName.toLowerCase(),
            type: fpNorm(el.getAttribute("type") ?? "text") || "text",
            name: String(el.getAttribute("name") ?? ""),
            id: String(el.getAttribute("id") ?? ""),
            placeholder: fpNorm(el.getAttribute("placeholder")),
            ariaLabel: fpNorm(el.getAttribute("aria-label")),
            label,
            editable,
        };
    }
    /**
     * Cari kolom yang sama sesudah simpulnya diganti halaman. Hanya menerima SATU kandidat terbaik dengan sedikitnya satu
     * ciri kuat (name, id, atau label) dan tidak sedang dipakai kontrol lain; ragu berarti tidak menebak (null).
     * Kandidat terpilih diberi lagi `data-applify-cid`.
     */
    function relocateControl(doc, cid, fp) {
        let pool = [];
        try {
            pool = deepQueryAll(doc, fp.editable ? "[contenteditable]" : fp.tag === "textarea" ? "textarea" : "input");
        }
        catch {
            return null;
        }
        let best = null;
        let bestScore = 0;
        let tie = false;
        for (const c of pool) {
            const own = c.getAttribute("data-applify-cid");
            if (own && own !== cid)
                continue;
            if (!isRendered(c))
                continue;
            if (!fp.editable && fp.tag === "input" && fpNorm(c.getAttribute("type") ?? "text") !== fp.type)
                continue;
            let score = 0;
            let strong = false;
            if (fp.name && c.getAttribute("name") === fp.name) {
                score += 3;
                strong = true;
            }
            if (fp.id && c.getAttribute("id") === fp.id) {
                score += 3;
                strong = true;
            }
            if (fp.label) {
                let label = "";
                try {
                    label = fpNorm(questionLabelFor(doc, c));
                }
                catch {
                    label = "";
                }
                if (label === fp.label) {
                    score += 2;
                    strong = true;
                }
            }
            if (!strong)
                continue;
            if (fp.ariaLabel && fpNorm(c.getAttribute("aria-label")) === fp.ariaLabel)
                score += 1;
            if (fp.placeholder && fpNorm(c.getAttribute("placeholder")) === fp.placeholder)
                score += 1;
            if (score > bestScore) {
                best = c;
                bestScore = score;
                tie = false;
            }
            else if (score === bestScore) {
                tie = true;
            }
        }
        if (!best || tie)
            return null;
        best.setAttribute("data-applify-cid", cid);
        return best;
    }
    /** Cocok dengan niat; kolom telepon dibandingkan per angka (kode negara dan nol di depan boleh berbeda). */
    const textMatches = (read, intent, phone) => textMatchesIntent(read, intent) || (phone && phoneMatches(read, intent));
    const readingsOf = (el, editable) => (editable ? editableReadings(el) : [String(el.value ?? "")]);
    const valueMatches = (el, intent, phone, editable) => readingsOf(el, editable).some((t) => textMatches(t, intent, phone));
    /** Halaman menandai kolom ini salah (Constraint Validation, `aria-invalid`, pesan galat di wadahnya). Lihat `fieldErrors.ts`. */
    function hasFieldError(el) {
        return extractFieldErrorMessage(el) !== null;
    }
    /**
     * Tulis satu isian teks dengan `commitText` (atau jalur contenteditable) dan antrekan untuk dibaca ulang. Catatan audit
     * dan hitungan terisi dimasukkan lebih dulu agar urutannya tetap; `finishPendingText` membalikkannya bila gagal.
     */
    function startTextCommit(state, doc, act, el, pending) {
        const editable = isEditableHost(el);
        const raw = String(act.value);
        const phone = !editable && (isPhoneField(el, doc) || findCountryAddon(el).found);
        const intent = phone ? normalizePhone(raw, el, doc) : raw;
        let via = "editable";
        let immediateOk;
        if (editable) {
            immediateOk = applyContentEditable(doc, el, intent).filled;
        }
        else {
            const res = commitText(el, intent, { doc, accept: (read) => textMatches(read, intent, phone) });
            via = res.via;
            immediateOk = res.immediate;
        }
        const entry = { ref: safeRef(act.controlId), kind: act.kind, action: "set", result: "verified" };
        pushAction(state.log, entry);
        state.filledCount++;
        state.filledControlIds.push(act.controlId);
        pending.push({ act, cid: act.controlId, el, fp: fingerprintOf(doc, el), intent, phone, editable, entry, via, immediateOk, retried: false });
    }
    /**
     * Baca ulang satu isian: kode alasan gagal, atau null bila menempel. Elemen dicari ulang lewat `data-applify-cid`
     * (React bisa mengganti simpulnya), harus masih tersambung dan tampil, nilainya cocok, dan halaman tidak menandainya salah.
     */
    function verifyPending(doc, p) {
        const el = findControlElement(doc, p.cid);
        if (!el)
            return "element_gone";
        p.el = el;
        if (el.isConnected === false)
            return "element_gone";
        if (!isRendered(el))
            return "hidden";
        if (!valueMatches(el, p.intent, p.phone, p.editable))
            return p.immediateOk ? "reverted" : "readback_mismatch";
        if (hasFieldError(el))
            return "field_error";
        return null;
    }
    const RETRYABLE_REASONS = new Set(["readback_mismatch", "reverted", "field_error", "element_gone"]);
    /** Tulis ulang satu kali, dengan jalur yang berbeda dari percobaan pertama (execCommand lawan ketikan per karakter). */
    function recommit(doc, p) {
        // Simpul diganti halaman (atribut cid hilang): cari kolom yang sama lagi. Tidak ketemu atau ragu: tidak menulis.
        const el = findControlElement(doc, p.cid) ?? relocateControl(doc, p.cid, p.fp);
        p.retried = true;
        if (!el)
            return;
        p.el = el;
        if (p.editable) {
            applyContentEditable(doc, el, p.intent);
            return;
        }
        const res = commitText(el, p.intent, { doc, forcePerChar: p.via === "execCommand", accept: (read) => textMatches(read, p.intent, p.phone) });
        p.via = res.via;
    }
    const filledRegistry = new Map();
    async function finishPendingText(state, doc, pending, opts) {
        if (pending.length === 0)
            return;
        const settle = () => settleThenGrace(doc, { graceMs: opts?.verifyGraceMs });
        const reasons = new Map();
        await settle();
        for (const p of pending)
            reasons.set(p, verifyPending(doc, p));
        const redo = pending.filter((p) => RETRYABLE_REASONS.has(reasons.get(p) ?? ""));
        if (redo.length > 0) {
            for (const p of redo)
                recommit(doc, p);
            await settle();
            for (const p of redo)
                reasons.set(p, verifyPending(doc, p));
        }
        for (const p of pending) {
            const reason = reasons.get(p) ?? null;
            if (reason === null) {
                p.entry.result = p.retried ? "retried" : "verified";
                filledRegistry.set(p.cid, { el: p.el, fp: p.fp, intent: p.intent, phone: p.phone, editable: p.editable });
                continue;
            }
            p.entry.result = "unverified";
            p.entry.reason = reason;
            if (reason === "field_error") {
                const message = extractFieldErrorMessage(p.el);
                if (message)
                    state.fieldErrors.push({ controlId: p.cid, message: message.slice(0, 200) });
            }
            filledRegistry.delete(p.cid);
            state.filledCount--;
            const at = state.filledControlIds.lastIndexOf(p.cid);
            if (at >= 0)
                state.filledControlIds.splice(at, 1);
            state.unfilled.push({ id: p.cid, el: p.el });
        }
    }
    /** Kosongkan daftar isian terverifikasi (dipakai tes, dan saat sesi pengisian baru dimulai di dokumen lain). */
    function resetFilledRegistry() {
        filledRegistry.clear();
    }
    /**
     * Penegasan akhir sebelum bukti dan laporan: isian teks yang tadinya terverifikasi dibaca lagi. Yang berubah (form
     * menginisialisasi ulang, topeng memformat ulang, halaman memuat data awal belakangan) ditulis ulang SATU kali dengan
     * `commitText`, ditunggu tenang, dan dibaca lagi. Yang masih berubah ditandai `unverified:reverted` supaya menjadi
     * pertanyaan, bukan "terisi" palsu. Hanya elemen yang masih tersambung, bertanda `data-applify-cid` yang sama, dan tampil.
     */
    async function reassertFilled(doc, opts) {
        const drifted = [];
        const pending = [];
        let checked = 0;
        for (const [cid, reg] of [...filledRegistry]) {
            let el = reg.el;
            if (el.isConnected === false || el.getAttribute?.("data-applify-cid") !== cid) {
                // Halaman mengganti simpulnya: cari kolom yang sama lagi (id yang sama, atau ciri name/id/label). Tidak ketemu: lepas.
                const found = findControlElement(doc, cid) ?? (reg.fp ? relocateControl(doc, cid, reg.fp) : null);
                if (!found) {
                    filledRegistry.delete(cid);
                    continue;
                }
                el = found;
                reg.el = found;
            }
            if (!isRendered(el))
                continue;
            checked++;
            if (valueMatches(el, reg.intent, reg.phone, reg.editable))
                continue;
            drifted.push(cid);
            pending.push({
                act: { controlId: cid, kind: "text", value: "", source: "fact" },
                cid,
                el,
                intent: reg.intent,
                phone: reg.phone,
                editable: reg.editable,
                fp: reg.fp ?? fingerprintOf(doc, el),
                entry: { ref: safeRef(cid), kind: "text", action: "set", result: "retried" },
                via: reg.editable ? "editable" : "execCommand",
                immediateOk: true,
                retried: false,
            });
        }
        const refilled = [];
        const reverted = [];
        const actionLog = [];
        if (pending.length > 0) {
            for (const p of pending)
                recommit(doc, p);
            await settleThenGrace(doc, { graceMs: opts?.verifyGraceMs });
            for (const p of pending) {
                const reason = verifyPending(doc, p);
                if (reason === null) {
                    refilled.push(p.cid);
                    actionLog.push({ ref: safeRef(p.cid), kind: "text", action: "set", result: "retried", reason: "drift_refilled" });
                }
                else {
                    reverted.push(p.cid);
                    filledRegistry.delete(p.cid);
                    actionLog.push({ ref: safeRef(p.cid), kind: "text", action: "set", result: "unverified", reason: "reverted" });
                }
            }
        }
        return { checked, drifted, refilled, reverted, missing: countMissingRequired(doc), actionLog };
    }
    function recordOutcome(state, act, el, outcome) {
        pushAction(state.log, {
            ref: safeRef(act.controlId),
            kind: act.kind,
            action: outcome.action,
            result: outcome.result,
            ...(outcome.reason ? { reason: outcome.reason } : {}),
        });
        if (outcome.filled) {
            state.filledCount++;
            state.filledControlIds.push(act.controlId);
        }
        else {
            state.unfilled.push({ id: act.controlId, el });
        }
    }
    function findControlElement(doc, controlId) {
        try {
            return findControlByCid(doc, controlId);
        }
        catch {
            return null;
        }
    }
    function applyRadioAction(state, doc, act) {
        const found = findRadioToSelect(doc, act.controlId, String(act.value));
        if (!found.radio) {
            const ambiguous = found.reason === "option_ambiguous";
            recordOutcome(state, act, found.group, failedOutcome("check", ambiguous ? "unverified" : "missing", found.reason ?? "option_missing"));
            return;
        }
        const skip = skipReason(found.radio);
        if (skip) {
            pushAction(state.log, { ref: safeRef(act.controlId), kind: "radio", action: "skip", result: "skipped", reason: skip });
            return;
        }
        scrollIntoViewIfNeeded(found.radio);
        const outcome = isNativeInput(found.radio) ? applyCheckable(found.radio, true) : applyAriaToggle(found.radio, true);
        recordOutcome(state, act, found.radio, outcome);
    }
    /**
     * Tahap bersama jalur sinkron dan asinkron. Menangani radio, elemen hilang, kontrol nonaktif/hanya-baca, dan semua
     * kontrol biasa. Mengembalikan elemen dropdown kustom bila aksi ini harus dipilih lewat combobox (pemanggil yang
     * memilih versi sinkron atau asinkron), atau null bila aksi sudah selesai ditangani.
     */
    function applyUntilCombobox(state, doc, act, pending) {
        if (act.kind === "radio") {
            applyRadioAction(state, doc, act);
            return null;
        }
        const el = findControlElement(doc, act.controlId);
        if (!el) {
            const action = act.kind === "select" ? "select" : act.kind === "checkbox" ? "check" : "set";
            recordOutcome(state, act, null, failedOutcome(action, "missing", "element_missing"));
            return null;
        }
        const customSelect = act.kind === "select" && el.tagName.toLowerCase() !== "select";
        const skip = customSelect ? comboboxSkipReason(el) : skipReason(el);
        if (skip) {
            pushAction(state.log, { ref: safeRef(act.controlId), kind: act.kind, action: "skip", result: "skipped", reason: skip });
            return null;
        }
        if (customSelect)
            return el;
        scrollIntoViewIfNeeded(el);
        // Jalur asinkron: teks ditulis seperti ketikan dan dibaca ulang sesudah halaman tenang (`finishPendingText`).
        if (pending && (act.kind === "text" || act.kind === "textarea") && isTextWritable(el)) {
            startTextCommit(state, doc, act, el, pending);
            return null;
        }
        recordOutcome(state, act, el, applyNonComboboxAction(doc, act, el));
        return null;
    }
    const NON_TEXT_INPUT_TYPES = new Set(["checkbox", "radio", "file", "hidden", "submit", "button", "image", "reset", "range", "color"]);
    /** Kontrol yang menerima teks: `textarea`, `input` bertipe teks, atau kotak `contenteditable`. */
    function isTextWritable(el) {
        if (isEditableHost(el))
            return true;
        const tag = el.tagName.toLowerCase();
        if (tag === "textarea")
            return true;
        return tag === "input" && !NON_TEXT_INPUT_TYPES.has((el.getAttribute("type") ?? "").toLowerCase());
    }
    /** Dropdown tertutup (`aria-expanded` bukan true) atau opsi yang diklik sudah hilang: pilihan tampaknya terpasang. */
    function comboboxLooksSelected(el, option) {
        const expanded = [el, el.querySelector?.("input")].map((n) => n?.getAttribute?.("aria-expanded") ?? null).find((v) => v !== null);
        if (expanded !== undefined)
            return expanded !== "true";
        if (!option)
            return false;
        return option.isConnected === false || !isShown(option);
    }
    function recordCombobox(state, act, el, pick) {
        const ref = safeRef(act.controlId);
        if (pick.ok && pick.confirmed !== false) {
            // Dropdown kustom tetap dihitung terisi seperti sebelumnya; catatan audit jujur soal terkonfirmasi atau tidaknya.
            const confirmed = pick.confirmed ?? comboboxLooksSelected(el, pick.option);
            pushAction(state.log, { ref, kind: "select", action: "select", result: confirmed ? "verified" : "unverified", ...(confirmed ? {} : { reason: "combobox_unconfirmed" }) });
            state.filledCount++;
            state.filledControlIds.push(act.controlId);
            return;
        }
        state.unfilled.push({ id: act.controlId, el });
        if (pick.observed && pick.observed.length > 0)
            state.observed.push({ controlId: act.controlId, options: pick.observed });
        // Tampilan kontrol menyangkal pilihan (menampilkan teks lain): bukan terisi.
        const reason = pick.ok ? "selection_mismatch" : pick.refused ? "click_refused" : "option_unmatched";
        pushAction(state.log, { ref, kind: "select", action: "select", result: "unverified", reason });
    }
    function finalizeApplyPlan(doc, state, opts, attachedFiles) {
        const { unfilled, filledControlIds, log } = state;
        let filledCount = state.filledCount;
        // Berkas per input file (jalur baru), lalu jalur lama satu CV. Server tidak mengirim keduanya sekaligus; bila tetap
        // begitu, input yang sama tidak diisi dua kali.
        const files = attachedFiles ?? attachFiles(doc, opts?.files);
        filledCount += files.attachedControlIds.length;
        filledControlIds.push(...files.attachedControlIds);
        for (const entry of files.log)
            pushAction(log, entry);
        const legacyControlId = opts?.fileControlId ?? null;
        const legacyAttempted = legacyControlId !== null && !files.attachedControlIds.includes(legacyControlId);
        const legacyAttached = legacyAttempted
            ? attachResumeBytes(doc, legacyControlId, opts?.resumeBase64 ?? null, opts?.resumeFilename ?? "resume.pdf")
            : false;
        if (legacyAttempted) {
            pushAction(log, {
                ref: safeRef(legacyControlId),
                kind: "file",
                action: "attach",
                result: legacyAttached ? "verified" : "unverified",
                // Bedakan CV yang gagal diunduh dari input yang gagal dipasang, supaya log bisa dibaca tanpa menebak.
                ...(legacyAttached ? {} : { reason: opts?.resumeBase64 ? "attach_failed" : "resume_fetch_failed" }),
            });
        }
        if (legacyAttached) {
            filledCount++;
            filledControlIds.push(legacyControlId);
        }
        const filesAttached = { ...files.attached, resume: files.attached.resume || legacyAttached };
        const resumeAttached = filesAttached.resume;
        const missing = countMissingRequired(doc);
        let missingCount = missing.count;
        const missingLabels = [...missing.labels];
        // Kontrol wajib yang dibiarkan kosong harus terhitung kurang. `countMissingRequired` hanya melihat nilai
        // input/select/textarea, jadi combobox berbasis div tidak pernah terhitung olehnya.
        for (const { el } of unfilled) {
            if (!el || el.getAttribute("data-applify-missing") === "true")
                continue;
            const required = el.hasAttribute("required") || el.getAttribute("aria-required") === "true";
            const tag = el.tagName.toLowerCase();
            const hasValue = tag === "input" || tag === "textarea" || tag === "select"
                ? String(el.value ?? "").trim() !== ""
                : isEditableHost(el)
                    ? hasEditableText(el)
                    : isAriaOn(el);
            if (!required || hasValue)
                continue;
            el.setAttribute("data-applify-missing", "true");
            missingCount++;
            missingLabels.push((questionLabelFor(doc, el) || el.getAttribute("name") || "Kolom wajib").trim());
        }
        return {
            filledCount,
            resumeAttached,
            filesAttached,
            filledControlIds,
            missingRequiredCount: missingCount,
            missingLabels: missingLabels.slice(0, 200),
            unfilledControlIds: [...new Set(unfilled.map((u) => u.id))],
            actionLog: log,
            ...(state.observed.length > 0 ? { observedOptions: state.observed } : {}),
            ...(state.fieldErrors.length > 0 ? { fieldErrors: state.fieldErrors.slice(0, 20) } : {}),
        };
    }
    /**
     * Combobox berupa `<input>` teks yang bisa diketik dengan daftar saran (`aria-autocomplete` list/both/inline), misalnya
     * Braid Autosuggest di JobStreet. Uji live 26 November 2026: jawaban "Posisi pekerjaan" yang tidak ada di daftar saran
     * tidak terpilih, JobStreet mengosongkan kolom, dan pengisian berulang tanpa hasil.
     */
    function isFreeTextCombobox(el) {
        if (el.tagName.toLowerCase() !== "input")
            return false;
        const type = (el.getAttribute("type") ?? "text").toLowerCase();
        if (type !== "text" && type !== "search" && type !== "")
            return false;
        if (el.hasAttribute("readonly") || el.hasAttribute("disabled"))
            return false;
        return /^(list|both|inline)$/i.test(el.getAttribute("aria-autocomplete") ?? "");
    }
    const FREE_TEXT_SETTLE_MS = 250;
    /** Tulis teks bebas lalu tunggu sebentar: `true` hanya bila nilai masih sama sesudah blur dan halaman tenang. */
    async function commitFreeTextCombobox(el, value) {
        const norm = (v) => v.replace(/\s+/g, " ").trim().toLowerCase();
        try {
            commitText(el, value);
        }
        catch {
            return false;
        }
        await new Promise((r) => setTimeout(r, FREE_TEXT_SETTLE_MS));
        return norm(el.value ?? "") === norm(value);
    }
    /**
     * Versi asinkron `applyFillPlan` untuk runtime ekstensi: memakai `selectCustomComboboxAsync` agar dropdown yang memuat
     * opsi secara asinkron tetap terisi tanpa mengubah kontrak sinkron `applyFillPlan` pada pengujian lama.
     */
    async function applyFillPlanAsync(doc, actions, opts) {
        const state = newApplyState();
        const pending = [];
        for (const act of actions) {
            const combo = applyUntilCombobox(state, doc, act, pending);
            if (combo) {
                const typeToSearch = act.typeToSearch === true;
                const pick = await selectCustomComboboxAsyncDetailed(doc, combo, String(act.value), { timeoutMs: opts?.comboboxTimeoutMs, typeToSearch });
                // Kolom saran yang menerima teks bebas (JobStreet "Posisi pekerjaan"): jawaban yang tidak ada di daftar ditulis
                // sebagai teks, lalu dicek masih menempel. Dropdown pilih-saja mengosongkannya lagi dan tetap tercatat tak terisi.
                if (!pick.ok && !pick.refused && isFreeTextCombobox(combo) && String(act.value).trim()) {
                    if (await commitFreeTextCombobox(combo, String(act.value))) {
                        pushAction(state.log, { ref: safeRef(act.controlId), kind: "select", action: "set", result: "verified", reason: "free_text" });
                        state.filledCount++;
                        state.filledControlIds.push(act.controlId);
                        continue;
                    }
                }
                recordCombobox(state, act, combo, pick);
            }
        }
        // Satu kali menunggu tenang untuk seluruh isian teks, bukan per kolom: latensi tidak bertambah per kolom.
        await finishPendingText(state, doc, pending, opts);
        const files = await attachFilesAsync(doc, opts?.files, { evidenceMs: opts?.uploadEvidenceMs });
        return finalizeApplyPlan(doc, state, opts, files);
    }
    /**
     * Klik tombol pembuka formulir lamaran ("Lamar", "Lamar Sekarang", "Lamaran Cepat", "Apply", "Easy Apply") HANYA bila
     * belum ada kolom isian yang terbuka dan tidak ada penghalang login/CAPTCHA. Tidak pernah mengklik tombol Submit akhir.
     */
    function clickOpeningApplyButton(doc) {
        const probe = probeForm(doc);
        if (probe.fillable > 0 || probe.blocker)
            return false;
        const btn = findOpeningApplyButton(doc);
        if (!btn)
            return false;
        return humanClick(btn);
    }
    /**
     * Klik tombol langkah berikutnya ("Lanjut", "Berikutnya", "Next", "Continue") di formulir multi-langkah. Tidak pernah
     * mengklik tombol Submit akhir atau tombol SSO/login.
     */
    function clickNextStepButton(doc) {
        const btn = findNextStepButton(doc);
        if (!btn)
            return false;
        if ((btn.getAttribute("data-applify-cid") ?? "").startsWith("applify_sub_"))
            return false;
        return humanClick(btn);
    }
    /** Batas tunggu tombol Lanjut aktif. Glints menonaktifkan "Selanjutnya" selama CV diunggah. */
    const NEXT_STEP_READY_TIMEOUT_MS = 15_000;
    const NEXT_STEP_READY_POLL_MS = 250;
    /**
     * Seperti `clickNextStepButton`, tetapi bila yang ada hanya tombol Lanjut yang NONAKTIF (unggahan berkas atau validasi
     * masih berjalan), tunggu sampai ia aktif dengan polling, paling lama `timeoutMs`. Tidak menunggu bila tidak ada tombol
     * Lanjut sama sekali, atau tombol Lanjut yang aktif ditolak penjaga klik. Tombol kirim akhir tidak pernah ikut: hanya
     * tombol yang lolos penyaring Lanjut (`findNextStepButton` / `findDisabledNextStepButton`) yang ditunggu atau diklik.
     * `false` bila batas waktu habis dan tombolnya masih nonaktif.
     */
    async function clickNextStepButtonWhenReady(doc, opts = {}) {
        const timeoutMs = opts.timeoutMs ?? NEXT_STEP_READY_TIMEOUT_MS;
        const pollMs = Math.max(1, opts.pollMs ?? NEXT_STEP_READY_POLL_MS);
        const deadline = Date.now() + timeoutMs;
        for (;;) {
            if (clickNextStepButton(doc))
                return true;
            // Tombol aktif tetapi tidak diklik (tanda kirim, penjaga klik): menunggu tidak mengubah apa pun.
            if (findNextStepButton(doc) || !findDisabledNextStepButton(doc))
                return false;
            const left = deadline - Date.now();
            if (left <= 0)
                return false;
            await new Promise((resolve) => setTimeout(resolve, Math.min(pollMs, left)));
        }
    }
    function clickSubmitControl(doc, submitControlId) {
        const el = submitControlId
            ? findControlByCid(doc, submitControlId)
            : deepQueryAll(doc, '[data-applify-cid^="applify_sub_"]', 1)[0] ?? null;
        if (!el)
            return false;
        // Tombol simpan sub-formulir ("Simpan jabatan") tidak pernah menjadi tombol kirim akhir, juga bila tandanya basi.
        if (isSubformSaveButton(el))
            return false;
        // H-01: tombol kirim yang nonaktif atau tidak bisa diklik tidak diklik. `false` dilaporkan pemanggil sebagai
        // "submit_control_not_found" (hasil incomplete yang melepas klaim persetujuan), bukan klik yang hilang percuma.
        if (skipReason(el) === "disabled" || !isRendered(el) || isNativelyDisabled(el))
            return false;
        scrollIntoViewIfNeeded(el);
        // Bukan `humanClick`: tombol kirim yang diotorisasi justru ditolak penjaganya (`clickGuardReason`).
        el.click();
        return true;
    }
    /** `:disabled` bawaan browser, termasuk tombol di dalam `<fieldset disabled>`. */
    function isNativelyDisabled(el) {
        try {
            return typeof el.matches === "function" && el.matches(":disabled");
        }
        catch {
            return false;
        }
    }

    /** Tunggu pilihan muncul setelah dropdown dibuka, per kontrol. Dropdown ant memuat daftar lewat animasi dan API, jadi 3 detik. */
    const PEEK_TIMEOUT_MS = 3000;
    /** Anggaran total satu pesan. Sisa kontrol dilewati dengan alasan `time_budget`. */
    const PEEK_TOTAL_BUDGET_MS = 20_000;
    const SAFE_CONTROL_ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
    const clamp = (value, fallback, min, max) => {
        const n = typeof value === "number" && Number.isFinite(value) ? value : fallback;
        return Math.min(max, Math.max(min, n));
    };
    const nowMs = () => (typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now());
    const labelOf = (o) => (o.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, PEEK_MAX_LABEL_CHARS);
    const isComboboxLike = (el) => (el.getAttribute("role") ?? "").trim().toLowerCase().split(/\s+/)[0] === "combobox" || el.getAttribute("aria-haspopup") === "listbox";
    const innerInputOf = (el) => el.tagName.toLowerCase() === "input" ? el : (el.querySelector?.("input") ?? null);
    /** `aria-expanded` pada kontrol atau input di dalamnya, atau null bila tidak ada. */
    function expandedAttr(el, input) {
        for (const node of [el, input]) {
            const v = node?.getAttribute?.("aria-expanded");
            if (v !== null && v !== undefined)
                return v;
        }
        return null;
    }
    /** Dropdown masih terbuka: `aria-expanded` true, atau (tanpa atribut itu) ada opsi baru yang masih tampil. */
    function isStillOpen(doc, el, input, shownBefore) {
        const expanded = expandedAttr(el, input);
        if (expanded !== null)
            return expanded === "true";
        return shownOptions(doc).some((o) => !shownBefore.has(o));
    }
    /** Daftar yang terbaca bukan seluruh daftar: lebih dari batas, atau `aria-setsize` menyebut jumlah yang lebih besar. */
    function isPartialList(options) {
        if (options.length > PEEK_MAX_OPTIONS)
            return true;
        return options.some((o) => {
            const raw = o.getAttribute("aria-setsize");
            if (raw === null)
                return false;
            const size = Number(raw);
            return size === -1 || (Number.isFinite(size) && size > options.length);
        });
    }
    /** Tunggu opsi muncul (`MutationObserver` bila ada, plus polling ringan) paling lama `timeoutMs`. Kosong bila tidak muncul. */
    function waitForOptions(doc, el, input, shownBefore, timeoutMs, pollMs) {
        const read = () => readComboboxOptions(doc, el, input, shownBefore) ?? [];
        const first = read();
        if (first.length > 0 || timeoutMs <= 0)
            return Promise.resolve(first);
        return new Promise((resolve) => {
            let finished = false;
            let observer = null;
            let pollTimer = null;
            let deadlineTimer = null;
            const done = (result) => {
                if (finished)
                    return;
                finished = true;
                if (observer)
                    observer.disconnect();
                if (pollTimer)
                    clearInterval(pollTimer);
                if (deadlineTimer)
                    clearTimeout(deadlineTimer);
                resolve(result);
            };
            const check = () => {
                if (finished)
                    return;
                const options = read();
                if (options.length > 0)
                    done(options);
            };
            if (typeof MutationObserver === "function") {
                try {
                    const target = (doc.body ?? doc.documentElement);
                    if (target) {
                        observer = new MutationObserver(check);
                        observer.observe(target, { childList: true, subtree: true, attributes: true });
                    }
                }
                catch {
                    observer = null;
                }
            }
            pollTimer = setInterval(check, pollMs);
            deadlineTimer = setTimeout(() => done(read()), timeoutMs);
        });
    }
    /** Kolom pencarian: input bisa diedit dengan `aria-autocomplete` list/both, atau di dalam `ant-select-show-search`. */
    function isSearchableCombobox(el, input) {
        for (const node of [el, input]) {
            if (!node)
                continue;
            const readonly = node.hasAttribute?.("readonly") || node.readOnly === true || node.getAttribute?.("aria-readonly") === "true";
            const autocomplete = (node.getAttribute?.("aria-autocomplete") ?? "").toLowerCase();
            if (!readonly && (autocomplete === "list" || autocomplete === "both"))
                return true;
        }
        try {
            return Boolean(el.closest?.('[class*="select-show-search"]'));
        }
        catch {
            return false;
        }
    }
    const entryFor = (controlId, result, reason) => ({
        ref: controlId,
        kind: "select",
        action: "peek",
        result,
        ...(reason ? { reason } : {}),
    });
    async function peekOne(doc, controlId, timeoutMs, pollMs) {
        const skip = (result, reason) => ({ options: [], entry: entryFor(controlId, result, reason) });
        let el = null;
        try {
            el = findControlByCid(doc, controlId);
        }
        catch {
            el = null;
        }
        if (!el)
            return skip("missing", "element_missing");
        if (el.tagName.toLowerCase() === "select")
            return skip("skipped", "native_select");
        if (!isComboboxLike(el))
            return skip("skipped", "not_combobox");
        const skipped = comboboxSkipReason(el);
        if (skipped)
            return skip("skipped", skipped);
        const input = innerInputOf(el);
        if (expandedAttr(el, input) === "true")
            return skip("skipped", "already_open");
        // Penjaga lebih dulu, sebelum fokus atau event apa pun: pemicu bergaya kirim tidak disentuh sama sekali.
        if (clickGuardReason(el))
            return skip("unverified", "click_refused");
        const previousValue = input?.value ?? "";
        const previousFocus = doc.activeElement;
        const shownBefore = new Set(shownOptions(doc));
        el.focus?.();
        if (!humanClick(el)) {
            previousFocus?.focus?.();
            return skip("unverified", "click_refused");
        }
        const optionEls = await waitForOptions(doc, el, input, shownBefore, timeoutMs, pollMs);
        const partial = isPartialList(optionEls);
        const labels = partial ? [] : optionEls.map(labelOf).filter(Boolean);
        // Tutup: blur dulu + kirim focusout sintetis agar React-Select di tab latar menutup menu tanpa mengirim Escape ke dialog.
        // Escape/klik luar hanya dijalankan bila masih terbuka atau teks filter berubah. Tidak ada opsi yang diklik.
        blurCombobox(el, input);
        await new Promise((r) => setTimeout(r, 25));
        if ((input && input.value !== previousValue) || isStillOpen(doc, el, input, shownBefore))
            dismissCombobox(el, input, previousValue);
        if (isStillOpen(doc, el, input, shownBefore)) {
            clickOutsideControl(doc, el);
            await new Promise((r) => setTimeout(r, 30));
            if (isStillOpen(doc, el, input, shownBefore) && !el.closest?.("dialog, [role='dialog'], [aria-modal='true']")) {
                try {
                    const esc = typeof KeyboardEvent === "function"
                        ? new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true, cancelable: true })
                        : new Event("keydown", { bubbles: true });
                    doc.dispatchEvent?.(esc);
                    doc.body?.dispatchEvent?.(esc);
                    doc.defaultView?.dispatchEvent?.(esc);
                }
                catch {
                    // Abaikan bila event keyboard ditolak.
                }
                await new Promise((r) => setTimeout(r, 25));
            }
        }
        const stillOpen = isStillOpen(doc, el, input, shownBefore);
        if (previousFocus && previousFocus !== el && previousFocus !== doc.body && typeof previousFocus.focus === "function") {
            previousFocus.focus();
        }
        if (partial) {
            // Daftar panjang atau tervirtualisasi yang bisa diketik (universitas, kota): beri petunjuk `searchable` agar perencana
            // menjawab dengan teks ketikan, bukan menyerah sebagai tanpa pilihan (audit U2B-10). Alasan log tetap partial_list.
            const searchable = isSearchableCombobox(el, input);
            return { options: [], ...(searchable ? { searchable: true } : {}), entry: entryFor(controlId, "unverified", "partial_list") };
        }
        if (labels.length === 0) {
            // Pencarian jarak jauh: tidak ada pilihan sebelum diketik. Ini petunjuk (bukan kegagalan) untuk perencana.
            if (isSearchableCombobox(el, input))
                return { options: [], searchable: true, entry: entryFor(controlId, "skipped", "searchable") };
            return { options: [], entry: entryFor(controlId, "unverified", "no_options") };
        }
        return { options: labels, entry: entryFor(controlId, stillOpen ? "unverified" : "verified", stillOpen ? "still_open" : undefined) };
    }
    /**
     * Intip pilihan beberapa dropdown kustom. `controlIds` yang tidak valid atau berlebih (lebih dari
     * `PEEK_MAX_CONTROLS`) dibuang. Posisi gulir halaman dipulihkan di akhir.
     */
    async function peekComboboxOptions(doc, controlIds, opts = {}) {
        const peeks = [];
        const actionLog = [];
        const ids = [];
        for (const raw of Array.isArray(controlIds) ? controlIds : []) {
            if (typeof raw !== "string" || !SAFE_CONTROL_ID_RE.test(raw) || ids.includes(raw))
                continue;
            ids.push(raw);
            if (ids.length >= PEEK_MAX_CONTROLS)
                break;
        }
        const timeoutMs = clamp(opts.timeoutMs, PEEK_TIMEOUT_MS, 0, PEEK_TIMEOUT_MS);
        const pollMs = clamp(opts.pollMs, 40, 10, 500);
        const budgetMs = clamp(opts.totalBudgetMs, PEEK_TOTAL_BUDGET_MS, 0, PEEK_TOTAL_BUDGET_MS);
        const startedAt = nowMs();
        const win = typeof window !== "undefined" ? window : null;
        const scrollX = win?.scrollX ?? 0;
        const scrollY = win?.scrollY ?? 0;
        for (const id of ids) {
            if (nowMs() - startedAt > budgetMs) {
                actionLog.push(entryFor(id, "skipped", "time_budget"));
                continue;
            }
            try {
                const outcome = await peekOne(doc, id, timeoutMs, pollMs);
                actionLog.push(outcome.entry);
                if (outcome.options.length > 0)
                    peeks.push({ controlId: id, options: outcome.options.slice(0, PEEK_MAX_OPTIONS) });
                else if (outcome.searchable)
                    peeks.push({ controlId: id, options: [], searchable: true });
            }
            catch {
                actionLog.push(entryFor(id, "unverified", "peek_error"));
            }
        }
        try {
            if (win && typeof win.scrollTo === "function" && (win.scrollX !== scrollX || win.scrollY !== scrollY)) {
                win.scrollTo({ left: scrollX, top: scrollY, behavior: "instant" });
            }
        }
        catch {
            // Pemulihan gulir hanya kenyamanan.
        }
        return { peeks, actionLog };
    }

    /**
     * Titik masuk content script (dijalankan hanya atas permintaan eksplisit side panel melalui activeTab scripting).
     */
    (() => {
        const w = window;
        if (w.__applifyContentLoaded)
            return;
        w.__applifyContentLoaded = true;
        // Dunia terisolasi yang sama dengan `executeScript` milik pemilih frame (`pickBestFrameId`): frame dinilai dengan
        // pembaca formulir yang sama (shadow root terbuka, widget ARIA, contenteditable), bukan hitungan selektor kasar.
        w.__applifyFrameScore = () => countFormControls(document);
        chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
            const url = window.location.href;
            if (isLinkedInUrl(url)) {
                sendResponse({ ok: false, error: "Ekstensi dinonaktifkan di domain LinkedIn (manual-only)." });
                return true;
            }
            // Lapisan tampilan hanya di frame teratas: pemanggil (service worker) menyapa frame 0, ini pagar tambahan.
            if (msg?.type === "AGENT_OVERLAY") {
                if (window !== window.top) {
                    sendResponse({ ok: false, error: "not_top_frame" });
                    return true;
                }
                void getAgentOverlay()
                    .apply(msg)
                    .then((res) => sendResponse(res))
                    .catch(() => sendResponse({ ok: false }));
                return true;
            }
            if (msg?.type === "EXTRACT_FORM") {
                // Halaman atau langkah baru: isian yang tercatat untuk penegasan akhir milik pengisian sebelumnya tidak boleh ikut,
                // supaya suntingan pengguna sesudahnya tidak ditimpa dan id kontrol yang dipakai ulang tidak tertukar.
                // Kecuali baca ulang di langkah yang sama (`keepFilled`): isian langkah ini tetap ikut ditegaskan di akhir.
                if (msg.keepFilled !== true)
                    resetFilledRegistry();
                sendResponse({ ok: true, snapshot: extractFormSnapshot(document, url) });
                return true;
            }
            if (msg?.type === "PROBE_FORM") {
                sendResponse({ ok: true, probe: probeForm(document) });
                return true;
            }
            if (msg?.type === "APPLY_FILL_PLAN") {
                void applyFillPlanAsync(document, (msg.actions ?? []), {
                    fileControlId: msg.fileControlId ?? null,
                    resumeBase64: msg.resumeBase64 ?? null,
                    resumeFilename: msg.resumeFilename ?? "resume.pdf",
                    files: Array.isArray(msg.files) ? msg.files : null,
                })
                    .then((summary) => sendResponse({ ok: true, summary }))
                    .catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
                return true;
            }
            if (msg?.type === "REASSERT_FILLED") {
                void reassertFilled(document)
                    .then((summary) => sendResponse({ ok: true, summary }))
                    .catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
                return true;
            }
            if (msg?.type === "CLICK_OPENING_CTA") {
                const clicked = clickOpeningApplyButton(document);
                sendResponse({ ok: true, clicked });
                return true;
            }
            if (msg?.type === "WAIT_SETTLE") {
                void waitForDomSettle(document, { quietMs: msg.quietMs, maxMs: msg.maxMs })
                    .then((res) => sendResponse({ ok: true, settled: res.settled, waitedMs: res.waitedMs }))
                    .catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
                return true;
            }
            if (msg?.type === "PEEK_COMBOBOX_OPTIONS") {
                void peekComboboxOptions(document, msg.controlIds)
                    .then((res) => sendResponse({ ok: true, peeks: res.peeks, actionLog: res.actionLog }))
                    .catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
                return true;
            }
            if (msg?.type === "CLICK_NEXT_STEP") {
                // Tombol Lanjut bisa nonaktif selama unggahan berkas: ditunggu sampai aktif (paling lama 15 detik), lalu diklik.
                void clickNextStepButtonWhenReady(document)
                    .then((clicked) => sendResponse({ ok: true, clicked }))
                    .catch((err) => sendResponse({ ok: false, clicked: false, error: err instanceof Error ? err.message : String(err) }));
                return true;
            }
            if (msg?.type === "DETECT_NEXT_STEPS") {
                // Hanya baca: teks tombol simpan sub-formulir dan tombol halaman berikutnya, tidak ada yang diklik.
                sendResponse({ ok: true, hints: detectNextStepHints(document) });
                return true;
            }
            if (msg?.type === "CHECK_MISSING_REQUIRED") {
                sendResponse({ ok: true, missing: countMissingRequired(document) });
                return true;
            }
            if (msg?.type === "CLICK_AUTHORIZED_SUBMIT") {
                // Keadaan sebelum klik: pembanding untuk galat validasi dan permintaan kode yang BARU muncul sesudahnya.
                captureSubmitBaseline(document);
                const clicked = clickSubmitControl(document, msg.submitControlId ?? null);
                sendResponse({ ok: clicked });
                return true;
            }
            if (msg?.type === "DETECT_SUBMIT_OUTCOME") {
                const inspected = inspectSubmission(document, msg.submitControlId ?? null);
                sendResponse({
                    ok: true,
                    outcome: inspected.outcome,
                    // Bukti ringkas untuk laporan: jumlah dan keberadaan saja, tanpa teks halaman.
                    evidence: { validationMessages: inspected.validationMessages, controlPresent: inspected.controlPresent },
                    pageUrl: window.location.href,
                });
                return true;
            }
            return false;
        });
    })();

})();
